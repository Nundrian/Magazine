# Verification and scope — 16 November 2026

The maintainer's production Open WebUI `magazine_simple` Function was updated from **0.2.0-handover.1** to **0.2.0-reliability.2**, preserving its Function ID and enabled state. Open WebUI remained 0.12.5. Source SHA-256: `2112da6c358ebfd2b153e26dea1583cbace98714ff11a21bea31af5b44814377`. The installed source matched the delivered source byte for byte.

**Automated tests:** 308 passed, 19 skipped, zero failed. Skips: 16 optional screenshot cases, 2 unavailable historical fixtures and 1 Chromium-only case omitted in Firefox. Browser checks ran in Chromium and Firefox. The original first full attempt exposed a browser fixture race; after correcting test waiting rather than application code, the final suite passed.

**Actual Bonsai 2 27B tests:** On mode stopped a repeated tool-result sequence with `LOOP_DETECTED` and recovered; Off persisted through page reload and allowed eight repeated successful calls without false stopping; normal tool use published and committed a valid result; On/Off settings were frozen in active/queued work; five-attempt enforcement was checked with one real stopped chat plus four controlled startup failures. The final installed On/Off/normal workflows were successfully checked. Earlier rejected diagnostic trials triggered verified automatic rollbacks; the final installation succeeded with no pending rollback.

**Accounting:** A final Off run retained 148,258 input + 3,620 output = 151,878 cumulative known tokens rather than the smaller latest-round token count. The final normal run reported 24,686 input + 7,467 output = 32,153 total. Stopped/incomplete attempts with missing usage stay explicitly incomplete, not zero.

**Preservation:** 647 original Magazine/history files and 2,898 existing project files retained their hashes in the installation report. The 187-cartridge project was not rerun. No unrelated Open WebUI Functions, Tools, model configuration or workflows were changed by the installation.

**Not established:** clean installation on another Open WebUI host, behaviour for other models, full 187-cartridge acceptance, every arbitrary tool integration, destructive power-loss durability, cancellation of tool side effects already committed, or complete accounting for stopped chats that supply no usage. Detection relies on the saved structured tool-call/result history: volatile tool output, ongoing silent reasoning, or opaque side effects may not be recognised as a loop.

The full original report, logs, screenshots, saved chats, backup metadata, and database records remain in the maintainer's private release/evidence bundle and are intentionally not included here.
