# Magazine Simple 0.2.0-reliability.2 — Open WebUI Function

This source archive contains the verified Function code installed on the maintainer's **Open WebUI 0.12.5** environment on **16 November 2026**. The source file's SHA-256 matches the installed Function exactly. The included helper is already embedded in the Function; do **not** install it as another Function.

## Update an existing Magazine Simple installation

1. Wait until the Magazine queue is idle. Back up the existing `magazine_simple` Function code, its settings/valves, Open WebUI database and Magazine run data.
2. In the Open WebUI administration interface, open the existing **Magazine Simple** Function, replace its code with the complete `magazine_simple.py` from this archive, and save. Keep the same Function ID and the previously configured settings. Ensure the Function remains enabled.
3. Open `/magazine-simple`, confirm the version shows `0.2.0-reliability.2`, and test a small disposable workflow with the exact local model and Terminal/tools it needs before using real projects.
4. For rollback, wait until the queue is idle and restore the saved earlier Function and settings. Preserve existing run evidence; newer file-protocol runs may not be compatible with old code.

No public clean-install acceptance is claimed. Do not import this ZIP as a Magazine *workflow*: the archive is Function source and technical reference material. The previous beta.5 import package targets a different implementation and should not be used to update Magazine Simple.

## Main changes

- Five attempts total (initial plus up to four recoveries); **1,800-second allowance per fresh chat**, not per cartridge; the attempt cap also applies to manual Continue.
- Built-in **Antiloop** watchdog observes repeated completed tool calls/results while a chat is active, warns after three identical repetitions and stops after five (or three identical errors), then uses the bounded recovery pathway. It is enabled by default, with a saved On/Off switch per user and Magazine. Off does not disable timeouts, Stop/HALT, or accounting.
- Cumulative known input/output/total tokens are recorded per attempt, cartridge and run in run JSON, LEDGER and ZIP exports; partial usage is marked incomplete rather than made up.
- Existing handover verification, commit identities, SHA-256 validation and fresh-chat recovery remain in place.

See `RELIABILITY.md` and `INSTALLATION-NOTES.md` for full scope, limitations, and tested behaviours. See the public repository for ongoing documentation: https://github.com/Nundrian/Magazine.

## Test status

The supplied installation report records **308 passing tests, 19 skipped and 0 failed**, plus actual Bonsai 2 27B live tests on Open WebUI 0.12.5 of On/Off loop detection, successful handover, persistence and recovery. The historical 187-cartridge workload, other models, fresh-install distribution and destructive service-restart durability were **not** retested. This **cleanly repackaged** source archive has had its manifest and checksums verified; that is not a separate live clean-install acceptance.

MIT licensed; see `LICENSE`.
