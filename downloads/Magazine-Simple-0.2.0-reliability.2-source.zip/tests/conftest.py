"""Shared test setup for the execution candidate.

The 0.2.0, UI and audit test files script their "models" as plain replies that were written before
Magazine asked for a closing line. Two things are done here, and nothing else:

1. A scripted model now does what the prompt tells it. When (and only when) the prompt Magazine sent
   contains the completion instruction, and the scripted reply is not a HALT, the closing line is added
   to the end of the model's final message. A reply given as a raw saved-message dict without visible
   content (the "unfinished" shapes) is left exactly as scripted.
2. MAGAZINE_LEGACY_COMPLETION=1 runs every test with the require_done_line valve off, which is the
   0.2.0 rule. In that mode the prompt has no completion instruction, so (1) does nothing.

Tests that script an unfinished or cut-off model do so with `RAW` (see test_completion.py), which this
file never touches.
"""
import os
import sys

LEGACY = os.environ.get("MAGAZINE_LEGACY_COMPLETION") == "1"


class RAW(dict):
    """A saved assistant message to be returned exactly as written."""


def cartridge_part(ms, prompt):
    """The prompt without the completion instruction Magazine appended (exact text, or unchanged)."""
    block = ms.DONE_INSTRUCTION
    for tail in ("\n\n---\n" + block + "\n", "\n\n" + block + "\n"):
        if prompt.endswith(tail):
            return prompt[:-len(tail)] + ("\n" if tail.startswith("\n\n" + block) else "")
    return prompt


def _obedient(ms, brain):
    """The scripted model: its cartridge behaviour is keyed on the cartridge's own text, and it follows the
    completion instruction when Magazine sent one."""
    def model(prompt, body):
        asked = ms.DONE_INSTRUCTION in prompt
        reply = brain(cartridge_part(ms, prompt), body)
        if isinstance(reply, RAW) or not asked:
            return reply
        if isinstance(reply, str):
            return reply if ms.closing_status(reply) == "HALT" else reply + "\n" + ms.DONE_LINE
        if isinstance(reply, dict) and reply.get("done") and not reply.get("error") \
                and (reply.get("content") or "").strip():
            if ms.closing_status(ms.final_message(reply, reply["content"])) == "HALT":
                return reply
            reply = dict(reply, content=reply["content"] + "\n" + ms.DONE_LINE)
            items = [dict(i) for i in reply.get("output") or []]
            if items and items[-1].get("type") == "message":
                parts = [dict(p) for p in items[-1]["content"]]
                parts[-1]["text"] += "\n" + ms.DONE_LINE
                items[-1]["content"] = parts
                reply["output"] = items
        return reply
    return model


def pytest_collection_finish(session):
    """Once, after the test files are imported: every test file shares test_magazine_simple's module `ms`
    and its FakeOpenWebUI (the UI tests subclass it), so this covers all of them."""
    base = sys.modules.get("test_magazine_simple")
    if base is None or getattr(base, "_contract_applied", False):
        return
    base._contract_applied = True
    ms, fake = base.ms, base.FakeOpenWebUI
    # Preserve the old suites as explicit legacy-protocol regression tests.
    # New file-protocol tests declare result_file_v1 in their manifests.
    ms.DEFAULT_HANDOVER_MODE = "legacy_chat"
    original = fake.__init__

    def init(self, brain, *args, **kwargs):
        original(self, _obedient(ms, brain), *args, **kwargs)
    fake.__init__ = init
    if LEGACY:
        ms.REQUIRE_DONE = False
        real = ms.install_routes

        def install(app, valves):
            valves.require_done_line = False
            return real(app, valves)
        ms.install_routes = install
