import asyncio,json,types
from pathlib import Path
import pytest
from test_magazine_simple import ms,env,FakeOpenWebUI,make_engine,run_to_end,write_workflow
from test_file_handover import workflow,publish,reply,execute


def test_default_manifest_explicit_false_and_persistent_precedence(env):
    run=workflow(env)
    assert run['loop_police']['enabled']
    assert env.store.workflow_loop_policy('u1','file',{'enabled':False})['enabled'] is False
    env.store.save_antiloop('u1','file',False)
    fresh=ms.Store(env.store.data_root,env.store.workspace_root)
    assert fresh.workflow_loop_policy('u1','file')['enabled'] is False
    assert fresh.workflow_loop_policy('u2','file')['enabled'] is True
    fresh.save_antiloop('u1','file',True)
    assert fresh.workflow_loop_policy('u1','file',{'enabled':False})['enabled'] is True
    assert env.store.workflow_loop_policy('u1','other')['enabled'] is True


@pytest.mark.parametrize('value',[None,0,1,'false',[],{}])
def test_setting_requires_real_boolean(env,value):
    with pytest.raises(ms.MagazineError):env.store.save_antiloop('u1','file',value)


def test_start_snapshots_latest_setting_and_recovery_cannot_change_it(env):
    run=workflow(env,retries=2)
    env.store.save_antiloop('u1','file',False)
    calls=[]
    def brain(prompt,body):
        calls.append(1)
        # An independent future-Magazine choice cannot mutate the running snapshot.
        env.store.save_antiloop('u1','file',True)
        if len(calls)>1:publish(prompt)
        return dict(reply(),usage={'input_tokens':10,'output_tokens':2,'total_tokens':12})
    saved,fake,engine=execute(env,run,brain)
    assert saved['status']=='completed' and saved['antiloop_frozen']
    assert saved['loop_police']['enabled'] is False
    assert len(saved['cartridges'][0]['attempts'])==2
    assert saved['tokens']['total']==36
    assert all('loop_evidence' not in a and 'loop_police' not in a for c in saved['cartridges'] for a in c['attempts'])
    assert all(sum(m=='GET' and p=='/api/v1/chats/'+cid for m,p in fake.requests)==1 for cid in fake.chats)


def test_off_keeps_five_attempts_no_sixth_and_timeout_policy(env):
    run=workflow(env,retries=5,outputs=True)
    env.store.save_antiloop('u1','file',False)
    calls=[]
    def brain(prompt,body):
        calls.append(1)
        (env.store.cartridge_dir(run['id'],'p')/'outputs/answer.txt').write_text(str(len(calls)))
        return reply()
    saved,fake,engine=execute(env,run,brain)
    assert len(fake.chats)==5 and saved['status']=='failed'
    saved=asyncio.run(run_to_end(engine,saved))
    assert len(fake.chats)==5
    assert all(a['timeout_seconds']==60 for a in saved['cartridges'][0]['attempts'])


def test_off_still_has_actual_timeout(env,monkeypatch):
    run=workflow(env,retries=0);run['recovery']=ms.recovery_policy({'attempt_seconds':1,'max_attempts':1})
    env.store.save_antiloop('u1','file',False)
    fake=FakeOpenWebUI(lambda p,b:reply(),busy_polls=100000)
    saved=asyncio.run(run_to_end(make_engine(env,fake),run))
    a=saved['cartridges'][0]['attempts'][0]
    assert a['code']=='ATTEMPT_TIMEOUT' and fake.stopped==['chat1']
    assert 'loop_police' not in a and saved['status']=='failed'


def test_old_run_resume_keeps_explicit_false(env):
    run=workflow(env)
    run['loop_police']['enabled']=False;run['status']='failed'
    env.store.save_antiloop('u1','file',True)
    def brain(prompt,body):publish(prompt);return reply()
    saved,_,_=execute(env,run,brain)
    assert saved['loop_police']['enabled'] is False and saved['status']=='completed'


def test_browser_switch_persistence_and_actual_run_snapshot(page,live):
    from test_ui_bulk_collapse import load
    from playwright.sync_api import expect
    load(page,'older')
    switch=page.get_by_role('switch',name='Antiloop')
    expect(switch).to_be_checked()
    switch.uncheck();expect(page.locator('#antiloop-msg')).to_have_text('Saved for this Magazine. Applied when a run starts.')
    page.reload();load(page,'older');expect(switch).not_to_be_checked()
    page.locator('#btn-create').click()
    expect(page.locator('#run-terminal')).to_contain_text('Antiloop: Off')
    expect(page.locator('#btn-start')).to_be_enabled()
    switch.check();expect(page.locator('#run-terminal')).to_contain_text('Antiloop: On')
    page.reload();load(page,'older');expect(switch).to_be_checked()
    load(page,'single');expect(switch).to_be_checked()
    assert page.locator('#tools #antiloop-switch').count()==0
    assert page.locator('#antiloop-control').locator('xpath=..').get_by_text('Tools for this workflow',exact=True).count()==1
    expect(page.locator('#magazine-version')).to_have_text('Magazine Simple 0.2.0-reliability.2')


# Reuse the real Chromium/Firefox fixtures; these exercise the real routes/page.
from test_ui_bulk_collapse import browser,live,page
