"""Execution-correctness tests for 0.2.0-exec.1: completion, HALT, recovery, handover integrity,
filesystem protection and the export.

Everything here is SIMULATED: a fake Open WebUI and scripted "models". No model is called. The saved
assistant messages are built in the shape Open WebUI 0.12.5 really saves (read from the Nebula chats on
12 Nov 2026): an `output` list of reasoning / function_call / function_call_output / message items, every
item `status: completed` even in a cut-off reply, `done: true`, `content` equal to the message items
joined by newlines, and a `usage` dict with Ollama's counters and no stop reason.
"""
import asyncio
import io
import json
import os
import stat
import tracemalloc
import zipfile
from pathlib import Path

import httpx
import pytest

from conftest import RAW
from test_execution_audit import _as_terminal, needs_root, shared_tmp  # noqa: F401
from test_magazine_simple import (FakeOpenWebUI, env, make_engine, ms, run_to_end, save_dir,  # noqa: F401
                                  write_workflow)

DONE = ms.DONE_LINE
HTML = "web/nebula-run.html"


# ------------------------------------------------------------------ saved-message builders

def msg(text):
    return {"type": "message", "id": "m", "status": "completed", "role": "assistant",
            "content": [{"type": "output_text", "text": text}]}


def think(text="Thinking."):
    return {"type": "reasoning", "id": "r", "status": "completed", "start_tag": "<think>", "end_tag": "</think>",
            "attributes": {}, "content": [{"type": "output_text", "text": text}], "summary": None}


def tool(name="run_command", args=None, result="ok"):
    return [{"type": "function_call", "id": "f", "call_id": "c", "name": name, "status": "completed",
             "arguments": json.dumps(args or {})},
            {"type": "function_call_output", "id": "o", "call_id": "c", "status": "completed",
             "output": [{"type": "input_text", "text": result}]}]


def usage(prompt, generated, incomplete=False):
    return {"prompt_eval_count": prompt, "eval_count": generated, "prompt_tokens": prompt,
            "completion_tokens": generated, "incomplete": incomplete, "output_tokens": generated + 40000,
            "total_duration": 1}


def saved(items, use=None, error=None):
    """A saved assistant message exactly as scripted (the test harness adds nothing to it)."""
    content = "\n".join("".join(p["text"] for p in i["content"]) for i in items if i["type"] == "message")
    reply = RAW(content=content, output=items, done=True)
    if use:
        reply["usage"] = use
    if error:
        reply["error"] = {"content": error}
    return reply


def nebula(root, ids=("c10", "c11", "c12")):
    cartridges, prev = [], None
    for cid in ids:
        c = {"id": cid, "prompt": f"# TASK\nBuild {cid}.\n\n# OUTPUT\nSave `{HTML}`.",
             "artifacts": {"outputs": [HTML]}}
        if prev:
            c["artifacts"]["inputs"] = [{"from": prev, "path": HTML}]
        cartridges.append(c)
        prev = cid
    return write_workflow(root, cartridges, name="Nebula Run")


def write_game(prompt, text):
    out = save_dir(prompt)
    (out / "web").mkdir(parents=True, exist_ok=True)
    (out / HTML).write_text(text, encoding="utf-8")


def run_line(env, brain, workflow="nebula", require_done=True, models=None):
    fake = FakeOpenWebUI(brain)
    engine = make_engine(env, fake)
    engine.require_done = require_done
    run = ms.new_run(env.store, "u1", env.library, workflow, models or {"worker": "m"}, ["dev"], "open-terminal")
    return asyncio.run(run_to_end(engine, run)), fake, engine


def sent_prompts(fake):
    return [c["completion"]["messages"][0]["content"] for c in fake.chats.values() if c["completion"]]


# ====================================================================== A. completion

def test_file_exists_but_the_reply_stopped_mid_work_is_not_done(env):
    """Nebula c07 attempt 2 (chat b1edc8a8): the output file existed, the reply ended on a reasoning item
    after a tool call, the last usage was 63,439 + 2,097 = 65,536. 0.2.0 recorded it done."""
    nebula(env.library / "nebula")

    def brain(prompt, body):
        if "Build c10" in prompt:
            write_game(prompt, "<html>terrain that never spawns</html>")
            return saved([think(), msg("The trace bypassed the real spawn logic. Let me test the real logic "
                                       "that's actually in the file."), *tool(), think("So _lastColumnX ...")],
                         usage(63439, 2097))
        raise AssertionError("no later cartridge may be dispatched")

    run, fake, _ = run_line(env, brain)
    a = run["cartridges"][0]["attempts"][0]
    assert run["status"] == "failed" and a["status"] == "failed"
    assert a["note"].startswith("Unfinished: the final message did not end with " + DONE)
    assert "ended on a reasoning item" in a["note"] and "63439 prompt + 2097 generated" in a["note"]
    assert "records no stop reason" in a["note"] and "Continue from this step" in a["note"]
    assert a["ended"] == {"last_item": "reasoning", "prompt_tokens": 63439, "generated_tokens": 2097,
                          "usage_incomplete": False}
    assert a["outputs"][0]["path"] == HTML and a["outputs"][0]["bytes"] == 38     # the file is kept and recorded
    assert [c["status"] for c in run["cartridges"]] == ["failed", "pending", "pending"]
    assert len(fake.chats) == 1                                                    # nothing after it, no retry
    assert (env.store.run_dir("u1", run["id"]) / "results" / "01-c10.md").read_text().endswith("in the file.")


def test_the_same_reply_was_recorded_done_under_the_0_2_0_rule(env):
    """Fault reproduction: with the valve off (the 0.2.0 rule) the identical cut-off reply passes, and the
    next cartridge is given the unfinished file. This is the Nebula c07 defect."""
    nebula(env.library / "nebula", ids=("c10", "c11"))
    calls = []

    def brain(prompt, body):
        calls.append(prompt)
        write_game(prompt, "<html>unfinished</html>")
        return saved([msg("Let me now rewrite the spawn check."), *tool(), think()], usage(63439, 2097))

    run, _, _ = run_line(env, brain, require_done=False)
    assert run["status"] == "completed" and len(calls) == 2
    assert ms.DONE_INSTRUCTION not in calls[0]


def test_a_final_summary_cut_mid_sentence_is_not_done(env):
    """Nebula c08 (chat 4ba1167b): the last item IS a message, cut inside its list ("Score value (100 for
    straight,"); 65,053 + 483 = 65,536. Only the missing closing line distinguishes it."""
    nebula(env.library / "nebula")

    def brain(prompt, body):
        write_game(prompt, "<html>enemies</html>")
        return saved([msg("Starting."), *tool(), think(),
                      msg("## Summary\n- Health (2 points)\n- Score value (100 for straight,")], usage(65053, 483))

    run, fake, _ = run_line(env, brain)
    a = run["cartridges"][0]["attempts"][0]
    assert a["status"] == "failed" and a["note"].startswith("Unfinished") and len(fake.chats) == 1
    assert a["ended"]["last_item"] == "message"


def test_stopped_before_writing_the_required_file(env):
    """Nebula c11 attempt 1 (chat 9e42562d): one 34,991-token round of thinking, no file."""
    nebula(env.library / "nebula")
    run, fake, _ = run_line(env, lambda p, b: saved(
        [think(), msg("I'll start by examining the input file."), *tool("read_file"), think("x" * 500)],
        usage(30545, 34991)))
    a = run["cartridges"][0]["attempts"][0]
    assert a["status"] == "failed" and len(fake.chats) == 1
    assert a["note"].startswith(f"Required output file(s) not found: {HTML}. Unfinished:")
    assert a["outputs"] == []


@pytest.mark.parametrize("closing", [
    "Done. Terrain spawns.\n" + DONE,
    "Done.\n```json\n" + DONE + "\n```",
    "Done.\n`" + DONE + "`",
    "Done.\n" + '{"status": "DONE"}' + "  \n\n",
    "Done.\n" + '{ "status" : "done" }',
    DONE,                                                         # no commentary at all
])
def test_a_completed_reply_passes_however_the_closing_line_is_dressed(env, closing):
    nebula(env.library / "nebula", ids=("c10",))

    def brain(prompt, body):
        write_game(prompt, "<html>ok</html>")
        return saved([think(), msg("Reading the file."), *tool(), think(), msg(closing)], usage(21000, 300))

    run, _, _ = run_line(env, brain)
    a = run["cartridges"][0]["attempts"][0]
    assert run["status"] == "completed" and a["status"] == "done" and "note" not in a
    assert a["ended"]["last_item"] == "message"


@pytest.mark.parametrize("ending", [
    "All done, I will now reply " + DONE + " as asked",           # inside a sentence, more text after it
    "Finished, so " + DONE,                                        # inside a sentence (0.2.0-exec.5: "Finished. " +
                                                                   # DONE now counts; see test_inline_closing.py)
    DONE + "\nActually, let me check one more thing.",             # not the end of the message
    "DONE",                                                        # the word, not the line
])
def test_a_closing_line_that_is_not_a_closing_line_does_not_pass(env, ending):
    nebula(env.library / "nebula", ids=("c10",))

    def brain(prompt, body):
        write_game(prompt, "<html>ok</html>")
        return saved([msg(ending)])

    run, _, _ = run_line(env, brain)
    assert run["cartridges"][0]["attempts"][0]["note"].startswith("Unfinished")


def test_declaring_done_without_the_required_file_fails(env):
    nebula(env.library / "nebula", ids=("c10",))
    run, _, _ = run_line(env, lambda p, b: saved([msg("All saved.\n" + DONE)]))
    a = run["cartridges"][0]["attempts"][0]
    assert a["status"] == "failed" and a["note"] == f"Required output file(s) not found: {HTML}"


@pytest.mark.parametrize("require_done", [True, False])
@pytest.mark.parametrize("final", [
    'Blocked.\n{"status":"HALT","reason":"Game.damagePlayer is missing"}',
    '{\n  "status": "HALT",\n  "reason": "Game.damagePlayer is missing"\n}',
    'I cannot go on.\n```json\n{"status":"HALT","reason":"Game.damagePlayer is missing"}\n```',
    # control examples quoted first, then the real closing response: the closing object's reason is the one kept
    'The note says to end with\n{"status":"DONE"}\nor, if blocked,\n{"status":"HALT","reason":"why"}\n'
    'I am blocked.\n{"status":"HALT","reason":"Game.damagePlayer is missing"}',
])
def test_a_genuine_halt_in_the_final_message_halts_and_keeps_its_reason(env, final, require_done):
    nebula(env.library / "nebula")

    def brain(prompt, body):
        write_game(prompt, "<html>x</html>")
        return saved([msg("Checking the input."), *tool(), think(), msg(final)])

    run, fake, _ = run_line(env, brain, require_done=require_done)
    a = run["cartridges"][0]["attempts"][0]
    assert run["status"] == "halted" and a["status"] == "halted" and len(fake.chats) == 1
    assert a["note"] == "Game.damagePlayer is missing"
    assert "Game.damagePlayer is missing" in (env.store.work_dir(run["id"]) / "LEDGER.md").read_text()


NOT_A_CLOSING_HALT = [
    # quoted as an example, then the reply stops (a cut-off final message)
    'If the API were missing I would answer\n{"status":"HALT","reason":"example"}\nIt is present, so let me now',
    # embedded in commentary, in a code block, and the model simply forgot its closing line
    'Notes for the next step. On a missing API reply:\n```json\n{"status":"HALT","reason":"missing"}\n```\n'
    'Nothing was missing. The file is saved.',
    # a HALT with words after it is not a closing line either: it stops the run as unfinished, not as HALT
    '```json\n{"status":"HALT","reason":"Game.damagePlayer is missing"}\n```\nI stopped here.',
]


@pytest.mark.parametrize("final", NOT_A_CLOSING_HALT)
def test_a_halt_object_that_does_not_close_the_final_message_is_not_a_halt(env, final):
    """Final review, 13 Nov: with the closing line required, HALT is read the same way as DONE, from the end of
    the final message only. The run still stops (nothing is dispatched), but as unfinished, and the note says a
    HALT object was seen."""
    nebula(env.library / "nebula")

    def brain(prompt, body):
        write_game(prompt, "<html>x</html>")
        return saved([msg("Checking the input."), *tool(), think(), msg(final)])

    run, fake, _ = run_line(env, brain)
    a = run["cartridges"][0]["attempts"][0]
    assert run["status"] == "failed" and a["status"] == "failed" and len(fake.chats) == 1
    assert a["note"].startswith("Unfinished: the final message did not end with " + DONE)
    assert "A HALT object appears in the final message but is not its last line" in a["note"]
    assert [c["status"] for c in run["cartridges"]] == ["failed", "pending", "pending"]


@pytest.mark.parametrize("final", NOT_A_CLOSING_HALT)
def test_with_the_valve_off_a_halt_object_anywhere_in_the_final_message_still_halts(env, final):
    """The 0.2.0 contract, unchanged when require_done_line is off: there is no closing line to go by."""
    nebula(env.library / "nebula")

    def brain(prompt, body):
        write_game(prompt, "<html>x</html>")
        return saved([msg(final)])

    run, _, _ = run_line(env, brain, require_done=False)
    assert run["status"] == "halted"


@pytest.mark.parametrize("require_done", [True, False])
def test_halt_and_done_quoted_between_tool_calls_decide_nothing(env, require_done):
    """The saved-chat form of the audit's HALT finding: commentary before a tool call quotes both objects on
    their own lines; the real final message closes normally."""
    nebula(env.library / "nebula", ids=("c10", "c11"))

    def brain(prompt, body):
        write_game(prompt, "<html>ok</html>")
        return saved([msg('The work method says: if blocked return\n{"status":"HALT","reason":"..."}\n'
                          'and when finished end with\n' + DONE + '\nI am not blocked; continuing.'),
                      *tool(), think(), msg("Saved web/nebula-run.html." + ("\n" + DONE if require_done else ""))])

    run, fake, _ = run_line(env, brain, require_done=require_done)
    assert run["status"] == "completed" and len(fake.chats) == 2
    assert [c["status"] for c in run["cartridges"]] == ["done", "done"]


def test_a_quoted_done_in_commentary_does_not_complete_a_cut_off_reply(env):
    nebula(env.library / "nebula")

    def brain(prompt, body):
        write_game(prompt, "<html>x</html>")
        return saved([msg("When finished I must end with\n" + DONE), *tool(), think("cut off here")])

    run, fake, _ = run_line(env, brain)
    a = run["cartridges"][0]["attempts"][0]
    assert a["status"] == "failed" and a["note"].startswith("Unfinished") and len(fake.chats) == 1


def test_a_quoted_halt_in_commentary_does_not_halt_a_cut_off_reply(env):
    """It is unfinished, not halted: the model never said HALT as its answer."""
    nebula(env.library / "nebula")

    def brain(prompt, body):
        write_game(prompt, "<html>x</html>")
        return saved([msg('If blocked I would return:\n{"status":"HALT","reason":"example"}'), *tool(), think()])

    run, _, _ = run_line(env, brain)
    a = run["cartridges"][0]["attempts"][0]
    assert a["status"] == "failed" and a["note"].startswith("Unfinished")


def test_a_halt_example_inside_the_final_message_does_not_beat_the_closing_done(env):
    nebula(env.library / "nebula", ids=("c10",))

    def brain(prompt, body):
        write_game(prompt, "<html>ok</html>")
        return saved([msg('Notes for the next step: on a missing API reply\n{"status":"HALT","reason":"missing"}\n'
                          "Nothing was missing here.\n" + DONE)])

    run, _, _ = run_line(env, brain)
    assert run["status"] == "completed"


def test_a_chat_template_error_fails_the_cartridge_with_the_error_kept(env):
    """Nebula c07 attempt 1 (chat f87094dc): Ollama's template raised after the context was exceeded. Open
    WebUI saved `error` on the message, with visible text and done:true."""
    nebula(env.library / "nebula")
    err = ("------------\nWhile executing CallExpression at line 79, column 24 in source:\n"
           "Error: Jinja Exception: No user query found in messages.")

    def brain(prompt, body):
        write_game(prompt, "<html>half</html>")
        return saved([msg("The ctx proxy just needs methods. Let me fix that:"), *tool()], usage(64359, 719), err)

    run, fake, _ = run_line(env, brain)
    a = run["cartridges"][0]["attempts"][0]
    assert a["status"] == "failed" and "No user query found in messages" in a["note"]
    assert a["note"].startswith("The model returned an error:") and len(fake.chats) == 1
    assert [c["completion"]["messages"] for c in fake.chats.values()][0][0]["role"] == "user"   # Magazine sent one


def test_termination_metadata_is_recorded_when_present_and_not_invented_when_absent(env):
    write_workflow(env.library / "w", [{"id": "a", "prompt": "with usage"}, {"id": "b", "prompt": "without usage"},
                                       {"id": "c", "prompt": "plain content"}])

    def brain(prompt, body):
        if prompt.startswith("with usage"):
            return saved([think(), msg("ok\n" + DONE)], usage(51216, 1002, incomplete=True))
        if prompt.startswith("without usage"):
            return saved([think(), msg("ok\n" + DONE)])
        return RAW(content="ok\n" + DONE, done=True)              # an older record: no output list at all

    run, _, _ = run_line(env, brain, workflow="w")
    ended = [c["attempts"][0]["ended"] for c in run["cartridges"]]
    assert ended == [{"last_item": "message", "prompt_tokens": 51216, "generated_tokens": 1002,
                      "usage_incomplete": True}, {"last_item": "message"}, {}]
    assert run["status"] == "completed"
    assert "stop_reason" not in json.dumps(run) and "finish_reason" not in json.dumps(run)


def test_a_reply_with_no_visible_text_is_not_a_completion(env, monkeypatch):
    """ornith:9b c06 (chat 2b50840a): 16,384 tokens of thinking, empty content, done:true."""
    monkeypatch.setattr(ms, "SAVE_WAIT_SECONDS", 0.0)
    write_workflow(env.library / "w", [{"id": "a", "prompt": "x"}, {"id": "b", "prompt": "y"}])
    run, fake, _ = run_line(env, lambda p, b: saved([think("t" * 2000), *tool(), think("t" * 2000)],
                                                    usage(19481, 16384)), workflow="w")
    a = run["cartridges"][0]["attempts"][0]
    assert a["status"] == "failed" and a["note"] == "The chat finished but no answer was saved"
    assert len(fake.chats) == 1


def test_json_handover_still_works_with_the_closing_line(env):
    write_workflow(env.library / "w", [
        {"id": "c1", "prompt": "Decide. Reply with JSON."},
        {"id": "c2", "prompt": "Use it.", "handover": [{"from": "c1", "select": "/policy", "as": "policy"}]},
        {"id": "c3", "prompt": "Use the combined form.",
         "handover": [{"from": "c2", "select": "/n", "as": "n"}]}])
    seen = []

    def brain(prompt, body):
        seen.append(prompt)
        if prompt.startswith("Decide"):
            return saved([msg("Looking."), *tool(), msg('{"status":"OK","policy":"paid_only"}\n' + DONE)])
        if prompt.startswith("Use it."):
            return saved([msg('Result:\n```json\n{"status":"DONE","n":7}\n```')])   # one object, status DONE
        return saved([msg(DONE)])

    run, _, _ = run_line(env, brain, workflow="w")
    assert run["status"] == "completed"
    assert '"paid_only"' in seen[1] and "n (from c2):\n```json\n7\n```" in seen[2]
    assert ms.result_json('{"a":1}\n' + DONE) == {"a": 1} and ms.result_json(DONE) is None


def test_the_prompt_is_the_cartridge_text_plus_the_documented_blocks_and_nothing_else(env):
    nebula(env.library / "nebula", ids=("c10", "c11"))
    write_workflow(env.library / "plain", [{"id": "p", "prompt": "Say hello.\n"}])

    def brain(prompt, body):
        if "Build" in prompt:
            write_game(prompt, "<html>ok</html>")
        return saved([msg(DONE)])

    run, fake, _ = run_line(env, brain)
    out = env.store.cartridge_dir(run["id"], "c11")
    assert sent_prompts(fake)[1] == (
        f"# TASK\nBuild c11.\n\n# OUTPUT\nSave `{HTML}`.\n\n---\n"
        f"Files for this step:\n- Save your output files in: {out / 'outputs'}\n"
        f"- Required output files: {HTML}\n- Input files:\n"
        f"  - {out / 'inputs' / 'c10' / HTML} (from c10: {HTML})\n\n"
        "When this step is finished:\n"
        '- End your final message with this line, on its own: {"status":"DONE"}\n'
        '- If you cannot finish it, end with {"status":"HALT","reason":"why"} instead.\n'
        "A reply that ends without one of these lines is treated as unfinished.\n")
    _, fake2, _ = run_line(env, brain, workflow="plain")
    assert sent_prompts(fake2)[0] == "Say hello.\n\n---\n" + ms.DONE_INSTRUCTION + "\n"
    _, fake3, _ = run_line(env, brain, workflow="plain", require_done=False)
    assert sent_prompts(fake3)[0] == "Say hello."                         # valve off: the 0.2.0 prompt exactly
    assert len(ms.DONE_INSTRUCTION) < 300                                 # a few dozen tokens, once per cartridge


def test_no_extra_inference_one_chat_and_one_completion_request_per_attempt(env):
    nebula(env.library / "nebula")

    def brain(prompt, body):
        write_game(prompt, "<html>ok</html>")
        return saved([msg("ok" if "c12" in prompt else "ok\n" + DONE)])

    run, fake, _ = run_line(env, brain)
    assert [c["status"] for c in run["cartridges"]] == ["done", "done", "failed"]
    assert len(fake.chats) == 3
    assert sum(1 for m, p in fake.requests if p == "/api/chat/completions") == 3     # no nudge, no retry
    assert all(len(c["completion"]["messages"]) == 1 for c in fake.chats.values())


# ====================================================================== B. recovery

class ContinuedByHand(FakeOpenWebUI):
    """After the model stops, a person types "please continue" in the chat and the model, which no longer has
    the cartridge prompt, answers with a DONE line (Nebula c11, chat 9e42562d)."""

    def handler(self, request):
        response = super().handler(request)
        if request.method == "GET" and request.url.path.startswith("/api/v1/chats/"):
            data = json.loads(response.content)
            messages = data["chat"]["history"]["messages"]
            if any(m.get("role") == "assistant" and "examining" in (m.get("content") or "")
                   for m in messages.values()):
                messages["u2"] = {"id": "u2", "role": "user", "content": "please continue"}
                messages["a2"] = {"id": "a2", "role": "assistant", "done": True,
                                  "content": "The damage system is verified.\n" + DONE,
                                  "output": [msg("The damage system is verified.\n" + DONE)]}
                data["chat"]["history"]["currentId"] = "a2"
                return httpx.Response(200, json=data)
        return response


def test_continue_from_this_step_restores_the_whole_cartridge_contract(env):
    nebula(env.library / "nebula")
    state = {"c11": 0}

    def brain(prompt, body):
        if "Build c11" in prompt:
            state["c11"] += 1
            if state["c11"] == 1:                                           # attempt 1: Nebula c11 attempt 1
                (save_dir(prompt) / "scratch.txt").write_text("notes", encoding="utf-8")
                return saved([msg("I'll start by examining the input file."), *tool("read_file"), think()],
                             usage(30545, 34991))
        write_game(prompt, f"<html>{prompt.split()[3]}</html>")
        return saved([msg("Saved.\n" + DONE)])

    fake = ContinuedByHand(brain)
    engine = make_engine(env, fake)
    engine.require_done = True
    run = asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "nebula", {"worker": "m"},
                                                    ["dev"], "open-terminal")))
    assert [c["status"] for c in run["cartridges"]] == ["done", "failed", "pending"]
    # the hand-typed continuation is in the saved chat, with a DONE line, and is not taken for the reply
    assert run["cartridges"][1]["attempts"][0]["note"].startswith(f"Required output file(s) not found: {HTML}")
    assert len(fake.chats) == 2
    first_prompt = sent_prompts(fake)[1]
    results = env.store.run_dir("u1", run["id"]) / "results"
    assert (results / "02-c11.prompt.md").read_text() == first_prompt

    with pytest.raises(ms.MagazineError, match="c11 has not completed"):   # cannot skip the unfinished step
        engine.start(run, "tok", {}, 2)
    hashes_before = [a["outputs"] for a in run["cartridges"][0]["attempts"]]
    run = asyncio.run(run_to_end(engine, run, start=1))                     # "Continue from this step"

    assert run["status"] == "completed"
    assert [c["id"] for c in run["cartridges"]] == ["c10", "c11", "c12"]   # no cartridge added, order kept
    assert [len(c["attempts"]) for c in run["cartridges"]] == [1, 2, 1]
    prompts = sent_prompts(fake)
    assert len(fake.chats) == 4 and prompts[2] == first_prompt              # same task, inputs, paths, closing note
    assert "Build c12" in prompts[3] and prompts.count(first_prompt) == 2
    retry = fake.chats["chat3"]["completion"]
    assert len(retry["messages"]) == 1 and retry["model"] == "m" and retry["tool_ids"] == ["dev"]
    assert retry["terminal_id"] == "open-terminal"
    c11 = run["cartridges"][1]["attempts"]
    assert c11[0]["status"] == "failed" and c11[0]["note"].startswith("Required output")   # the reason is kept
    assert c11[0]["chat_id"] == "chat2" and c11[1]["chat_id"] == "chat3" and c11[1]["status"] == "done"
    assert [a["outputs"] for a in run["cartridges"][0]["attempts"]] == hashes_before
    work = env.store.work_dir(run["id"])
    assert (work / "c11~attempt1" / "outputs" / "scratch.txt").read_text() == "notes"     # evidence kept
    assert (work / "c11~attempt1" / "inputs" / "c10" / HTML).is_file()
    assert (results / "02-c11~attempt1.md").read_text().startswith("I'll start by examining")
    assert (results / "02-c11~attempt1.prompt.md").read_text() == first_prompt
    assert (results / "02-c11.md").read_text() == "Saved.\n" + DONE
    ledger = (work / "LEDGER.md").read_text()
    assert "| 2 | c11 | 1 | `m` | failed |" in ledger and "| 2 | c11 | 2 | `m` | done |" in ledger
    assert "**c11, attempt 1:** Required output file(s) not found" in ledger
    assert not (work / "c12_hud").exists() and sorted(p.name for p in work.iterdir()) == [
        "LEDGER.md", "c10", "c11", "c11~attempt1", "c12"]


def test_a_run_record_written_by_0_2_0_continues(env):
    """Existing runs: version 0.2.0, attempts without `ended`, inputs without hashes or `verified`."""
    nebula(env.library / "nebula")

    def brain(prompt, body):
        write_game(prompt, "<html>new</html>")
        return saved([msg(DONE)])

    fake = FakeOpenWebUI(brain)
    engine = make_engine(env, fake)
    run = ms.new_run(env.store, "u1", env.library, "nebula", {"worker": "m"}, [], None)
    out = env.store.cartridge_dir(run["id"], "c10") / "outputs" / "web"
    out.mkdir(parents=True)
    (out / "nebula-run.html").write_text("<html>old</html>", encoding="utf-8")
    old = "<html>old</html>".encode()
    run.update(version="0.2.0", status="failed")
    run["cartridges"][0].update(status="done", attempts=[{
        "model": "m", "status": "done", "started": "2026-11-11T03:07:13+00:00", "chat_id": "x", "inputs": [],
        "outputs": [{"path": HTML, "bytes": len(old), "sha256": ms.sha256_bytes(old)}],
        "finished": "2026-11-11T03:14:35+00:00"}])
    run["cartridges"][1].update(status="failed", attempts=[{
        "model": "m", "status": "failed", "started": "2026-11-11T03:14:35+00:00", "chat_id": "y",
        "inputs": [{"from": "c10", "path": HTML, "bytes": len(old)}], "outputs": [],
        "note": f"Required output file(s) not found: {HTML}", "finished": "2026-11-11T03:23:09+00:00"}])
    (env.store.run_dir("u1", run["id"]) / "results").mkdir()
    (env.store.run_dir("u1", run["id"]) / "results" / "01-c10.md").write_text("old reply", encoding="utf-8")
    env.store.save(run)
    run = asyncio.run(run_to_end(engine, env.store.load("u1", run["id"]), start=1))
    assert run["status"] == "completed" and run["version"] == "0.2.0"
    delivered = run["cartridges"][1]["attempts"][1]["inputs"][0]
    assert delivered["verified"] is True and delivered["sha256"] == ms.sha256_bytes(old)
    assert (env.store.run_dir("u1", run["id"]) / "results" / "01-c10.md").read_text() == "old reply"


# ====================================================================== C. handover integrity

def two_steps(env):
    return write_workflow(env.library / "w", [
        {"id": "c1", "prompt": "a", "artifacts": {"outputs": ["f.txt"]}},
        {"id": "c2", "prompt": "b", "artifacts": {"inputs": [{"from": "c1", "path": "f.txt"}],
                                                   "outputs": ["g.txt"]}}])


def handover_run(env, monkeypatch, tamper=None, c1_text="original"):
    two_steps(env)
    calls = []

    def brain(prompt, body):
        calls.append(prompt[0])
        out = save_dir(prompt)
        (out / ("f.txt" if prompt.startswith("a") else "g.txt")).write_text(c1_text, encoding="utf-8")
        return saved([msg(DONE)])

    real = ms.prepare_files

    def between(cartridge, run, store):
        if cartridge["id"] == "c2" and tamper:
            tamper(store.cartridge_dir(run["id"], "c1") / "outputs")
        return real(cartridge, run, store)

    monkeypatch.setattr(ms, "prepare_files", between)
    run, fake, _ = run_line(env, brain, workflow="w")
    return run, fake, calls


def test_an_unchanged_file_is_handed_over_verified(env, monkeypatch):
    run, _, calls = handover_run(env, monkeypatch)
    assert run["status"] == "completed" and calls == ["a", "b"]
    recorded = run["cartridges"][0]["attempts"][0]["outputs"][0]
    delivered = run["cartridges"][1]["attempts"][0]["inputs"][0]
    assert delivered == {"from": "c1", "path": "f.txt", "bytes": 8, "sha256": recorded["sha256"], "verified": True}
    copy = env.store.cartridge_dir(run["id"], "c2") / "inputs" / "c1" / "f.txt"
    assert ms.sha256_bytes(copy.read_bytes()) == recorded["sha256"]
    assert stat.S_IMODE(copy.stat().st_mode) == 0o666 and not list(copy.parent.glob("*.part"))


CHANGES = {
    "content edited": lambda out: (out / "f.txt").write_text("tampered", encoding="utf-8"),
    "one byte flipped, same size": lambda out: (out / "f.txt").write_bytes(b"originaL"),
    "truncated": lambda out: (out / "f.txt").write_bytes(b""),
    "replaced by a different file": lambda out: (os.remove(out / "f.txt"),
                                                 (out / "f.txt").write_text("another", encoding="utf-8")),
}


@pytest.mark.parametrize("change", list(CHANGES))
def test_a_changed_output_is_refused_and_the_next_cartridge_never_starts(env, monkeypatch, change):
    run, fake, calls = handover_run(env, monkeypatch, CHANGES[change])
    a = run["cartridges"][1]["attempts"][0]
    assert run["status"] == "failed" and a["status"] == "failed"
    assert a["note"].startswith("Input file f.txt from c1 changed after c1 finished: recorded 8 B ")
    assert "Nothing was handed over" in a["note"]
    assert calls == ["a"] and len(fake.chats) == 1 and a["chat_id"] is None          # no inference was spent
    here = env.store.cartridge_dir(run["id"], "c2")
    assert not (here / "inputs" / "c1" / "f.txt").exists() and not list(here.rglob("*.part"))
    assert (env.store.cartridge_dir(run["id"], "c1") / "outputs" / "f.txt").exists()   # the evidence stays
    assert run["cartridges"][0]["attempts"][0]["outputs"][0]["bytes"] == 8             # the record is untouched


def test_fault_injection_the_check_is_what_catches_it(env, monkeypatch):
    """Control: with the recorded hash removed from the record the same edit goes through (and is labelled
    unverified), so the refusal above comes from the comparison and not from something incidental."""
    def strip_and_tamper(out):
        (out / "f.txt").write_text("tampered", encoding="utf-8")

    real_lookup = ms.recorded_output
    monkeypatch.setattr(ms, "recorded_output", lambda run, cid, rel: None)
    run, _, calls = handover_run(env, monkeypatch, strip_and_tamper)
    assert calls == ["a", "b"] and run["status"] == "completed"
    a = run["cartridges"][1]["attempts"][0]
    assert a["inputs"][0]["verified"] is False
    assert a["note"] == "Handed over without an integrity check (no recorded hash for the earlier step): f.txt"
    assert real_lookup(run, "c1", "f.txt")["bytes"] == 8


def test_a_missing_output_is_refused(env, monkeypatch):
    run, fake, _ = handover_run(env, monkeypatch, lambda out: os.remove(out / "f.txt"))
    a = run["cartridges"][1]["attempts"][0]
    assert a["note"] == "Input file f.txt from c1 is missing or is not a regular file" and len(fake.chats) == 1


def _link_file(out):
    (out / "elsewhere.txt").write_text("original", encoding="utf-8")        # identical bytes, wrong object
    os.remove(out / "f.txt")
    os.symlink(out / "elsewhere.txt", out / "f.txt")


def _link_folder(out):
    os.rename(out, out.with_name("moved"))
    os.symlink(out.with_name("moved"), out)


def _fifo(out):
    os.remove(out / "f.txt")
    os.mkfifo(out / "f.txt")


@pytest.mark.parametrize("swap", [_link_file, _link_folder, _fifo])
def test_links_and_special_files_are_never_followed_or_read(env, monkeypatch, swap):
    run, fake, _ = handover_run(env, monkeypatch, swap)
    a = run["cartridges"][1]["attempts"][0]
    assert a["status"] == "failed" and a["note"].endswith("is missing or is not a regular file")
    assert len(fake.chats) == 1


def test_a_required_output_that_is_a_link_is_not_collected(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "a", "artifacts": {"outputs": ["f.txt"]}}])
    secret = env.tmp / "secret.txt"
    secret.write_text("not the model's file", encoding="utf-8")

    def brain(prompt, body):
        os.symlink(secret, save_dir(prompt) / "f.txt")
        return saved([msg(DONE)])

    run, _, _ = run_line(env, brain, workflow="w")
    a = run["cartridges"][0]["attempts"][0]
    assert a["status"] == "failed" and a["outputs"] == []
    assert a["note"] == "Required output file(s) not found: f.txt (a link, not a file)"
    assert "work/c1/outputs/f.txt" not in zipfile.ZipFile(io.BytesIO(ms.build_download(env.store, run))).namelist()


def test_large_files_are_hashed_and_copied_in_bounded_memory(env):
    two_steps(env)
    store = env.store
    run = ms.new_run(store, "u1", env.library, "w", {"worker": "m"}, [], None)
    c1, c2 = ms.load_workflow(store.run_dir("u1", run["id"]) / "workflow")["cartridges"]
    ms.prepare_files(c1, run, store)
    big = store.cartridge_dir(run["id"], "c1") / "outputs" / "f.txt"
    with open(big, "wb") as f:
        for n in range(48):
            f.write(bytes([n]) * (1024 * 1024))                                # 48 MB
    tracemalloc.start()
    files, missing = ms.collect_outputs(c1, run, store)
    run["cartridges"][0]["attempts"].append({"status": "done", "outputs": files})
    delivered = ms.prepare_files(c2, run, store)
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    assert not missing and files[0]["bytes"] == 48 * 1024 * 1024 and delivered[0]["verified"] is True
    assert delivered[0]["sha256"] == files[0]["sha256"]
    assert peak < 8 * 1024 * 1024, peak                                         # 0.2.0 read the whole file


# ====================================================================== D. filesystem (unprivileged user)

PROBE = """
    import os, sys, json
    work, here = sys.argv[1:3]
    r = {}
    def attempt(name, fn):
        try: fn(); r[name] = "ok"
        except OSError as e: r[name] = type(e).__name__
    j = os.path.join
    attempt("rename_earlier_cartridge", lambda: os.rename(j(work, "c1"), j(work, "c1_moved")))
    attempt("create_folder_in_run", lambda: os.mkdir(j(work, "c12_hud")))
    attempt("create_file_in_run", lambda: open(j(work, "x"), "w").write("x"))
    attempt("remove_ledger", lambda: os.remove(j(work, "LEDGER.md")))
    attempt("replace_ledger", lambda: os.rename(j(work, "LEDGER.md"), j(work, "L2")))
    attempt("append_ledger", lambda: open(j(work, "LEDGER.md"), "a").write("x"))
    attempt("read_ledger", lambda: open(j(work, "LEDGER.md")).read())
    attempt("list_run", lambda: os.listdir(work))
    attempt("read_earlier_output", lambda: open(j(work, "c1", "outputs", "f.txt")).read())
    attempt("create_in_earlier_cartridge", lambda: open(j(work, "c1", "x"), "w").write("x"))
    attempt("create_in_earlier_outputs", lambda: open(j(work, "c1", "outputs", "x"), "w").write("x"))
    attempt("rename_earlier_outputs", lambda: os.rename(j(work, "c1", "outputs"), j(work, "c1", "o2")))
    attempt("remove_earlier_output", lambda: os.remove(j(work, "c1", "outputs", "f.txt")))
    attempt("notes_in_own_cartridge", lambda: open(j(here, "NOTES.md"), "w").write("n"))
    attempt("write_own_output", lambda: open(j(here, "outputs", "g.txt"), "w").write("g"))
    attempt("read_own_input", lambda: open(j(here, "inputs", "c1", "f.txt")).read())
    attempt("rename_own_inputs", lambda: os.rename(j(here, "inputs"), j(here, "i2")))
    attempt("run_a_command", lambda: os.system("ls " + here + " > /dev/null") and None)
    print(json.dumps(r))
"""

EXPECTED = {
    "rename_earlier_cartridge": "PermissionError", "create_folder_in_run": "PermissionError",
    "create_file_in_run": "PermissionError", "remove_ledger": "PermissionError",
    "replace_ledger": "PermissionError", "append_ledger": "PermissionError", "read_ledger": "ok",
    "list_run": "ok", "read_earlier_output": "ok", "create_in_earlier_cartridge": "PermissionError",
    "create_in_earlier_outputs": "PermissionError", "rename_earlier_outputs": "PermissionError",
    "remove_earlier_output": "PermissionError", "notes_in_own_cartridge": "ok", "write_own_output": "ok",
    "read_own_input": "ok", "rename_own_inputs": "PermissionError", "run_a_command": "ok",
}


def _mid_run(module, root):
    """c1 finished (its file written by the Terminal user), c2 set up and 'running'."""
    library = root / "library"
    write_workflow(library / "w", [
        {"id": "c1", "prompt": "a", "artifacts": {"outputs": ["f.txt"]}},
        {"id": "c2", "prompt": "b", "artifacts": {"inputs": [{"from": "c1", "path": "f.txt"}],
                                                   "outputs": ["g.txt"]}}])
    store = module.Store(root / "data", root / "work")
    run = module.new_run(store, "u1", library, "w", {"worker": "m"}, [], None)
    c1, c2 = module.load_workflow(store.run_dir("u1", run["id"]) / "workflow")["cartridges"]
    module.prepare_files(c1, run, store)
    work = store.work_dir(run["id"])
    wrote = _as_terminal("import sys; open(sys.argv[1], 'w').write('original')", work / "c1" / "outputs" / "f.txt")
    assert wrote.returncode == 0, wrote.stderr
    files, _ = module.collect_outputs(c1, run, store)
    run["cartridges"][0].update(status="done", attempts=[{"status": "done", "model": "m", "outputs": files}])
    if hasattr(module, "seal_cartridge"):
        module.seal_cartridge(c1, run, store)
    store.save(run)
    module.prepare_files(c2, run, store)
    return store, run, work, c2


@needs_root
def test_the_terminal_user_cannot_alter_what_magazine_owns_and_can_still_work(shared_tmp):
    store, run, work, _ = _mid_run(ms, shared_tmp)
    done = _as_terminal(PROBE, work, work / "c2")
    assert done.returncode == 0, done.stderr
    assert json.loads(done.stdout) == EXPECTED
    # effective modes, read back from the filesystem rather than trusted from chmod
    modes = {p: stat.S_IMODE(os.lstat(work / p).st_mode) for p in (".", "LEDGER.md", "c1", "c1/outputs", "c2",
                                                                    "c2/outputs")}
    assert modes == {".": 0o755, "LEDGER.md": 0o644, "c1": 0o755, "c1/outputs": 0o755, "c2": 0o1777,
                     "c2/outputs": 0o777}
    assert os.lstat(work).st_uid == 0 and os.lstat(work / "LEDGER.md").st_uid == 0
    assert (work / "LEDGER.md").read_text() == ms.render_ledger(store.load("u1", run["id"]))
    os.rename(work / "c2", work / "c2~attempt1")                    # Magazine's own restart still works


@needs_root
def test_the_same_probe_succeeds_against_the_installed_ui_candidate(shared_tmp):
    """Reproduction of the weakness on the unmodified 0.2.0-ui.1 source (set MAGAZINE_BASELINE to its
    magazine_simple.py). The earlier cartridge folder can be renamed, new folders planted, the ledger removed."""
    baseline = os.environ.get("MAGAZINE_BASELINE") or str(
        Path(__file__).resolve().parents[2] / "Magazine-Simple-0.2.0-ui-candidate" / "magazine_simple.py")
    if not Path(baseline).is_file():
        pytest.skip("0.2.0-ui.1 source not found (set MAGAZINE_BASELINE): the reproduction was not run")
    import importlib.util
    spec = importlib.util.spec_from_file_location("ms_baseline", baseline)
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    assert old.VERSION == "0.2.0-ui.1"
    _, _, work, _ = _mid_run(old, shared_tmp)
    done = _as_terminal(PROBE, work, work / "c2")
    r = json.loads(done.stdout)
    assert r["rename_earlier_cartridge"] == "ok" and r["create_folder_in_run"] == "ok"
    assert r["create_file_in_run"] == "ok" and r["remove_ledger"] == "ok"
    assert r["notes_in_own_cartridge"] == "PermissionError"         # and the audit's finding, the other way round


@needs_root
def test_a_file_the_terminal_owns_can_still_be_edited_and_the_handover_refuses_it(shared_tmp):
    """The stated limit of permissions: every cartridge's Terminal is the same user, so a later cartridge can
    edit a file an earlier one created. Permissions cannot stop that; the hash check does."""
    store, run, work, c2 = _mid_run(ms, shared_tmp)
    edit = _as_terminal("import sys; open(sys.argv[1], 'w').write('tampered')", work / "c1" / "outputs" / "f.txt")
    assert edit.returncode == 0
    with pytest.raises(ms.MagazineError, match="changed after c1 finished"):
        ms.prepare_files(c2, run, store)


@needs_root
def test_where_permissions_do_not_apply_the_ledger_is_not_written_through_a_planted_link(shared_tmp, monkeypatch):
    """A mount that ignores chmod (the run folder stays world-writable): the Terminal replaces LEDGER.md with a
    link to a file only Magazine may write. 0.2.0 would write the ledger into that file."""
    store, run, work, _ = _mid_run(ms, shared_tmp)
    victim = shared_tmp / "data" / "victim.db"
    victim.write_text("precious", encoding="utf-8")
    real_chmod = os.chmod
    monkeypatch.setattr(os, "chmod", lambda path, mode, **kw: None if Path(path) == work else real_chmod(path, mode))
    real_chmod(work, 0o777)                                           # as such a mount would present it
    planted = _as_terminal("import os, sys; os.remove(sys.argv[1]); os.symlink(sys.argv[2], sys.argv[1])",
                           work / "LEDGER.md", victim)
    assert planted.returncode == 0 and (work / "LEDGER.md").is_symlink()
    store.save(run)
    assert victim.read_text() == "precious"
    assert not (work / "LEDGER.md").is_symlink() and (work / "LEDGER.md").read_text().startswith("# Ledger:")
    assert not [p for p in work.iterdir() if p.name.endswith(".tmp")]
    assert ms._others_can_rename_in(work) is True


def test_the_ledger_says_so_when_the_permissions_did_not_take_effect(env, monkeypatch):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "a"}])
    run, _, _ = run_line(env, lambda p, b: saved([msg(DONE)]), workflow="w")
    assert "warning" not in run and "**Work folder:**" not in ms.render_ledger(run)
    real_chmod = os.chmod
    monkeypatch.setattr(ms.os, "chmod", lambda path, mode, **kw: real_chmod(path, 0o777))   # a mount that reports 777
    run, _, _ = run_line(env, lambda p, b: saved([msg(DONE)]), workflow="w")
    assert run["status"] == "completed"
    assert "lets other users rename or replace entries in the run folder" in run["warning"]
    assert "- **Work folder:** this filesystem lets other users" in (
        env.store.work_dir(run["id"]) / "LEDGER.md").read_text()


def test_a_planted_cartridge_folder_link_is_refused(env):
    nebula(env.library / "nebula", ids=("c10", "c11"))
    elsewhere = env.tmp / "elsewhere"
    elsewhere.mkdir()

    def brain(prompt, body):
        write_game(prompt, "<html>ok</html>")
        os.symlink(elsewhere, Path(env.store.work_dir(run_id["id"])) / "c11")       # worst case: it could
        return saved([msg(DONE)])

    run_id = {}
    real = ms.new_run
    fake = FakeOpenWebUI(brain)
    engine = make_engine(env, fake)
    run = real(env.store, "u1", env.library, "nebula", {"worker": "m"}, [], None)
    run_id["id"] = run["id"]
    run = asyncio.run(run_to_end(engine, run))
    a = run["cartridges"][1]["attempts"][0]
    assert a["status"] == "failed" and "is a link; Magazine did not make it" in a["note"]
    assert list(elsewhere.iterdir()) == [] and len(fake.chats) == 1


# ====================================================================== E. export

def test_the_download_holds_the_workflow_and_the_exact_prompts_and_no_credentials(env):
    nebula(env.library / "nebula", ids=("c10", "c11"))

    def brain(prompt, body):
        write_game(prompt, "<html>ok</html>")
        return saved([msg(DONE)])

    fake = FakeOpenWebUI(brain)
    engine = ms.Engine(env.store, env.library,
                       lambda token: ms.OpenWebUI("http://owui", token, transport=httpx.MockTransport(fake.handler)))
    run = ms.new_run(env.store, "u1", env.library, "nebula", {"worker": "model-x"}, ["dev"], "open-terminal")
    run = asyncio.run(run_to_end(engine, run, token="sk-SECRET-TOKEN", params={"system": "PRIVATE SYSTEM PROMPT"}))
    data = ms.build_download(env.store, run)
    archive = zipfile.ZipFile(io.BytesIO(data))
    names = set(archive.namelist())
    assert {"LEDGER.md", "run.json", "workflow/magazine.yaml", "workflow/cartridges/c10.md",
            "workflow/cartridges/c11.md", "results/01-c10.md", "results/01-c10.prompt.md",
            "results/02-c11.md", "results/02-c11.prompt.md", f"work/c11/inputs/c10/{HTML}"} <= names
    prompts = sent_prompts(fake)
    assert archive.read("results/01-c10.prompt.md").decode() == prompts[0]
    assert archive.read("results/02-c11.prompt.md").decode() == prompts[1]
    assert archive.read("workflow/cartridges/c11.md").decode() == f"# TASK\nBuild c11.\n\n# OUTPUT\nSave `{HTML}`."
    record = json.loads(archive.read("run.json"))
    assert record["cartridges"][0]["model"] == "model-x" and record["tool_ids"] == ["dev"]
    assert record["terminal_id"] == "open-terminal"
    everything = b"".join(archive.read(n) for n in names)
    assert b"sk-SECRET-TOKEN" not in everything and b"PRIVATE SYSTEM PROMPT" not in everything
    assert b"Authorization" not in everything
