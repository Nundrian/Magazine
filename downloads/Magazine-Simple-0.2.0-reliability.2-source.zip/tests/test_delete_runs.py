"""0.2.0-exec.4: deleting previous work (one, a selection, or all). Simulated: fake Open WebUI, no model."""
import asyncio
import os
import sys
import types

import pytest

from conftest import RAW
from test_execution_audit import shared_tmp  # noqa: F401
from test_magazine_simple import (FakeOpenWebUI, env, make_engine, ms, run_to_end, save_dir,  # noqa: F401
                                  write_workflow)

DONE = ms.DONE_LINE


def finished_run(env, engine=None, fail_second=False):
    if not (env.library / "w").exists():
        write_workflow(env.library / "w", [
            {"id": "c1", "prompt": "a", "artifacts": {"outputs": ["f.txt"]}},
            {"id": "c2", "prompt": "b", "artifacts": {"inputs": [{"from": "c1", "path": "f.txt"}], "outputs": ["g.txt"]}}])

    def brain(prompt, body):
        if prompt.startswith("b") and fail_second:
            return RAW(content="Let me now", done=True)
        (save_dir(prompt) / ("f.txt" if prompt.startswith("a") else "g.txt")).write_text("x", encoding="utf-8")
        return "ok"

    fake = FakeOpenWebUI(brain)
    engine = engine or make_engine(env, fake)
    engine.client_factory = lambda token: fake.client()
    run = asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    return run, engine, fake


def places(env, run):
    return env.store.run_dir("u1", run["id"]), env.store.work_dir(run["id"])


def test_deleting_a_run_removes_its_record_and_work_and_nothing_else(env):
    keep, engine, _ = finished_run(env)
    gone, _, fake = finished_run(env, engine, fail_second=True)
    gone = asyncio.run(run_to_end(engine, gone, start=1))                    # a retry, so an ~attempt folder exists
    record, work = places(env, gone)
    assert (work.parent / gone["id"] / "c2~attempt1").is_dir() and (record / "results" / "02-c2~attempt1.md").is_file()
    assert ms.delete_run(env.store, engine, "u1", gone["id"]) == {"deleted": gone["id"]}
    assert not record.exists() and not work.exists()
    with pytest.raises(ms.MagazineError, match="Run not found"):
        env.store.load("u1", gone["id"])
    kept_record, kept_work = places(env, keep)
    assert (kept_record / "run.json").is_file() and (kept_work / "c2" / "outputs" / "g.txt").read_text() == "x"
    assert [r["id"] for r in env.store.runs("u1")] == [keep["id"]]
    assert (env.library / "w" / "magazine.yaml").is_file()                   # the workflow is not touched
    assert not any(method == "DELETE" for method, _ in fake.requests)        # Magazine never deletes chats
    assert sorted(p.name for p in env.store.workspace_root.iterdir()) == [keep["id"]]


def test_a_running_or_waiting_run_is_refused_and_left_whole(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "a"}])
    engine = make_engine(env, FakeOpenWebUI(lambda p, b: "x", busy_polls=10 ** 9))
    first = ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)
    second = ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)

    async def scenario():
        assert engine.start(first, "tok", {}) is None and engine.start(second, "tok", {}) == 1
        await asyncio.sleep(0.05)
        for run in (first, second):
            with pytest.raises(ms.MagazineError, match="running or waiting") as info:
                ms.delete_run(env.store, engine, "u1", run["id"])
            assert info.value.status_code == 409
            assert (places(env, run)[0] / "run.json").is_file() and places(env, run)[1].is_dir()
        engine.dequeue(env.store.load("u1", second["id"]))
        engine.stop(first["id"])
        await engine.active[first["id"]]
    asyncio.run(scenario())
    for run in (first, second):                                              # stopped / back to ready: now allowed
        assert ms.delete_run(env.store, engine, "u1", run["id"]) == {"deleted": run["id"]}
    assert env.store.runs("u1") == []


@pytest.mark.parametrize("bad", ["../../etc", "..", "", "no-such-run", "a/b", 7, None, {"id": "x"}])
def test_bad_ids_delete_nothing(env, bad):
    run, engine, _ = finished_run(env)
    outside = env.tmp / "outside.txt"
    outside.write_text("keep", encoding="utf-8")
    with pytest.raises(ms.MagazineError, match="Run not found"):
        ms.delete_run(env.store, engine, "u1", bad)
    assert (places(env, run)[0] / "run.json").is_file() and places(env, run)[1].is_dir() and outside.read_text() == "keep"


def test_another_persons_run_cannot_be_deleted(env):
    run, engine, _ = finished_run(env)
    with pytest.raises(ms.MagazineError, match="Run not found"):
        ms.delete_run(env.store, engine, "someone-else", run["id"])
    assert (places(env, run)[0] / "run.json").is_file() and places(env, run)[1].is_dir()


def test_a_work_folder_replaced_by_a_link_is_unlinked_not_followed(env):
    run, engine, _ = finished_run(env)
    record, work = places(env, run)
    precious = env.tmp / "precious"
    precious.mkdir()
    (precious / "keep.txt").write_text("keep", encoding="utf-8")
    os.rename(work, work.with_name("moved-aside"))
    os.symlink(precious, work)
    os.symlink(precious, work.with_name("moved-aside") / "c1" / "outputs" / "link-inside")
    ms.delete_run(env.store, engine, "u1", run["id"])
    assert not work.exists() and not work.is_symlink() and not record.exists()
    assert (precious / "keep.txt").read_text() == "keep"


def test_delete_routes_selected_and_all(env, monkeypatch):
    fastapi = pytest.importorskip("fastapi")
    from fastapi.testclient import TestClient
    user = types.SimpleNamespace(id="u1", role="user", settings={})
    auth = types.ModuleType("open_webui.utils.auth")
    auth.get_current_user = lambda: user
    config = types.ModuleType("open_webui.config")
    config.DATA_DIR = str(env.tmp / "data")
    for name, module in (("open_webui", types.ModuleType("open_webui")), ("open_webui.utils", types.ModuleType("open_webui.utils")),
                         ("open_webui.utils.auth", auth), ("open_webui.config", config)):
        monkeypatch.setitem(sys.modules, name, module)
    monkeypatch.setitem(ms._STATE, "engine", None)
    app = fastapi.FastAPI()
    event = ms.Event()
    event.valves.library_root, event.valves.workspace_root = str(env.library), str(env.tmp / "work")
    asyncio.run(event.event(__app__=app))
    engine = ms._STATE["engine"]
    env.store = engine.store
    runs = [finished_run(env, engine)[0] for _ in range(4)]
    mine = [r["id"] for r in runs]
    other = ms.new_run(engine.store, "u2", env.library, "w", {"worker": "m"}, [], None)       # someone else's
    api = TestClient(app)
    url = "/api/magazine-simple/runs/delete"
    assert api.post(url, json={}).status_code == 400 and api.post(url, json={"ids": []}).status_code == 400
    r = api.post(url, json={"ids": [mine[0], "nope", other["id"], "../x"]}).json()
    assert r["deleted"] == [mine[0]] and [f["id"] for f in r["failed"]] == ["nope", other["id"], "../x"]
    assert sorted(x["id"] for x in api.get("/api/magazine-simple/runs").json()["runs"]) == sorted(mine[1:])
    assert api.get(f"/api/magazine-simple/runs/{mine[0]}").status_code == 404
    assert api.get(f"/api/magazine-simple/runs/{mine[0]}/download").status_code == 404
    assert api.post(url, json={"ids": [mine[1]]}).json() == {"deleted": [mine[1]], "failed": []}
    r = api.post(url, json={"all": True}).json()
    assert sorted(r["deleted"]) == sorted(mine[2:]) and r["failed"] == []
    assert api.get("/api/magazine-simple/runs").json()["runs"] == []
    assert (engine.store.run_dir("u2", other["id"]) / "run.json").is_file()                    # untouched throughout
    assert engine.store.work_dir(other["id"]).is_dir()
    assert api.get("/api/magazine-simple/workflows").json()["workflows"][0]["id"] == "w"


# ---------------------------------------------------------------- final review, 0.2.0-exec.5

def test_a_deletion_that_fails_partway_is_reported_and_can_be_retried(env, monkeypatch):
    """A file that cannot be removed (for example one held open on a Windows bind mount): the run must stay
    listed, with its record, so the deletion can be repeated; nothing may claim success."""
    run, engine, _ = finished_run(env)
    record, work = places(env, run)
    real_rmtree = ms.shutil.rmtree
    stuck = {"on": "work"}

    def rmtree(path, *a, **k):
        from pathlib import Path
        p = Path(path)
        if stuck["on"] == "work" and p == work:
            real_rmtree(work / "c1")                                  # some of it goes, then a file refuses
            raise PermissionError(13, "Permission denied", str(work / "c2" / "outputs" / "g.txt"))
        if stuck["on"] == "record" and p.parent == record:
            raise OSError(16, "Device or resource busy", str(p))
        return real_rmtree(path, *a, **k)

    monkeypatch.setattr(ms.shutil, "rmtree", rmtree)
    with pytest.raises(OSError):
        ms.delete_run(env.store, engine, "u1", run["id"])
    assert (record / "run.json").is_file() and [r["id"] for r in env.store.runs("u1")] == [run["id"]]
    stuck["on"] = "record"                                            # the work folder goes, the record sticks
    with pytest.raises(OSError):
        ms.delete_run(env.store, engine, "u1", run["id"])
    assert not work.exists()
    assert (record / "run.json").is_file() and [r["id"] for r in env.store.runs("u1")] == [run["id"]]
    stuck["on"] = None
    assert ms.delete_run(env.store, engine, "u1", run["id"]) == {"deleted": run["id"]}
    assert not record.exists() and env.store.runs("u1") == []


def test_the_route_reports_a_failed_deletion_as_failed(env, monkeypatch):
    run, engine, _ = finished_run(env)
    keep, _, _ = finished_run(env, engine)
    record, work = places(env, run)

    def refuse(path, *a, **k):
        raise PermissionError(13, "Permission denied", str(path))
    real = ms.shutil.rmtree
    monkeypatch.setattr(ms.shutil, "rmtree", lambda p, *a, **k: refuse(p) if str(p).startswith(str(work)) else real(p, *a, **k))
    done, failed = [], []
    for rid in (run["id"], keep["id"]):                               # what the route does for {"all": true}
        try:
            done.append(ms.delete_run(env.store, engine, "u1", rid)["deleted"])
        except OSError as exc:
            failed.append((rid, str(exc)))
    assert done == [keep["id"]] and [f[0] for f in failed] == [run["id"]] and "Permission denied" in failed[0][1]
    assert (record / "run.json").is_file() and work.is_dir()


def test_a_run_finished_with_an_inline_done_is_deleted_like_any_other(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "a", "artifacts": {"outputs": ["f.txt"]}}])

    def brain(prompt, body):
        (save_dir(prompt) / "f.txt").write_text("x", encoding="utf-8")
        return RAW(content="The file is saved. " + DONE, done=True)

    engine = make_engine(env, FakeOpenWebUI(brain))
    engine.require_done = True
    run = asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    assert run["status"] == "completed"
    again = asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    ms.delete_run(env.store, engine, "u1", run["id"])
    assert [r["id"] for r in env.store.runs("u1")] == [again["id"]] and places(env, again)[1].is_dir()
    assert asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))["status"] == "completed"


def test_rmtree_is_the_link_safe_implementation_here():
    import shutil
    assert shutil.rmtree.avoids_symlink_attacks


def test_magazine_removes_sealed_and_terminal_owned_folders_and_the_terminal_cannot(shared_tmp):  # noqa: F811
    """Real Linux filesystem, Magazine as root, the Terminal as an unprivileged user: a finished cartridge's
    folder is sealed (0755 root) and holds a file the Terminal owns. The Terminal cannot remove the run folder;
    Magazine's deletion removes all of it."""
    from test_completion import _mid_run
    from test_execution_audit import _as_terminal
    if not hasattr(os, "geteuid") or os.geteuid() != 0:
        pytest.skip("needs root to switch user")
    store, run, work, _ = _mid_run(ms, shared_tmp)
    assert os.lstat(work / "c1" / "outputs" / "f.txt").st_uid != 0                      # the Terminal's own file
    tried = _as_terminal("import shutil, sys\ntry:\n shutil.rmtree(sys.argv[1]); print('removed')\n"
                         "except OSError as e: print(type(e).__name__)", work)
    assert tried.stdout.strip() == "PermissionError" and (work / "LEDGER.md").is_file() and (work / "c1").is_dir()
    engine = ms.Engine(store, shared_tmp / "library", None)
    assert ms.delete_run(store, engine, "u1", run["id"]) == {"deleted": run["id"]}
    assert not work.exists() and not store.run_dir("u1", run["id"]).exists()
    assert list(store.workspace_root.iterdir()) == []
