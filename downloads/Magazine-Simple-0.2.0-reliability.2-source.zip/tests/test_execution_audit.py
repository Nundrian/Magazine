"""Execution-architecture audit tests for Magazine Simple.

Everything here runs against a *fake* Open WebUI and a *scripted* "model" (the `brain`
callbacks). No language model and no real Terminal are involved: where a test says a model
"ran a command", the brain performed the equivalent file operation itself. The sequence is
reconstructed from the live Qwen3.8 run 20261111-050908-251fe1 (chat cf73cb0c, cartridge
c05_effects, which opened with list_files, an `ls` of the run folder polled with
get_process_status, and a read of LEDGER.md).
"""
import asyncio
import hashlib
import io
import json
import os
import stat
import subprocess
import sys
import tempfile
import textwrap
import zipfile
from pathlib import Path

import pytest

from test_magazine_simple import (FakeOpenWebUI, env, make_engine, ms, run_to_end, save_dir,  # noqa: F401
                                  write_workflow)

WORK_METHOD = ("# WORK METHOD — Qwen3.8 with 64K context\nKeep this TASK and SUCCESS CONDITION authoritative. "
               "Work in a staging file in this cartridge's output directory. Move or copy the staged result to the "
               "required OUTPUT path only after the available checks. If blocked return "
               "{\"status\":\"HALT\",\"reason\":\"...\"}.")
HTML = "web/nebula-run.html"


def nebula_workflow(root):
    """c04 -> c04b -> c05 -> c06, one shared file handed on, as in the Nebula run."""
    def step(cid, prev, prompt):
        c = {"id": cid, "prompt": f"# TASK\n{prompt}\n\n{WORK_METHOD}\n\n# OUTPUT\nSave `{HTML}`.",
             "artifacts": {"outputs": [HTML]}}
        if prev:
            c["artifacts"]["inputs"] = [{"from": prev, "path": HTML}]
        return c
    return write_workflow(root, [step("c04_weapons", None, "weapons"),
                                 step("c04b_weapon_smoke", "c04_weapons", "smoke"),
                                 step("c05_effects", "c04b_weapon_smoke", "effects"),
                                 step("c06_starfield", "c05_effects", "starfield")], name="Nebula Run")


def message(text):
    return {"type": "message", "content": [{"type": "output_text", "text": text}]}


def tool_items(call_id, name, args, result):
    return [{"type": "reasoning", "content": [{"text": "Thinking about it"}]},
            {"type": "function_call", "name": name, "arguments": json.dumps(args), "call_id": call_id},
            {"type": "function_call_output", "call_id": call_id,
             "output": [{"type": "input_text", "text": json.dumps(result)}]}]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# --------------------------------------------------------------------------- 1, 2, 4, 5, 8

def test_c04b_to_c05_sequence_ledger_siblings_and_polled_command(env):
    nebula_workflow(env.library / "nebula")
    seen = {}

    def brain(prompt, body):
        out = save_dir(prompt)
        cid = out.parent.name
        if cid in ("c04_weapons", "c04b_weapon_smoke"):
            (out / "web").mkdir(parents=True, exist_ok=True)
            (out / HTML).write_text("<html>weapons v1</html>", encoding="utf-8")
            if cid == "c04b_weapon_smoke":   # an undeclared notes file, as in the live run
                (out / "weapon_smoke_notes.md").write_text("No defect found.", encoding="utf-8")
            return f"{cid} finished."
        if cid == "c06_starfield":
            (out / "web").mkdir(parents=True, exist_ok=True)
            (out / HTML).write_text("<html>c06</html>", encoding="utf-8")
            return "c06 finished."
        # c05_effects: the sequence the live model performed
        run_dir = out.parent.parent
        seen["own_dir"] = sorted(p.name for p in out.parent.iterdir())
        seen["input"] = (out.parent / "inputs" / "c04b_weapon_smoke" / HTML).read_text(encoding="utf-8")
        seen["run_listing"] = sorted(p.name for p in run_dir.iterdir())          # `ls -la <run>/`
        seen["ledger"] = (run_dir / "LEDGER.md").read_text(encoding="utf-8")      # read_file LEDGER.md
        seen["sibling_notes"] = (run_dir / "c04b_weapon_smoke" / "outputs" / "weapon_smoke_notes.md").read_text()
        seen["sibling_out"] = (run_dir / "c04b_weapon_smoke" / "outputs" / HTML).read_bytes()
        (out / "_work").mkdir(parents=True, exist_ok=True)                          # staging inside outputs/
        (out / "_work" / "staged.html").write_text(seen["input"] + "<!-- effects -->", encoding="utf-8")
        (out / "web").mkdir(parents=True, exist_ok=True)
        (out / HTML).write_text((out / "_work" / "staged.html").read_text(encoding="utf-8"), encoding="utf-8")
        ls = {"id": "20261111-141035-fb282d", "status": "running", "exit_code": None}
        done = {"id": "20261111-141035-fb282d", "status": "done", "exit_code": 0}
        items = (tool_items("a", "run_command", {"command": "ls -la <run>/"}, ls)
                 + tool_items("b", "get_process_status", {"process_id": ls["id"], "wait": "10"}, done)
                 + [message("Let me look at the sibling cartridges."), message("Done. web/nebula-run.html saved.")])
        return {"content": "Let me look at the sibling cartridges.\nDone. web/nebula-run.html saved.",
                "output": items, "done": True}

    fake = FakeOpenWebUI(brain, busy_polls=3)
    engine = make_engine(env, fake)
    models = {"c04_weapons": "m-a", "c04b_weapon_smoke": "m-b", "c05_effects": "m-c", "c06_starfield": "m-d"}
    run = ms.new_run(env.store, "u1", env.library, "nebula", models, ["dev"], "open-terminal")
    run = asyncio.run(run_to_end(engine, run))

    assert run["status"] == "completed"
    # 2: the model could read its input, the run folder, the ledger and a sibling's declared and undeclared files
    assert seen["input"] == "<html>weapons v1</html>"
    assert {"LEDGER.md", "c04_weapons", "c04b_weapon_smoke", "c05_effects"} <= set(seen["run_listing"])
    assert "c06_starfield" not in seen["run_listing"]            # later cartridges have not been set up yet
    assert seen["own_dir"] == ["inputs", "outputs"]
    assert seen["sibling_notes"] == "No defect found."
    # the ledger it read was written *before* dispatch and shows c05 running, c04b done
    assert "| 2 | c04b_weapon_smoke | 1 | `m-b` | done |" in seen["ledger"]
    assert "| 3 | c05_effects | 1 | `m-c` | running |" in seen["ledger"]
    # 1/4: one chat per cartridge, one user message each, model chosen per step
    bodies = [fake.chats[f"chat{i}"]["completion"] for i in range(1, 5)]
    assert [b["model"] for b in bodies] == ["m-a", "m-b", "m-c", "m-d"]
    assert all(len(b["messages"]) == 1 and b["messages"][0]["role"] == "user" for b in bodies)
    assert all(b["tool_ids"] == ["dev"] and b["terminal_id"] == "open-terminal" for b in bodies)
    # 5/8: outputs found at the cartridge's own path and hashed; the next cartridge got exactly that file
    c05 = run["cartridges"][2]["attempts"][0]
    out_file = env.store.cartridge_dir(run["id"], "c05_effects") / "outputs" / HTML
    assert c05["outputs"] == [{"path": HTML, "bytes": out_file.stat().st_size, "sha256": sha(out_file)}]
    handed = env.store.cartridge_dir(run["id"], "c06_starfield") / "inputs" / "c05_effects" / HTML
    assert sha(handed) == sha(out_file)
    # the chain of provenance in the ledger
    ledger = (env.store.work_dir(run["id"]) / "LEDGER.md").read_text(encoding="utf-8")
    assert f"({out_file.stat().st_size} B, {sha(out_file)[:12]})" in ledger
    # tool traffic in the chat is not Magazine's: it only used the chat/task endpoints
    paths = {p for _, p in fake.requests}
    assert not any("terminal" in p or "process" in p for p in paths)


# --------------------------------------------------------------------------- 3, 10 (canonical result)

def test_saved_reply_is_visible_messages_only_never_reasoning_or_tool_output(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "Do it"}])
    items = (tool_items("a", "run_command", {"command": "echo SECRET_TOOL_ARG"}, {"stdout": "SECRET_TOOL_OUT"})
             + [message("Interim note."), message("Final report.")])
    items[0]["content"] = [{"text": "SECRET_REASONING"}]
    # `content` empty: Magazine derives the text from the message items only
    fake = FakeOpenWebUI(lambda p, b: {"content": "", "output": items, "done": True})
    run = asyncio.run(run_to_end(make_engine(env, fake),
                                 ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    text = (env.store.run_dir("u1", run["id"]) / "results" / "01-c1.md").read_text(encoding="utf-8")
    assert text == "Interim note.Final report."
    assert not any(word in text for word in ("SECRET_REASONING", "SECRET_TOOL_ARG", "SECRET_TOOL_OUT"))
    # and the record Magazine keeps (run.json) holds notes and hashes, not the transcript
    blob = (env.store.run_dir("u1", run["id"]) / "run.json").read_text(encoding="utf-8")
    assert "SECRET" not in blob


# --------------------------------------------------------------------------- 7: tool success is not completion

def test_successful_commands_alone_do_not_complete_a_cartridge(env):
    nebula_workflow(env.library / "nebula")
    work_root = env.tmp / "work"                    # the Terminal's cwd is the workspace *above* magazine-simple/

    def brain(prompt, body):
        stray = work_root.parent / "outputs" / "web"      # "outputs/web/nebula-run.html" resolved against cwd
        stray.mkdir(parents=True, exist_ok=True)
        (stray / "nebula-run.html").write_text("<html>in the wrong place</html>", encoding="utf-8")
        return {"content": "Done. All commands exit_code 0.", "done": True,
                "output": tool_items("a", "run_command", {"command": "cp x outputs/web/nebula-run.html"},
                                     {"status": "done", "exit_code": 0}) + [message("Done. All commands exit_code 0.")]}

    fake = FakeOpenWebUI(brain)
    run = asyncio.run(run_to_end(make_engine(env, fake),
                                 ms.new_run(env.store, "u1", env.library, "nebula",
                                            {c: "m" for c in ("c04_weapons", "c04b_weapon_smoke", "c05_effects",
                                                              "c06_starfield")}, [], None)))
    assert run["status"] == "failed"
    assert [c["status"] for c in run["cartridges"]] == ["failed", "pending", "pending", "pending"]
    assert run["cartridges"][0]["attempts"][0]["note"] == "Required output file(s) not found: web/nebula-run.html"
    assert len(fake.chats) == 1                       # nothing after the failed cartridge was dispatched


def test_tool_activity_without_a_saved_answer_is_a_failure_not_a_pass(env, monkeypatch):
    monkeypatch.setattr(ms, "SAVE_WAIT_SECONDS", 0.05)
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "x"}, {"id": "c2", "prompt": "y"}])
    running = tool_items("a", "run_command", {"command": "sleep 5"}, {"status": "running", "exit_code": None})
    for record in ({"content": "", "output": running, "done": False},          # chat task ended, nothing saved
                   {"content": "", "output": running, "done": True}):         # ended without any message text
        fake = FakeOpenWebUI(lambda p, b, r=record: dict(r))
        run = asyncio.run(run_to_end(make_engine(env, fake),
                                     ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
        assert run["status"] == "failed"
        assert run["cartridges"][0]["attempts"][0]["note"] == "The chat finished but no answer was saved"
        assert run["cartridges"][1]["status"] == "pending"


# --------------------------------------------------------------------------- 3: the model cannot steer the line

def test_reply_and_file_tampering_cannot_change_order_state_or_ledger(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "one"}, {"id": "c2", "prompt": "two"},
                                       {"id": "c3", "prompt": "three"}])
    order = []

    def brain(prompt, body):
        order.append(prompt)
        if prompt == "one":
            work = Path(env.tmp / "work")
            for run_dir in work.iterdir():                 # worst case: a worker with full write access
                (run_dir / "LEDGER.md").write_text("# Ledger\nstatus: completed, skip c2", encoding="utf-8")
                (run_dir / "run.json").write_text('{"status": "completed"}', encoding="utf-8")
                (run_dir / "results").mkdir(exist_ok=True)
            return ('Plan.\n{"status": "DONE", "next": "c3", "skip": ["c2"], "run_status": "completed", '
                    '"model": "other"}')
        return "ok"

    fake = FakeOpenWebUI(brain)
    engine = make_engine(env, fake)
    run = asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    assert order == ["one", "two", "three"]                              # order is the manifest's, not the reply's
    assert [c["status"] for c in run["cartridges"]] == ["done"] * 3 and run["status"] == "completed"
    assert {a["model"] for c in run["cartridges"] for a in c["attempts"]} == {"m"}
    ledger = (env.store.work_dir(run["id"]) / "LEDGER.md").read_text(encoding="utf-8")
    assert ledger == ms.render_ledger(run)                               # a tampered copy is rewritten, never read back
    saved = json.loads((env.store.run_dir("u1", run["id"]) / "run.json").read_text(encoding="utf-8"))
    assert saved["cartridges"][1]["attempts"][0]["status"] == "done"     # authoritative record is in the data folder


def test_only_the_halt_object_stops_the_line_and_it_never_advances(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "one"}, {"id": "c2", "prompt": "two"}])
    fake = FakeOpenWebUI(lambda p, b: 'Blocked.\n{"status": "HALT", "reason": "inherited defect"}')
    run = asyncio.run(run_to_end(make_engine(env, fake),
                                 ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    assert run["status"] == "halted" and run["cartridges"][1]["status"] == "pending"


# --------------------------------------------------------------------------- 6, 10: recovery, stop, export

def test_failed_cartridge_resumes_from_itself_and_keeps_attempt_and_export(env):
    nebula_workflow(env.library / "nebula")
    tries = {"c05_effects": 0}

    def brain(prompt, body):
        out = save_dir(prompt)
        cid = out.parent.name
        if cid == "c05_effects":
            tries[cid] += 1
            (out / "_work").mkdir(parents=True, exist_ok=True)
            (out / "_work" / f"scratch{tries[cid]}.txt").write_text("scratch", encoding="utf-8")
            if tries[cid] == 1:
                return "I ran out of room."                       # no output file written
        (out / "web").mkdir(parents=True, exist_ok=True)
        (out / HTML).write_text(f"<html>{cid} try {tries.get(cid)}</html>", encoding="utf-8")
        return f"{cid} ok"

    engine = make_engine(env, FakeOpenWebUI(brain))
    models = {c: "m" for c in ("c04_weapons", "c04b_weapon_smoke", "c05_effects", "c06_starfield")}
    run = asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "nebula", models, [], None)))
    assert [c["status"] for c in run["cartridges"]] == ["done", "done", "failed", "pending"]
    c04b_hash = run["cartridges"][1]["attempts"][0]["outputs"][0]["sha256"]
    run = asyncio.run(run_to_end(engine, run, start=2))
    assert run["status"] == "completed"
    assert run["cartridges"][1]["attempts"][0]["outputs"][0]["sha256"] == c04b_hash      # earlier work untouched
    assert [a["status"] for a in run["cartridges"][2]["attempts"]] == ["failed", "done"]
    work = env.store.work_dir(run["id"])
    assert (work / "c05_effects~attempt1" / "outputs" / "_work" / "scratch1.txt").is_file()
    names = set(zipfile.ZipFile(io.BytesIO(ms.build_download(env.store, run))).namelist())
    assert {"LEDGER.md", "run.json", "results/03-c05_effects.md", "work/c05_effects/outputs/web/nebula-run.html",
            "work/c05_effects~attempt1/outputs/_work/scratch1.txt"} <= names


def test_stop_during_a_long_tool_loop_does_not_advance(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "Long"}, {"id": "c2", "prompt": "Never"}])
    fake = FakeOpenWebUI(lambda p, b: "x", busy_polls=10 ** 9)
    engine = make_engine(env, fake)
    run = ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)

    async def scenario():
        engine.start(run, "tok", {})
        task = engine.active[run["id"]]
        await asyncio.sleep(0.05)
        engine.stop(run["id"])
        await task

    asyncio.run(scenario())
    saved = env.store.load("u1", run["id"])
    assert saved["status"] == "stopped" and saved["cartridges"][1]["status"] == "pending" and len(fake.chats) == 1


# --------------------------------------------------------------------------- 10: page / API

def test_run_api_returns_saved_replies_but_no_transcript(env, monkeypatch):
    """The page shows progress, notes, the ledger and each *saved reply*. It has no feed of reasoning
    or tool calls; those exist only in the Open WebUI chat the "open chat" link points to."""
    page = (Path(ms.__file__).parent / "page.html").read_text(encoding="utf-8")
    for word in ("function_call", "reasoning", "Thinking", "get_process_status", "tool_calls"):
        assert word not in page
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "x"}])
    items = tool_items("a", "run_command", {"command": "rm -rf SECRET"}, {"stdout": "SECRET"}) + [message("Fine.")]
    fake = FakeOpenWebUI(lambda p, b: {"content": "Fine.", "output": items, "done": True})
    run = asyncio.run(run_to_end(make_engine(env, fake),
                                 ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    shown = json.dumps(run)
    assert "SECRET" not in shown and "function_call" not in shown
    assert run["cartridges"][0]["attempts"][0]["chat_id"] == "chat1"      # the way to the full chat stays


# --------------------------------------------------------------------------- permissions (regression for the fix)

def _as_terminal(script, *args):
    """Run python as an unprivileged user, standing in for the Terminal (uid 1000 in the live run)."""
    def demote():
        os.setgroups([])
        os.setgid(65534)
        os.setuid(65534)
    return subprocess.run([sys.executable, "-I", "-c", textwrap.dedent(script), *map(str, args)],
                          preexec_fn=demote, capture_output=True, text=True, timeout=30)


needs_root = pytest.mark.skipif(not hasattr(os, "geteuid") or os.geteuid() != 0, reason="needs root to switch user")


@pytest.fixture
def shared_tmp():
    root = Path(tempfile.mkdtemp(prefix="msaudit-"))
    os.chmod(root, 0o755)
    yield root
    import shutil
    shutil.rmtree(root, ignore_errors=True)


@needs_root
def test_terminal_user_can_use_the_cartridge_folder_but_not_remove_what_magazine_made(shared_tmp):
    """Live evidence (c05, 11 Nov): the cartridge folder was drwxr-xr-x root, so `touch <cartridge>/x` and notes
    in the 'work folder' failed with Permission denied; only outputs/ was drwxrwxrwx."""
    library = shared_tmp / "library"
    write_workflow(library / "nebula", [
        {"id": "c04", "prompt": "a", "artifacts": {"outputs": [HTML]}},
        {"id": "c05", "prompt": "b", "artifacts": {"inputs": [{"from": "c04", "path": HTML}], "outputs": [HTML]}}])
    store = ms.Store(shared_tmp / "data", shared_tmp / "work")
    run = ms.new_run(store, "u1", library, "nebula", {"worker": "m"}, [], None)
    wf = ms.load_workflow(store.run_dir("u1", run["id"]) / "workflow")
    c04, c05 = wf["cartridges"]
    ms.prepare_files(c04, run, store)
    (store.cartridge_dir(run["id"], "c04") / "outputs" / "web").mkdir()
    (store.cartridge_dir(run["id"], "c04") / "outputs" / HTML).write_text("<html>c04</html>")
    store.save(run)
    ms.prepare_files(c05, run, store)
    work = store.work_dir(run["id"])
    here = work / "c05"
    script = """
        import os, sys, json
        here, ledger, sibling_file = sys.argv[1:4]
        r = {}
        def attempt(name, fn):
            try: fn(); r[name] = "ok"
            except OSError as e: r[name] = type(e).__name__
        attempt("write_in_cartridge_folder", lambda: open(os.path.join(here, "NOTES.md"), "w").write("n"))
        attempt("mkdir_in_cartridge_folder", lambda: os.mkdir(os.path.join(here, "notes")))
        attempt("write_outputs", lambda: open(os.path.join(here, "outputs", "x"), "w").write("x"))
        attempt("rename_outputs", lambda: os.rename(os.path.join(here, "outputs"), os.path.join(here, "outputs2")))
        attempt("rename_inputs", lambda: os.rename(os.path.join(here, "inputs"), os.path.join(here, "inputs2")))
        attempt("remove_outputs_dir", lambda: os.rmdir(os.path.join(here, "outputs")))
        attempt("write_ledger", lambda: open(ledger, "a").write("x"))
        attempt("read_ledger", lambda: open(ledger).read())
        attempt("read_sibling_output", lambda: open(sibling_file).read())
        attempt("read_own_input", lambda: open(os.path.join(here, "inputs", "c04", "web", "nebula-run.html")).read())
        print(json.dumps(r))
    """
    done = _as_terminal(script, here, work / "LEDGER.md", work / "c04" / "outputs" / HTML)
    assert done.returncode == 0, done.stderr
    r = json.loads(done.stdout)
    assert r["write_in_cartridge_folder"] == "ok" and r["mkdir_in_cartridge_folder"] == "ok"   # the fix
    assert r["write_outputs"] == "ok"
    assert r["rename_outputs"] == "PermissionError" and r["rename_inputs"] == "PermissionError"   # sticky bit
    assert r["remove_outputs_dir"] == "PermissionError"
    assert r["write_ledger"] == "PermissionError" and r["read_ledger"] == "ok"
    assert r["read_sibling_output"] == "ok" and r["read_own_input"] == "ok"            # legitimate access kept
    assert stat.S_IMODE(here.stat().st_mode) == 0o1777
    # Magazine itself is unaffected: it can still collect the output and re-run (rename to ~attempt)
    os.rename(here, work / "c05~attempt1")


# --------------------------------------------------------------------------- known limitations (not fixed)

def test_handover_detects_a_changed_earlier_output(env, monkeypatch):
    write_workflow(env.library / "w", [
        {"id": "c1", "prompt": "a", "artifacts": {"outputs": ["f.txt"]}},
        {"id": "c2", "prompt": "b", "artifacts": {"inputs": [{"from": "c1", "path": "f.txt"}], "outputs": ["g.txt"]}}])

    def brain(prompt, body):
        out = save_dir(prompt)
        (out / ("f.txt" if prompt.startswith("a") else "g.txt")).write_text("original", encoding="utf-8")
        return "ok"

    real = ms.prepare_files

    def tampering(cartridge, run, store):
        if cartridge["id"] == "c2":     # something edits c1's finished output before c2 is set up
            (store.cartridge_dir(run["id"], "c1") / "outputs" / "f.txt").write_text("tampered", encoding="utf-8")
        return real(cartridge, run, store)

    monkeypatch.setattr(ms, "prepare_files", tampering)
    run = asyncio.run(run_to_end(make_engine(env, FakeOpenWebUI(brain)),
                                 ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    assert run["cartridges"][1]["status"] == "failed"


def test_halt_quoted_in_interim_narration_does_not_halt(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "a"}, {"id": "c2", "prompt": "b"}])
    reply = 'If blocked I would return:\n{"status":"HALT","reason":"example"}\nNot blocked. Finished.'
    run = asyncio.run(run_to_end(make_engine(env, FakeOpenWebUI(lambda p, b: reply)),
                                 ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    # 0.2.0-exec.1: the closing line decides. With the require_done_line valve off there is no closing line,
    # and a HALT object on its own line in a reply saved without Open WebUI's item list still halts, as in
    # 0.2.0 (the saved-chat form of this case, with real items, is in test_completion.py and passes either way).
    assert run["status"] == ("completed" if ms.REQUIRE_DONE else "halted")


@needs_root
def test_terminal_user_cannot_rename_an_earlier_cartridge_folder(shared_tmp):
    library = shared_tmp / "library"
    write_workflow(library / "w", [{"id": "c1", "prompt": "a", "artifacts": {"outputs": ["o"]}}, {"id": "c2", "prompt": "b"}])
    store = ms.Store(shared_tmp / "data", shared_tmp / "work")
    run = ms.new_run(store, "u1", library, "w", {"worker": "m"}, [], None)
    for c in ms.load_workflow(store.run_dir("u1", run["id"]) / "workflow")["cartridges"]:
        ms.prepare_files(c, run, store)
    work = store.work_dir(run["id"])
    done = _as_terminal("import os,sys\ntry:\n os.rename(sys.argv[1]+'/c1', sys.argv[1]+'/c1_moved'); print('ok')\n"
                        "except OSError as e: print(type(e).__name__)", work)
    assert done.stdout.strip() == "PermissionError"
