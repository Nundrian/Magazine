import asyncio
import errno
import json
from pathlib import Path
import re
import subprocess
import sys

import pytest
import yaml
from conftest import RAW
from test_magazine_simple import env, ms, FakeOpenWebUI, write_workflow, make_engine, run_to_end


def workflow(env, *, outputs=False, retries=0, mode="result_file_v1"):
    steps=[{"id":"p","prompt":"PRODUCER: create a verified result."},
           {"id":"c","prompt":"CONSUMER: use previous result.","handover":[{"from":"p","select":"/result","as":"previous"}]}]
    if outputs:
        steps[0]["artifacts"]={"outputs":["answer.txt"]}
        steps[1]["artifacts"]={"inputs":[{"from":"p","path":"answer.txt"}]}
    root=write_workflow(env.library/"file",steps)
    p=root/"magazine.yaml"
    value=yaml.safe_load(p.read_text())
    value.update(handover_mode=mode,recovery={"max_retries":retries,"seconds":60,"io_retries":2})
    p.write_text(yaml.safe_dump(value))
    return ms.new_run(env.store,"u1",env.library,"file",{"worker":"bonsai-2:27b"},[],None)


def base(prompt):
    return Path(re.search(r"Publish with: python3 (\S+)/publish_result.py",prompt).group(1))


def publish(prompt, *, note="verified", payload=None):
    here=base(prompt)
    args=[sys.executable,str(here/"publish_result.py")]
    if payload is not None:
        p=here/"publish/payload.json"
        p.write_text(json.dumps(payload))
        args += ["--payload-file",str(p)]
    else:
        args += ["--verified","--note",note,"--check","observed check passed"]
    completed=subprocess.run(args,text=True,capture_output=True)
    assert completed.returncode==0,completed.stderr
    return json.loads((here/"publish/result.json").read_text())


def reply(text=None):
    text=ms.DONE_LINE if text is None else text
    return RAW(done=True,content=text,output=[{"type":"message","content":[{"type":"output_text","text":text}]}])


def execute(env,run,brain):
    fake=FakeOpenWebUI(brain)
    engine=make_engine(env,fake)
    result=asyncio.run(run_to_end(engine,run))
    return result,fake,engine


def test_valid_file_malformed_chat_done_commits_and_hands_over(env):
    run=workflow(env)
    received=[]
    def brain(prompt,body):
        if "CONSUMER:" in prompt:
            value=json.loads(prompt.split("previous (from p):\n```json\n",1)[1].split("\n```",1)[0])
            received.append(value)
        publish(prompt,note="exact payload")
        return reply('{"result":{"broken":true}\n'+ms.DONE_LINE)
    result,fake,_=execute(env,run,brain)
    assert result["status"]=="completed" and received[0]["note"]=="exact payload"
    assert len(fake.chats)==2
    attempt=result["cartridges"][0]["attempts"][0]
    assert attempt["phase"]=="committed"
    assert ms.committed_result(env.store,result,"p")["result"]==received[0]
    import zipfile,io
    names=zipfile.ZipFile(io.BytesIO(ms.build_download(env.store,result))).namelist()
    assert any(n.endswith("chat.json") for n in names) and any(n.endswith("commit.json") for n in names)


@pytest.mark.parametrize("failure",["missing","bad_json","pointer"])
def test_publication_recovery_new_chat_new_identity_and_archives(env,failure):
    run=workflow(env,retries=2)
    seen=[]
    def brain(prompt,body):
        here=base(prompt)
        seen.append(json.loads((here/"attempt.json").read_text()))
        if len(seen)==1:
            if failure=="bad_json": (here/"publish/result.json").write_text('{"broken":')
            if failure=="pointer": publish(prompt,payload={"other":7})
        else:
            publish(prompt)
        return reply()
    result,fake,_=execute(env,run,brain)
    assert result["status"]=="completed" and len(fake.chats)==3
    attempts=result["cartridges"][0]["attempts"]
    assert len(attempts)==2 and attempts[1]["kind"]=="publish"
    assert attempts[0]["status"]=="failed" and attempts[1]["status"]=="done"
    assert len({a["attempt_id"] for a in seen})==3 and len({a["chat_id"] for a in seen})==3
    for a in attempts:
        assert (env.store.run_dir("u1",run["id"])/a["chat_archive"]["path"]).is_file()


@pytest.mark.parametrize("key",["run_id","cartridge_id","attempt_id","chat_id"])
def test_wrong_identity_is_hard_failure_without_model_retry(env,key):
    run=workflow(env,retries=2)
    def brain(prompt,body):
        document=publish(prompt)
        document[key]="wrong-attempt"
        (base(prompt)/"publish/result.json").write_text(json.dumps(document))
        return reply()
    result,fake,_=execute(env,run,brain)
    assert len(fake.chats)==1 and result["status"]=="failed"
    assert result["cartridges"][0]["attempts"][0]["code"]=="RESULT_IDENTITY_MISMATCH"
    assert result["cartridges"][1]["status"]=="pending"


def test_missing_done_blocks_valid_file(env):
    run=workflow(env)
    def brain(prompt,body): publish(prompt); return reply("Work finished.")
    result,fake,_=execute(env,run,brain)
    assert len(fake.chats)==1 and result["cartridges"][0]["attempts"][0]["code"]=="DONE_MISSING"


def test_halt_never_retries_or_advances(env):
    run=workflow(env,retries=2)
    def brain(prompt,body): publish(prompt); return reply('{"status":"HALT","reason":"cannot verify"}')
    result,fake,_=execute(env,run,brain)
    assert result["status"]=="halted" and len(fake.chats)==1


def test_missing_output_uses_fresh_repair_and_verified_input_hash(env):
    run=workflow(env,outputs=True,retries=2)
    calls=[]
    def brain(prompt,body):
        calls.append(prompt)
        if len(calls)==2:
            assert '"kind": "repair"' in prompt
            p=Path(re.search(r"Save your output files in: (\S+)",prompt).group(1))
            (p/"answer.txt").write_text("verified answer")
        publish(prompt)
        return reply()
    result,fake,_=execute(env,run,brain)
    assert result["status"]=="completed" and len(fake.chats)==3
    assert result["cartridges"][1]["attempts"][0]["inputs"][0]["verified"] is True


def test_repeated_no_progress_stops_bounded_recovery(env):
    run=workflow(env,retries=5)
    result,fake,_=execute(env,run,lambda p,b:reply())
    assert result["status"]=="failed" and len(fake.chats)==2
    assert result["cartridges"][0]["attempts"][-1]["retry_stopped"]


def test_storage_transient_retries_without_new_model_chat(env,monkeypatch):
    run=workflow(env)
    real=ms.commit_attempt_result
    calls=[]
    def commit(*args):
        calls.append(1)
        if len(calls)==1: raise OSError(errno.EIO,"injected temporary storage failure")
        return real(*args)
    monkeypatch.setattr(ms,"commit_attempt_result",commit)
    def brain(prompt,body): publish(prompt); return reply()
    result,fake,_=execute(env,run,brain)
    assert result["status"]=="completed" and len(fake.chats)==2 and len(calls)==3
    assert len(result["cartridges"][0]["attempts"])==1
    assert result["cartridges"][0]["attempts"][0]["storage_retries"]


@pytest.mark.parametrize("where",["archive","commit"])
def test_storage_permission_failure_never_advances(env,monkeypatch,where):
    run=workflow(env,retries=2)
    def fail(*a): raise PermissionError(errno.EACCES,"injected permission failure")
    monkeypatch.setattr(ms,"archive_attempt_chat" if where=="archive" else "commit_attempt_result",fail)
    def brain(prompt,body): publish(prompt); return reply()
    result,fake,_=execute(env,run,brain)
    assert result["status"]=="failed" and len(fake.chats)==1
    assert result["cartridges"][0]["attempts"][0]["code"]=="STORAGE_FAILED"


def test_crash_after_result_write_before_marker_never_starts_consumer(env,monkeypatch):
    run=workflow(env)
    real=ms.durable_json
    def write(path,value):
        if Path(path).name=="commit.json": raise RuntimeError("injected crash before commit marker")
        return real(path,value)
    monkeypatch.setattr(ms,"durable_json",write)
    def brain(prompt,body): publish(prompt); return reply()
    result,fake,engine=execute(env,run,brain)
    assert result["status"]=="failed" and len(fake.chats)==1
    assert result["cartridges"][0]["attempts"][0]["code"]=="COMMIT_INCOMPLETE"
    with pytest.raises(ms.MagazineError,match="has not completed"):
        engine.start(result,"tok",{},1)


def test_canonical_result_tampering_blocks_consumer(env,monkeypatch):
    run=workflow(env)
    real=ms.seal_cartridge
    def seal(cartridge,record,store):
        real(cartridge,record,store)
        if cartridge["id"]=="p":
            a=record["cartridges"][0]["attempts"][-1]
            p=store.run_dir("u1",record["id"])/a["handover"]["path"]
            value=json.loads(p.read_text()); value["payload"]["result"]["note"]="tampered"
            p.write_text(json.dumps(value))
    monkeypatch.setattr(ms,"seal_cartridge",seal)
    def brain(prompt,body): publish(prompt); return reply()
    result,fake,_=execute(env,run,brain)
    assert result["status"]=="failed" and len(fake.chats)==1
    assert result["cartridges"][1]["attempts"][0]["code"]=="RESULT_COMMIT_MISMATCH"


@pytest.mark.parametrize("kind",["symlink","directory","fifo","oversize","duplicate","nan","tmp_only"])
def test_unsafe_or_invalid_result_is_rejected(tmp_path,kind):
    p=tmp_path/"publish";p.mkdir();f=p/"result.json"
    if kind=="symlink": (tmp_path/"other").write_text('{}');f.symlink_to(tmp_path/"other")
    if kind=="directory": f.mkdir()
    if kind=="fifo":
        import os
        os.mkfifo(f)
    if kind=="oversize": f.write_text('x'*(ms.MAX_RESULT_BYTES+1))
    if kind=="duplicate": f.write_text('{"x":1,"x":2}')
    if kind=="nan": f.write_text('{"x":NaN}')
    if kind=="tmp_only": (p/"result.tmp").write_text('{}')
    with pytest.raises(ms.ResultFailure): ms.read_result_file(tmp_path)


def test_legacy_producer_is_not_done_with_bad_outgoing_json(env):
    run=workflow(env,mode="legacy_chat")
    result,fake,_=execute(env,run,lambda p,b:reply('{"result":{"broken":true}\n'+ms.DONE_LINE))
    assert result["status"]=="failed" and len(fake.chats)==1
    assert result["cartridges"][0]["status"]=="failed"


def test_helper_rejects_invalid_payload_without_publishing(tmp_path):
    (tmp_path/"publish").mkdir()
    (tmp_path/"attempt.json").write_text(json.dumps({"run_id":"r","cartridge_id":"p","attempt_id":"a","chat_id":"c"}))
    (tmp_path/"publish_result.py").write_text(ms.PUBLISH_HELPER)
    (tmp_path/"payload.json").write_text('{"broken":')
    r=subprocess.run([sys.executable,str(tmp_path/"publish_result.py"),"--payload-file",str(tmp_path/"payload.json")],capture_output=True)
    assert r.returncode!=0 and not (tmp_path/"publish/result.json").exists()


def test_workspace_result_change_after_commit_does_not_change_handover(env,monkeypatch):
    run=workflow(env)
    real=ms.seal_cartridge
    def seal(c,r,s):
        real(c,r,s)
        if c['id']=='p':
            a=r['cartridges'][0]['attempts'][-1]
            Path(a['result_path']).write_text('{"untrusted":"later edit"}')
    monkeypatch.setattr(ms,'seal_cartridge',seal)
    received=[]
    def brain(prompt,body):
        if 'CONSUMER:' in prompt:
            received.append(prompt)
        publish(prompt,note='protected original')
        return reply()
    result,fake,_=execute(env,run,brain)
    assert result['status']=='completed' and 'protected original' in received[0]
    assert 'later edit' not in received[0]


def test_path_replacement_while_read_is_rejected(tmp_path,monkeypatch):
    p=tmp_path/'publish';p.mkdir();f=p/'result.json';f.write_text('{}')
    real=ms._open_plain
    class Reader:
        def __init__(self,h):self.h=h
        def __enter__(self):return self
        def __exit__(self,*args):self.h.close()
        def fileno(self):return self.h.fileno()
        def read(self,n):
            raw=self.h.read(n)
            replacement=p/'other';replacement.write_text('{}');replacement.replace(f)
            return raw
    monkeypatch.setattr(ms,'_open_plain',lambda b,n:Reader(real(b,n)))
    with pytest.raises(ms.ResultFailure,match='RESULT_CHANGED_DURING_READ'):
        ms.read_result_file(tmp_path)


def test_run_state_commit_failure_cannot_start_consumer(env,monkeypatch):
    run=workflow(env)
    real=env.store.save
    injected=[]
    def save(r):
        a=r['cartridges'][0]['attempts']
        if a and a[-1].get('phase')=='committed' and a[-1]['status']=='done' and not injected:
            injected.append(True)
            raise RuntimeError('injected failure before status persistence')
        return real(r)
    monkeypatch.setattr(env.store,'save',save)
    def brain(prompt,body):publish(prompt);return reply()
    result,fake,_=execute(env,run,brain)
    assert len(fake.chats)==1 and result['status']=='failed'
    assert result['cartridges'][0]['attempts'][0]['code']=='COMMIT_INCOMPLETE'


def test_duplicate_commit_is_idempotent(env):
    run=workflow(env)
    def brain(prompt,body):publish(prompt);return reply()
    result,_,_=execute(env,run,brain)
    c=ms.load_workflow(env.library/'file')['cartridges'][0]
    a=result['cartridges'][0]['attempts'][0]
    doc,_=ms.read_result_file(env.store.run_dir('u1',run['id']),a['handover']['path'])
    again=ms.commit_attempt_result(env.store,result,c,a,doc,a['handover']['source'],['/result'])
    assert again['sha256']==a['handover']['sha256']


def test_real_unprivileged_publisher_works_and_cannot_replace_descriptor():
    import tempfile,os,shutil
    root=Path(tempfile.mkdtemp(prefix='magazine-writer-permissions-'))
    try:
        os.chmod(root,0o755)
        (root/'publish').mkdir(mode=0o777);os.chmod(root/'publish',0o777)
        identity={'run_id':'r','cartridge_id':'p','attempt_id':'a','chat_id':'c'}
        ms.durable_json(root/'attempt.json',identity)
        ms._replace_text(root/'publish_result.py',ms.PUBLISH_HELPER,0o555)
        result=subprocess.run([sys.executable,str(root/'publish_result.py'),'--verified','--check','actual permission check'],user='nobody',capture_output=True,text=True)
        assert result.returncode==0,result.stderr
        value,_=ms.read_result_file(root)
        assert value['chat_id']=='c'
        attack=subprocess.run([sys.executable,'-c','from pathlib import Path;Path('+repr(str(root/'attempt.json'))+').write_text("wrong")'],user='nobody',capture_output=True)
        assert attack.returncode!=0 and json.loads((root/'attempt.json').read_text())==identity
    finally:
        shutil.rmtree(root)


def test_dotted_cartridge_id_keeps_complete_reply_filename(env):
    root=write_workflow(env.library/'dot',[{'id':'part.one','prompt':'Small task'}])
    p=root/'magazine.yaml';d=yaml.safe_load(p.read_text());d['handover_mode']='result_file_v1';p.write_text(yaml.safe_dump(d))
    run=ms.new_run(env.store,'u1',env.library,'dot',{'worker':'bonsai-2:27b'},[],None)
    def brain(prompt,body):publish(prompt);return reply()
    result,_,_=execute(env,run,brain)
    assert result['status']=='completed'
    folder=env.store.run_dir('u1',run['id'])/'results'
    assert (folder/'01-part.one.md').is_file() and (folder/'01-part.one.prompt.md').is_file()


def test_continue_consumer_uses_existing_protected_producer_commit(env):
    run=workflow(env)
    calls=[]
    def brain(prompt,body):
        calls.append(prompt)
        if len(calls)!=2:publish(prompt)
        return reply()
    result,fake,engine=execute(env,run,brain)
    assert result['status']=='failed' and result['cartridges'][0]['status']=='done'
    first=result['cartridges'][0]['attempts'][0]['chat_id']
    result=asyncio.run(run_to_end(engine,result,start=1))
    assert result['status']=='completed' and len(fake.chats)==3
    assert result['cartridges'][0]['attempts'][0]['chat_id']==first
    assert len(result['cartridges'][0]['attempts'])==1


def test_stop_blocks_publication_and_no_automatic_retry(env):
    run=workflow(env,retries=2)
    fake=FakeOpenWebUI(lambda p,b:reply())
    engine=make_engine(env,fake)
    def brain(prompt,body):
        publish(prompt)
        engine.stop_flags.add(run['id'])
        return reply()
    fake.brain=brain
    result=asyncio.run(run_to_end(engine,run))
    assert result['status']=='stopped' and len(fake.chats)==1
    assert result['cartridges'][1]['attempts']==[]


def test_repair_preserves_useful_unverified_candidate_file(env):
    run=workflow(env,outputs=True,retries=2)
    folder=env.store.run_dir('u1',run['id'])/'workflow'
    path=folder/'magazine.yaml';manifest=yaml.safe_load(path.read_text())
    manifest['cartridges'][0]['artifacts']['outputs'].append('second.txt')
    path.write_text(yaml.safe_dump(manifest))
    attempts=[]
    def brain(prompt,body):
        if 'PRODUCER:' in prompt:
            attempts.append(prompt)
            output=Path(re.search(r'Save your output files in: (\S+)',prompt).group(1))
            if len(attempts)==1:
                (output/'answer.txt').write_text('useful completed candidate')
            else:
                assert '"verified": false' in prompt and 'answer.txt' in prompt
                assert (output/'answer.txt').read_text()=='useful completed candidate'
                (output/'second.txt').write_text('repaired missing output')
        publish(prompt)
        return reply()
    result,_,_=execute(env,run,brain)
    assert result['status']=='completed'
    first,second=result['cartridges'][0]['attempts']
    assert first['candidate_files'][0]['sha256']==second['outputs'][0]['sha256']
    snapshot=env.store.run_dir('u1',run['id'])/'handovers/p'/first['attempt_id']/'candidates/answer.txt'
    assert snapshot.read_text()=='useful completed candidate'
