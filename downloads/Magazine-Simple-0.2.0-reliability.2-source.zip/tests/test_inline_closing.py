"""0.2.0-exec.5: a closing status object written straight after a finished sentence, on that sentence's line.

Live evidence: Qwen3-Coder, run 20261113-023115 c02 (and, as reported by the user, run 085431): the required file
was written and the reply ended `...in the specified output folder. {"status":"DONE"}`. 0.2.0-exec.2 to exec.4
recorded that as "Unfinished". Simulated tests: fake Open WebUI, no model."""
import pytest

from test_completion import DONE, HTML, msg, nebula, run_line, saved, think, tool, write_game
from test_magazine_simple import env, ms  # noqa: F401

HALT = '{"status":"HALT","reason":"the API is missing"}'
QWEN = ('The greeting "Hello there friend" has been saved to the file notes/greeting.txt in the specified '
        'output folder. ' + DONE)

ORIGINAL = {                                   # accepted before this change, and still
    "own line": "Saved.\n" + DONE,
    "own line after a blank line": "Saved.\n\n" + DONE,
    "alone": DONE,
    "closing fenced block": "Saved.\n```json\n" + DONE + "\n```",
    "own line in backticks": "Saved.\n`" + DONE + "`",
    "own line, spaced and lower case": 'Saved.\n{ "status" : "done" }  \n',
    "own line with other keys": 'Saved.\n{"status":"DONE","n":7}',
}
NEWLY_ACCEPTED = {
    "Qwen3-Coder c02, verbatim": QWEN,
    "after a full stop": "The file is saved. " + DONE,
    "after an exclamation mark": "All checks pass! " + DONE,
    "after a question mark": "Anything else? " + DONE,
    "tab and several spaces": "The file is saved.\t   " + DONE,
    "trailing whitespace after the object": "The file is saved. " + DONE + "  \n\n",
    "spaced object": 'The file is saved. { "status": "DONE" }',
    "examples quoted earlier, real closing inline": ("The note says end with\n" + DONE + "\nor, if blocked,\n" + HALT
                                                     + "\nNothing blocked me. " + DONE),
}
NOT_ACCEPTED = {
    "mention inside a sentence, at the very end": "Next I will check the file and then end with " + DONE,
    "mention after a colon": "When finished the closing line is: " + DONE,
    "mention after a comma": "Once verified, " + DONE,
    "inline in backticks": "The file is saved. `" + DONE + "`",
    "inline in double quotes": 'The file is saved. "' + DONE + '"',
    "inline in single quotes": "The file is saved. '" + DONE + "'",
    "inline in brackets": "The file is saved. (" + DONE + ")",
    "inline, bold": "The file is saved. **" + DONE + "**",
    "followed by a full stop": "Then I will reply " + DONE + ".",
    "followed by more text": "The file is saved. " + DONE + " Let me also check one more thing",
    "followed by another sentence on the next line": "The file is saved. " + DONE + "\nActually, one more check.",
    "inside a fenced block with prose": "```\nThe file is saved. " + DONE + "\n```",
    "fenced example, then prose": "For reference:\n```json\n" + DONE + "\n```\nI have not finished yet.",
    "no space after the full stop": "The file is saved." + DONE,
    "cut off inside the object": 'The file is saved. {"status":"DO',
    "missing closing brace": 'The file is saved. {"status":"DONE"',
    "trailing comma": 'The file is saved. {"status":"DONE",}',
    "single-quoted keys": "The file is saved. {'status':'DONE'}",
    "not an object": 'The file is saved. ["status","DONE"]',
    "another status": 'The file is saved. {"status":"OK"}',
    "status in a nested object": 'The file is saved. {"result":{"status":"DONE"}}',
    "the bare word": "The file is saved. DONE",
    "escaped": 'The file is saved. {\\"status\\":\\"DONE\\"}',
}


@pytest.mark.parametrize("name", list(ORIGINAL))
def test_original_closing_forms_are_still_accepted(name):
    assert ms.closing_status(ORIGINAL[name]) == "DONE"


@pytest.mark.parametrize("name", list(NEWLY_ACCEPTED))
def test_a_closing_done_straight_after_a_finished_sentence_is_accepted(name):
    assert ms.closing_status(NEWLY_ACCEPTED[name]) == "DONE"


@pytest.mark.parametrize("name", list(NOT_ACCEPTED))
def test_misleading_and_invalid_endings_are_not_accepted(name):
    assert ms.closing_status(NOT_ACCEPTED[name]) is None


def test_halt_is_read_the_same_way_and_examples_still_decide_nothing():
    assert ms.closing_status("I cannot write the file. " + HALT) == "HALT"
    assert ms.closing_object("I cannot write the file. " + HALT)["reason"] == "the API is missing"
    assert ms.closing_status("If the API were missing I would answer " + HALT) is None          # inside a sentence
    assert ms.closing_status("If blocked I would answer\n" + HALT + "\nIt is present, so let me now") is None
    assert ms.closing_status("I cannot write the file. `" + HALT + "`") is None
    assert ms.closing_status("Blocked.\n" + HALT) == "HALT"                                      # as before


def test_the_qwen_reply_now_completes_the_step_and_the_line_goes_on(env):
    """Run 023115 c02 as saved: tool refusals, a successful write_file, then the inline closing."""
    nebula(env.library / "nebula", ids=("c10", "c11"))

    def brain(prompt, body):
        write_game(prompt, "<html>ok</html>")
        if "Build c10" in prompt:
            return saved([msg("I need to use a different approach. Let me try the write_file function instead."),
                          *tool("write_file"), msg(QWEN)])
        return saved([msg("Done.\n" + DONE)])

    run, fake, _ = run_line(env, brain)
    a = run["cartridges"][0]["attempts"][0]
    assert run["status"] == "completed" and a["status"] == "done" and "note" not in a and len(fake.chats) == 2
    handed = run["cartridges"][1]["attempts"][0]["inputs"][0]
    assert handed["verified"] is True and handed["sha256"] == a["outputs"][0]["sha256"]


def test_an_inline_done_without_the_required_file_still_fails(env):
    nebula(env.library / "nebula")
    run, fake, _ = run_line(env, lambda p, b: saved([msg(QWEN)]))
    a = run["cartridges"][0]["attempts"][0]
    assert a["status"] == "failed" and a["note"] == f"Required output file(s) not found: {HTML}" and len(fake.chats) == 1


def test_an_inline_halt_halts_with_its_reason(env):
    nebula(env.library / "nebula")

    def brain(prompt, body):
        write_game(prompt, "<html>x</html>")
        return saved([msg("Checking."), *tool(), think(), msg("I cannot write the file. " + HALT)])

    run, fake, _ = run_line(env, brain)
    a = run["cartridges"][0]["attempts"][0]
    assert run["status"] == "halted" and a["note"] == "the API is missing" and len(fake.chats) == 1


@pytest.mark.parametrize("name", ["mention inside a sentence, at the very end", "inline in backticks",
                                  "followed by more text", "cut off inside the object"])
def test_a_misleading_ending_still_stops_the_line_as_unfinished(env, name):
    nebula(env.library / "nebula")

    def brain(prompt, body):
        write_game(prompt, "<html>x</html>")
        return saved([msg("Working."), *tool(), msg(NOT_ACCEPTED[name])])

    run, fake, _ = run_line(env, brain)
    a = run["cartridges"][0]["attempts"][0]
    assert a["status"] == "failed" and a["note"].startswith("Unfinished") and len(fake.chats) == 1
    assert [c["status"] for c in run["cartridges"]] == ["failed", "pending", "pending"]


def test_with_the_valve_off_nothing_changes(env):
    nebula(env.library / "nebula", ids=("c10",))

    def brain(prompt, body):
        write_game(prompt, "<html>ok</html>")
        return saved([msg("The file is saved.")])

    run, _, _ = run_line(env, brain, require_done=False)
    assert run["status"] == "completed"
