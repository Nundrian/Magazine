"""Offline tests for Magazine Simple against a fake Open WebUI."""
import asyncio
import base64
import importlib.util
import io
import json
import re
import sys
import types
import zipfile
from pathlib import Path

import httpx
import pytest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("magazine_simple", HERE.parent / "magazine_simple.py")
ms = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ms)

BONSAI = Path("/tmp/claude-0/wf")  # the real Run B 10-cartridge workflow, if present


# ---------------------------------------------------------------- helpers

def write_workflow(root, cartridges, name="Test workflow"):
    root = Path(root)
    (root / "cartridges").mkdir(parents=True, exist_ok=True)
    items = []
    for c in cartridges:
        (root / "cartridges" / f"{c['id']}.md").write_text(c["prompt"], encoding="utf-8")
        item = {"id": c["id"], "model": c.get("model", "worker"), "prompt_file": f"cartridges/{c['id']}.md"}
        for key in ("handover", "artifacts"):
            if key in c:
                item[key] = c[key]
        items.append(item)
    import yaml
    (root / "magazine.yaml").write_text(yaml.safe_dump({"schema_version": "1.0", "name": name, "cartridges": items}),
                                        encoding="utf-8")
    return root


def zip_of(folder, prefix=""):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as z:
        for p in Path(folder).rglob("*"):
            if p.is_file():
                z.write(p, prefix + p.relative_to(folder).as_posix())
    return buffer.getvalue()


class FakeOpenWebUI:
    """Behaves like the parts of Open WebUI's API that Magazine uses. `brain`
    decides each reply from the prompt and may write files like a Terminal."""

    def __init__(self, brain, busy_polls=1):
        self.brain = brain
        self.busy_polls = busy_polls
        self.chats = {}
        self.requests = []
        self.stopped = []

    def handler(self, request):
        self.requests.append((request.method, request.url.path))
        path, method = request.url.path, request.method
        body = json.loads(request.content) if request.content else None
        if method == "DELETE":
            return httpx.Response(500, json={"detail": "Magazine must never delete chats"})
        if path == "/api/v1/chats/new":
            cid = f"chat{len(self.chats) + 1}"
            self.chats[cid] = {"chat": body["chat"], "polls": 0, "completion": None}
            return httpx.Response(200, json={"id": cid})
        if path == "/api/chat/completions":
            chat = self.chats[body["chat_id"]]
            chat["completion"] = body
            return httpx.Response(200, json={"status": True, "chat_id": body["chat_id"], "task_ids": ["t1"]})
        m = re.fullmatch(r"/api/tasks/chat/(\w+)/stop", path)
        if m:
            self.stopped.append(m.group(1))
            self.chats[m.group(1)]["polls"] = self.busy_polls + 1
            return httpx.Response(200, json={"status": True})
        m = re.fullmatch(r"/api/tasks/chat/(\w+)", path)
        if m:
            chat = self.chats[m.group(1)]
            chat["polls"] += 1
            return httpx.Response(200, json={"task_ids": ["t1"] if chat["polls"] <= self.busy_polls else []})
        m = re.fullmatch(r"/api/v1/chats/(\w+)", path)
        if m:
            chat = self.chats[m.group(1)]
            body = chat["completion"]
            history = json.loads(json.dumps(chat["chat"]["history"]))
            if "saved_reply" not in chat:
                chat["saved_reply"] = self.brain(body["messages"][0]["content"], body)
            reply = chat["saved_reply"]
            msg = history["messages"][body["id"]]
            if isinstance(reply, dict):
                msg.update(reply)
            else:
                msg.update(content=reply, done=True)
            return httpx.Response(200, json={"id": m.group(1), "chat": {"history": history}})
        if path == "/api/models":
            return httpx.Response(200, json={"data": [{"id": "bonsai-2:27b", "name": "Bonsai"}]})
        if path == "/api/v1/tools/":
            return httpx.Response(200, json=[{"id": "dev", "name": "Dev", "meta": {"description": "d"}}])
        if path == "/api/v1/terminals/":
            return httpx.Response(200, json=[{"id": "open-terminal", "name": "Open Terminal", "contexts": {}}])
        return httpx.Response(404, json={"detail": "not found"})

    def client(self):
        return ms.OpenWebUI("http://owui", "tok", transport=httpx.MockTransport(self.handler))


def save_dir(prompt):
    m = re.search(r"Save your output files in: (\S+)", prompt)
    return Path(m.group(1)) if m else None


@pytest.fixture
def env(tmp_path, monkeypatch):
    monkeypatch.setattr(ms, "POLL_SECONDS", 0.0)
    library, data, work = tmp_path / "library", tmp_path / "data", tmp_path / "work"
    library.mkdir()
    store = ms.Store(data, work)
    return types.SimpleNamespace(library=library, store=store, tmp=tmp_path)


async def run_to_end(engine, run, token="tok", params=None, start=0):
    assert engine.start(run, token, params or {}, start) is None
    await engine.active[run["id"]]
    return engine.store.load(run["owner"], run["id"])


def make_engine(env, fake):
    return ms.Engine(env.store, env.library, lambda token: fake.client())


# ---------------------------------------------------------------- workflows

@pytest.mark.skipif(not BONSAI.is_dir(), reason="Run B workflow not available")
def test_existing_run_b_workflow_loads_unchanged():
    wf = ms.load_workflow(BONSAI)
    assert len(wf["cartridges"]) == 10
    c2 = wf["cartridges"][1]
    assert c2["handover"] == [{"from": "c01_policy", "select": "/policy", "as": "policy"}]
    assert c2["outputs"] == ["data/orders.csv", "notes/utf8.txt"]
    assert "Mġarr — €12.50" in c2["prompt"]
    assert wf["cartridges"][6]["inputs"][2] == {"from": "c06_extend", "path": "data/orders.csv"}


def test_workflow_validation_messages(tmp_path):
    root = write_workflow(tmp_path / "a", [{"id": "c1", "prompt": "x"},
                                            {"id": "c2", "prompt": "y", "artifacts": {"inputs": [{"from": "c1", "path": "f.txt"}]}}])
    with pytest.raises(ms.MagazineError, match="does not declare output"):
        ms.load_workflow(root)
    root = write_workflow(tmp_path / "b", [{"id": "c1", "prompt": "x", "artifacts": {"outputs": ["../escape"]}}])
    with pytest.raises(ms.MagazineError, match="inside the workflow"):
        ms.load_workflow(root)
    root = write_workflow(tmp_path / "c", [{"id": "c1", "prompt": "x", "handover": [{"from": "c9", "select": "/a"}]}])
    with pytest.raises(ms.MagazineError, match="earlier cartridge"):
        ms.load_workflow(root)


def test_import_zip_root_and_single_folder(env):
    src = write_workflow(env.tmp / "src", [{"id": "c1", "prompt": "Hello"}], name="Import me")
    r = ms.import_workflow(env.library, "Import me.zip", zip_of(src))
    assert r == {"id": "Import-me", "name": "Import me", "cartridges": 1}
    r = ms.import_workflow(env.library, "nested.zip", zip_of(src, "project/"))
    assert r["id"] == "nested"
    assert (env.library / "nested" / "magazine.yaml").is_file()
    with pytest.raises(ms.MagazineError, match="already exists"):
        ms.import_workflow(env.library, "NESTED.zip", zip_of(src))
    assert not [p for p in env.library.iterdir() if p.name.startswith(".import-")]
    listed = ms.list_workflows(env.library)
    assert [w["id"] for w in listed] == ["Import-me", "nested"]


def test_import_rejects_traversal_and_bad_workflow(env):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as z:
        z.writestr("magazine.yaml", "cartridges: []")
        z.writestr("../evil.txt", "x")
    with pytest.raises(ms.MagazineError):
        ms.import_workflow(env.library, "evil.zip", buffer.getvalue())
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as z:
        z.writestr("magazine.yaml", "cartridges: []")
    with pytest.raises(ms.MagazineError, match="non-empty"):
        ms.import_workflow(env.library, "empty.zip", buffer.getvalue())
    assert list(env.library.iterdir()) == []


# ---------------------------------------------------------------- replies

def test_halt_and_json_rules():
    assert ms.halt_reason('{"status":"HALT","reason":"no policy"}') == "no policy"
    assert ms.halt_reason('Cannot continue.\n```json\n{"status": "HALT"}\n```') == "The model replied HALT."
    assert ms.halt_reason('All good {"status": "HALT"} inline is just text') is None
    assert ms.halt_reason('{"status":"OK","stage":"seed"}') is None
    assert ms.result_json('Done.\n```json\n{"policy":"paid_only"}\n```')["policy"] == "paid_only"
    assert ms.select_pointer({"a": [{"b": 2}]}, "/a/0/b") == 2


# ---------------------------------------------------------------- runs

def test_full_run_passes_files_and_values_and_writes_ledger(env):
    write_workflow(env.library / "line", [
        {"id": "c1", "prompt": "Decide the policy. Reply with JSON."},
        {"id": "c2", "prompt": "Write data.", "handover": [{"from": "c1", "select": "/policy", "as": "policy"}],
         "artifacts": {"outputs": ["data/orders.csv"]}},
        {"id": "c3", "prompt": "Summarise the data.", "model": "checker",
         "artifacts": {"inputs": [{"from": "c2", "path": "data/orders.csv"}], "outputs": ["summary.txt"]}},
    ])
    seen = []

    def brain(prompt, body):
        seen.append((prompt, body))
        if prompt.startswith("Decide"):
            return '{"status":"OK","policy":"paid_only"}'
        out = save_dir(prompt)
        if prompt.startswith("Write data."):
            assert '"paid_only"' in prompt
            (out / "data").mkdir(parents=True, exist_ok=True)
            (out / "data" / "orders.csv").write_text("a,b\n1,2\n", encoding="utf-8")
            return "Wrote the file."
        source = re.search(r"  - (\S+) \(from c2: data/orders.csv\)", prompt).group(1)
        rows = Path(source).read_text(encoding="utf-8").count("\n")
        (out / "summary.txt").write_text(f"{rows} lines\n", encoding="utf-8")
        return "Summary written."

    fake = FakeOpenWebUI(brain)
    engine = make_engine(env, fake)
    run = ms.new_run(env.store, "u1", env.library, "line", {"worker": "bonsai-2:27b", "c3": "ornith:9b"},
                     ["dev"], "open-terminal")
    run = asyncio.run(run_to_end(engine, run, params={"temperature": 0.6}))

    assert run["status"] == "completed"
    assert [c["status"] for c in run["cartridges"]] == ["done", "done", "done"]
    assert len(fake.chats) == 3 and not any(m == "DELETE" for m, _ in fake.requests)
    first_prompt, first_body = seen[0]
    assert first_prompt == "Decide the policy. Reply with JSON."          # prompt passed through unchanged
    assert first_body["tool_ids"] == ["dev"] and first_body["terminal_id"] == "open-terminal"
    assert first_body["params"] == {"temperature": 0.6}
    assert seen[2][1]["model"] == "ornith:9b"
    assert fake.chats["chat1"]["chat"]["title"] == "Magazine · Test workflow · c1"
    work = env.store.work_dir(run["id"])
    assert (work / "c3" / "outputs" / "summary.txt").read_text() == "2 lines\n"
    ledger = (work / "LEDGER.md").read_text(encoding="utf-8")
    assert "| 3 | c3 | 1 | `ornith:9b` | done |" in ledger and "[open](/c/chat3)" in ledger
    assert "summary.txt (8 B, " in ledger
    results = env.store.run_dir("u1", run["id"]) / "results"
    # 0.2.0-exec.1: the saved reply is the chat's visible text, closing line included (valve on).
    closing = "\n" + ms.DONE_LINE if engine.require_done else ""
    assert (results / "01-c1.md").read_text() == '{"status":"OK","policy":"paid_only"}' + closing

    archive = zipfile.ZipFile(io.BytesIO(ms.build_download(env.store, run)))
    names = set(archive.namelist())
    assert {"LEDGER.md", "run.json", "results/03-c3.md", "work/c2/outputs/data/orders.csv",
            "work/c3/inputs/c2/data/orders.csv"} <= names


def test_halt_stops_the_line_and_keeps_chat(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "Check"}, {"id": "c2", "prompt": "Next"}])
    fake = FakeOpenWebUI(lambda p, b: '{"status":"HALT","reason":"policy missing"}')
    engine = make_engine(env, fake)
    run = asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    assert run["status"] == "halted"
    assert [c["status"] for c in run["cartridges"]] == ["halted", "pending"]
    assert run["cartridges"][0]["attempts"][0]["note"] == "policy missing"
    assert len(fake.chats) == 1


def test_missing_output_and_model_error_fail_clearly(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "Make it", "artifacts": {"outputs": ["x.txt"]}}])
    engine = make_engine(env, FakeOpenWebUI(lambda p, b: "I made it, honest."))
    run = asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    assert run["status"] == "failed"
    assert "x.txt" in run["cartridges"][0]["attempts"][0]["note"]

    engine = make_engine(env, FakeOpenWebUI(lambda p, b: {"error": {"content": "context size exceeded"}, "done": True}))
    run = asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    assert run["status"] == "failed"
    assert "context size exceeded" in run["cartridges"][0]["attempts"][0]["note"]


def test_no_time_limit_long_chat_completes(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "Slow"}])
    fake = FakeOpenWebUI(lambda p, b: "done slowly", busy_polls=500)
    engine = make_engine(env, fake)
    run = asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    assert run["status"] == "completed"


def test_stop_cancels_the_active_chat(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "Long"}, {"id": "c2", "prompt": "Never"}])
    fake = FakeOpenWebUI(lambda p, b: "x", busy_polls=10 ** 9)
    engine = make_engine(env, fake)
    run = ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)

    async def scenario():
        engine.start(run, "tok", {})
        task = engine.active[run["id"]]
        await asyncio.sleep(0.05)
        engine.stop(run["id"])
        await task

    asyncio.run(scenario())
    saved = env.store.load("u1", run["id"])
    assert saved["status"] == "stopped"
    assert [c["status"] for c in saved["cartridges"]] == ["stopped", "pending"]
    assert fake.stopped == ["chat1"]


def test_restart_from_failed_cartridge_keeps_previous_attempt(env):
    write_workflow(env.library / "w", [
        {"id": "c1", "prompt": "First", "artifacts": {"outputs": ["a.txt"]}},
        {"id": "c2", "prompt": "Second", "artifacts": {"inputs": [{"from": "c1", "path": "a.txt"}], "outputs": ["b.txt"]}},
    ])
    state = {"c2_tries": 0}

    def brain(prompt, body):
        out = save_dir(prompt)
        if prompt.startswith("First"):
            (out / "a.txt").write_text("A", encoding="utf-8")
            return "ok"
        state["c2_tries"] += 1
        if state["c2_tries"] == 1:
            return "forgot the file"
        (out / "b.txt").write_text("B", encoding="utf-8")
        return "ok now"

    fake = FakeOpenWebUI(brain)
    engine = make_engine(env, fake)
    run = asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    assert run["status"] == "failed"
    with pytest.raises(ms.MagazineError):
        engine.start(run, "tok", {}, 2)  # starting after c2 is refused: c2 has not completed
    run = asyncio.run(run_to_end(engine, run, start=1))
    assert run["status"] == "completed"
    attempts = run["cartridges"][1]["attempts"]
    assert [a["status"] for a in attempts] == ["failed", "done"]
    assert [a["chat_id"] for a in attempts] == ["chat2", "chat3"]
    work = env.store.work_dir(run["id"])
    assert (work / "c2~attempt1").is_dir() and (work / "c2" / "outputs" / "b.txt").read_text() == "B"
    assert run["cartridges"][0]["attempts"][0]["chat_id"] == "chat1"
    ledger = (work / "LEDGER.md").read_text(encoding="utf-8")
    assert "| 2 | c2 | 1 |" in ledger and "| 2 | c2 | 2 |" in ledger


def test_handover_value_missing_fails_the_producer_before_consumer(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "Talk"},
                                       {"id": "c2", "prompt": "Use", "handover": [{"from": "c1", "select": "/policy"}]}])
    engine = make_engine(env, FakeOpenWebUI(lambda p, b: "plain words, no JSON"))
    run = asyncio.run(run_to_end(engine, ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)))
    assert [c["status"] for c in run["cartridges"]] == ["failed", "pending"]
    assert "RESULT_JSON_INVALID" in run["cartridges"][0]["attempts"][0]["note"]
    assert run["cartridges"][1]["attempts"] == []


def test_interrupted_run_after_restart_of_open_webui(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "x"}])
    run = ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)
    run["status"] = "running"
    run["cartridges"][0].update(status="running", attempts=[{"model": "m", "status": "running", "started": ms.now_iso()}])
    env.store.save(run)
    engine = make_engine(env, FakeOpenWebUI(lambda p, b: "x"))
    engine.mark_interrupted("u1")
    saved = env.store.load("u1", run["id"])
    assert saved["status"] == "interrupted" and saved["cartridges"][0]["status"] == "interrupted"


def test_model_choice_is_required(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "x", "model": "writer"}])
    with pytest.raises(ms.MagazineError, match="Choose a model for: c1"):
        ms.new_run(env.store, "u1", env.library, "w", {}, [], None)


# ---------------------------------------------------------------- queue

def test_queue_runs_one_at_a_time_in_order(env):
    """Three workflows started together: one uses the model, the others wait
    their turn. A halted run does not hold up the queue."""
    for name in ("a", "b", "c", "d"):
        write_workflow(env.library / name, [{"id": "s1", "prompt": f"{name} one"}, {"id": "s2", "prompt": f"{name} two"}],
                       name=name.upper())
    order = []

    def brain(prompt, body):
        order.append(prompt.replace(" ", ""))
        return '{"status":"HALT","reason":"b stops"}' if prompt == "b one" else "ok"
    engine = make_engine(env, FakeOpenWebUI(brain, busy_polls=3))
    runs = {n: ms.new_run(env.store, "u1", env.library, n, {"worker": "m"}, [], None) for n in "abcd"}

    async def scenario():
        assert engine.start(runs["a"], "tok", {}) is None
        assert engine.start(runs["b"], "tok", {}) == 1
        assert engine.start(runs["c"], "tok", {}) == 2
        assert engine.start(runs["d"], "tok", {}) == 3
        assert env.store.load("u1", runs["c"]["id"])["status"] == "queued"
        with pytest.raises(ms.MagazineError, match="already"):
            engine.start(runs["c"], "tok", {})
        engine.dequeue(env.store.load("u1", runs["d"]["id"]))     # change of mind: d leaves the queue
        assert engine.position(runs["c"]["id"]) == 2
        for _ in range(500):
            await asyncio.sleep(0.01)
            if not engine.active and not engine.queue:
                break
    asyncio.run(scenario())
    status = {n: env.store.load("u1", runs[n]["id"])["status"] for n in "abcd"}
    assert status == {"a": "completed", "b": "halted", "c": "completed", "d": "ready"}
    assert order == ["aone", "atwo", "bone", "cone", "ctwo"]
    a, b, c = (env.store.load("u1", runs[n]["id"]) for n in "abc")   # never two at once
    assert a["cartridges"][-1]["attempts"][0]["finished"] <= b["cartridges"][0]["attempts"][0]["started"]
    assert b["cartridges"][0]["attempts"][0]["finished"] <= c["cartridges"][0]["attempts"][0]["started"]


def test_queue_waits_after_open_webui_restart(env):
    write_workflow(env.library / "w", [{"id": "c1", "prompt": "x"}])
    run = ms.new_run(env.store, "u1", env.library, "w", {"worker": "m"}, [], None)
    run["status"], run["queued_from"] = "queued", "ready"
    env.store.save(run)
    engine = make_engine(env, FakeOpenWebUI(lambda p, b: "ok"))   # a fresh engine has an empty queue
    engine.mark_interrupted("u1")
    assert env.store.load("u1", run["id"])["status"] == "ready"


# ---------------------------------------------------------------- routes

def test_routes_through_fastapi(env, monkeypatch):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    user = types.SimpleNamespace(id="u1", role="admin", settings={"ui": {"params": {"temperature": 0.7}}})
    auth = types.ModuleType("open_webui.utils.auth")
    auth.get_current_user = lambda: user
    config = types.ModuleType("open_webui.config")
    config.DATA_DIR = str(env.tmp / "data")
    for name, module in (("open_webui", types.ModuleType("open_webui")),
                         ("open_webui.utils", types.ModuleType("open_webui.utils")),
                         ("open_webui.utils.auth", auth), ("open_webui.config", config)):
        monkeypatch.setitem(sys.modules, name, module)
    fake = FakeOpenWebUI(lambda p, b: "fine")
    monkeypatch.setitem(ms._STATE, "engine", None)
    app = FastAPI()
    event = ms.Event()
    event.valves.library_root = str(env.library)
    event.valves.workspace_root = str(env.tmp / "work")
    asyncio.run(event.event(__app__=app))
    ms._STATE["engine"].client_factory = lambda token: fake.client()
    api = TestClient(app)
    assert "Your workflows" in api.get("/magazine-simple").text
    src = write_workflow(env.tmp / "src", [{"id": "c1", "prompt": "Hi"}], name="Route test")
    r = api.post("/api/magazine-simple/workflows/import",
                 json={"file_name": "route.zip", "data_b64": base64.b64encode(zip_of(src)).decode()})
    assert r.status_code == 200, r.text
    assert api.get("/api/magazine-simple/workflows").json()["workflows"][0]["id"] == "route"
    opts = api.get("/api/magazine-simple/options").json()
    assert opts["models"][0]["id"] == "bonsai-2:27b" and opts["terminals"][0]["id"] == "open-terminal"
    r = api.post("/api/magazine-simple/runs", json={"workflow_id": "route", "model_map": {"c1": "bonsai-2:27b"}})
    assert r.status_code == 200, r.text
    run_id = r.json()["id"]
    assert api.get(f"/api/magazine-simple/runs/{run_id}").json()["status"] == "ready"   # Prepare does not start
    assert api.post(f"/api/magazine-simple/runs/{run_id}/start").status_code == 200
    detail = None
    for _ in range(100):
        detail = api.get(f"/api/magazine-simple/runs/{run_id}").json()
        if detail["status"] != "running":
            break
        import time
        time.sleep(0.02)
    assert detail["status"] == "completed", detail
    assert "# Ledger: Route test" in detail["ledger"]
    # 0.2.0-exec.1: the saved reply is the chat's visible text, closing line included (valve on).
    closing = "\n" + ms.DONE_LINE if ms._STATE["engine"].require_done else ""
    assert detail["cartridges"][0]["reply"] == "fine" + closing
    assert api.post(f"/api/magazine-simple/runs/{run_id}/start").status_code == 409
    assert api.get("/api/magazine-simple/queue").json() == {"running": [], "waiting": []}
    assert api.get(f"/api/magazine-simple/runs/{run_id}/download").headers["content-type"] == "application/zip"
    assert api.get("/api/magazine-simple/runs/../../etc").status_code == 404
    # 0.2.0-exec.3: any signed-in user can add a workflow, as any signed-in user can already delete one.
    user.role = "user"
    assert api.get("/api/magazine-simple/workflows").json()["can_import"] is True
    r = api.post("/api/magazine-simple/workflows/import",
                 json={"file_name": "by-user.zip", "data_b64": base64.b64encode(zip_of(src)).decode()})
    assert r.status_code == 200 and r.json()["id"] == "by-user", r.text
    assert api.post("/api/magazine-simple/workflows/import", json={}).status_code == 400   # a bad ZIP, not a refusal
    assert api.delete("/api/magazine-simple/workflows/by-user").json() == {"deleted": "by-user"}
    # Any signed-in user can delete: one, a selection, or all.
    for name in ("a1", "a2", "a3", "a4"):
        write_workflow(env.library / name, [{"id": "c1", "prompt": "x"}])
    assert api.delete("/api/magazine-simple/workflows/route").json() == {"deleted": "route"}
    r = api.post("/api/magazine-simple/workflows/delete", json={"ids": ["a1", "a3", "nope", ".."]}).json()
    assert r["deleted"] == ["a1", "a3"] and [f["id"] for f in r["failed"]] == ["nope", ".."]
    assert [w["id"] for w in api.get("/api/magazine-simple/workflows").json()["workflows"]] == ["a2", "a4"]
    assert api.post("/api/magazine-simple/workflows/delete", json={"ids": []}).status_code == 400
    assert api.post("/api/magazine-simple/workflows/delete", json={"all": True}).json()["deleted"] == ["a2", "a4"]
    assert api.get("/api/magazine-simple/workflows").json()["workflows"] == []
    assert api.get(f"/api/magazine-simple/runs/{run_id}").json()["status"] == "completed"   # past work kept
    assert api.delete("/api/magazine-simple/workflows/..").status_code in (400, 404)
