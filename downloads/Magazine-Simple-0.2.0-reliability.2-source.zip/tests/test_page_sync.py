"""Metadata checks: page.html is the readable source and the installed function serves the copy embedded in
magazine_simple.py, so they must be identical; and the candidate must be distinguishable from 0.2.0."""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_magazine_simple as base  # noqa: E402

CANDIDATE_VERSION = "0.2.0-reliability.2"
UI1_PAGE_SHA256 = "0716e12fdb284e34ee27294706600855a1b7bde59836cc4212ef80d4b68016c9"   # page.html of 0.2.0-ui.1


def test_embedded_page_matches_page_html():
    py = (HERE / "magazine_simple.py").read_text(encoding="utf-8")
    embedded = re.search(r'PAGE_HTML = r"""(.*?)"""', py, re.S).group(1)
    assert embedded.rstrip("\n") == (HERE / "page.html").read_text(encoding="utf-8").rstrip("\n")


def without_delete_previous_work(page):
    """The page with the 0.2.0-exec.4 additions taken out again: the "Delete previous work" block, the one
    call that fills it, and its script section. What is left must be the 0.2.0-ui.1 page."""
    a, b = page.index('  <details id="history-delete-details">'), page.index('  <p id="history-msg"')
    page = page[:a] + page[b:]
    page = page.replace("      renderHistoryDeleteList(d.runs);\n", "", 1)
    a = page.index("\n  // --- delete previous work ---")
    b = page.index('  el("btn-history-open").onclick')
    page = page[:a] + page[b:]
    page = re.sub(r'  /\* Antiloop \*/.*?  /\* End Antiloop \*/\n', '', page, flags=re.S)
    page = re.sub(r'  <div class="tool" id="antiloop-control">.*?  </div>\n', '', page, flags=re.S)
    page = re.sub(r'<footer class="muted" id="magazine-version">.*?</footer>\n', '', page)
    page = re.sub(r'  // --- Antiloop ---.*?  // --- End Antiloop ---\n', '', page, flags=re.S)
    page = page.replace('    renderAntiloop();\n', '')
    page = page.replace('    el("run-terminal").textContent += " · Antiloop: " + (!r.loop_police || r.loop_police.enabled !== false ? "On" : "Off");\n', '')
    return page


def test_page_is_the_ui_candidate_page_plus_delete_previous_work_and_nothing_else():
    import hashlib
    page = (HERE / "page.html").read_text(encoding="utf-8")
    assert hashlib.sha256(without_delete_previous_work(page).encode("utf-8")).hexdigest() == UI1_PAGE_SHA256
    assert page.count("history-delete") > 10 and "/runs/delete" in page


def test_version_identifies_the_candidate():
    py = (HERE / "magazine_simple.py").read_text(encoding="utf-8")
    assert re.search(r"^version: (.+)$", py, re.M).group(1) == CANDIDATE_VERSION        # Open WebUI function metadata
    assert re.search(r'^VERSION = "(.+)"$', py, re.M).group(1) == CANDIDATE_VERSION     # the constant the engine records
    assert base.ms.VERSION == CANDIDATE_VERSION
    assert (HERE / "README.md").read_text(encoding="utf-8").startswith(f"# Magazine Simple {CANDIDATE_VERSION}\n")
    assert "0.2.0-ui" not in (HERE / "page.html").read_text(encoding="utf-8")            # the page shows no version


def test_new_runs_record_the_candidate_version_and_nothing_else_changes_in_the_record(tmp_path):
    library = tmp_path / "library"
    library.mkdir()
    base.write_workflow(library / "w", [{"id": "c1", "prompt": "x", "model": "m"}, {"id": "c2", "prompt": "y", "model": "m"}])
    store = base.ms.Store(tmp_path / "data", tmp_path / "work")
    run = base.ms.new_run(store, "u1", library, "w", {"m": "model-a"}, [], None)
    assert run["version"] == CANDIDATE_VERSION and run["status"] == "ready"
    assert [c["model"] for c in run["cartridges"]] == ["model-a", "model-a"]
