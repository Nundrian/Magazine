import asyncio
import io
import json
import zipfile
from pathlib import Path
import pytest
from test_magazine_simple import ms, env, FakeOpenWebUI, make_engine, run_to_end
from test_file_handover import workflow, execute, publish, reply, base


def events(sequence, *, errors=False, arguments=None):
    out=[]
    for i, result in enumerate(sequence):
        cid=f'call-{i}'
        out += [{'type':'function_call','call_id':cid,'name':'probe','arguments':arguments or '{"a":1,"b":2}'},
                {'type':'function_call_output','call_id':cid,'status':'failed' if errors else 'completed','output':result}]
    return {'done':False,'output':out}


@pytest.mark.parametrize('config,expected', [({},(1800,5)),({'seconds':60,'max_retries':2},(60,3)),
    ({'attempt_seconds':3,'max_attempts':5},(3,5)),({'max_retries':5},(1800,5))])
def test_policy_aliases(config,expected):
    p=ms.recovery_policy(config)
    assert (p['attempt_seconds'],p['max_attempts'])==expected


@pytest.mark.parametrize('config',[{'max_attempts':6},{'max_retries':True},{'max_retries':'4'},
    {'attempt_seconds':0},{'max_attempts':3,'max_retries':4},{'attempt_seconds':30,'seconds':60},[]])
def test_invalid_recovery(config):
    with pytest.raises(ms.MagazineError): ms.recovery_policy(config)


def test_repetitions_warn_three_stop_five_and_no_snapshot_double_count():
    p=ms.LoopPolice()
    p.observe(events(['same']*3))
    assert len(p.warnings)==1
    p.observe(events(['same']*3))
    assert p.observed==3
    p.observe(events(['same']*4))
    with pytest.raises(ms.LoopDetected,match='identical_call_result'):
        p.observe(events(['same']*5))


def test_identical_errors_three():
    with pytest.raises(ms.LoopDetected,match='identical_errors'):
        ms.LoopPolice().observe(events(['Error']*3,errors=True))


def test_short_cycle():
    with pytest.raises(ms.LoopDetected,match='short_cycle'):
        ms.LoopPolice().observe(events(['A','B']*3))


def test_changing_polling_slow_reasoning_and_changed_test_result():
    p=ms.LoopPolice()
    for _ in range(100): p.observe({'content':'thinking','done':False})
    p.observe(events(list(range(20))))
    p.observe(events(list(range(20))+['test failed','changed file','test failed','changed file again','test failed']))
    assert not p.warnings


def test_disable_and_incomplete_tools():
    ms.LoopPolice({'enabled':False}).observe(events(['same']*30))
    p=ms.LoopPolice()
    p.observe({'output':[{'type':'function_call','call_id':str(i),'name':'x'} for i in range(30)]})
    assert p.observed==0


def test_parallel_batch_is_not_serial_loop():
    calls=events(['same']*20)['output']
    msg={'output':calls[::2]+calls[1::2]}
    p=ms.LoopPolice();p.observe(msg)
    assert p.observed==1


def test_argument_key_order_is_canonical():
    msg=events(['same']*5)
    for item in msg['output'][::4]: item['arguments']='{ "b":2, "a":1 }'
    with pytest.raises(ms.LoopDetected): ms.LoopPolice().observe(msg)


def test_effective_edits_reset_and_explicit_noop_edits_count():
    msg=events(['acknowledged']*10)
    for item in msg['output'][::2]: item['name']='edit_file'
    p=ms.LoopPolice();p.observe(msg)
    assert not p.warnings and not p.history
    msg=events([[{'type':'input_text','text':'{"changed": false}'}]]*5)
    for item in msg['output'][::2]: item['name']='edit_file'
    with pytest.raises(ms.LoopDetected): ms.LoopPolice().observe(msg)


def test_completed_only_snapshot_is_never_claimed_as_live_protection(env):
    run=workflow(env)
    fake=FakeOpenWebUI(lambda p,b:reply(),busy_polls=0)
    engine=make_engine(env,fake)
    # The observation wrapper checks active-task provenance before detection.
    async def scenario():
        a={}
        def cid(c): a['chat_id']=c
        await ms.attempt_chat(engine,run,a,fake.client(),model='m',prompt='x',title='x',on_chat=cid)
        assert a['loop_police']['observed_events']==0
    asyncio.run(scenario())


def test_usage_c025_cumulative_and_partial():
    t=ms.token_usage({'id':'original','done':True,'usage':{'input_tokens':205867,'output_tokens':6413,
        'total_tokens':212280,'prompt_tokens':29827,'completion_tokens':457}})
    assert (t['input'],t['output'],t['total'])==(205867,6413,212280)
    assert t['available'] and not t['incomplete']
    t=ms.token_usage({'done':True,'usage':{'input_tokens':100,'completion_tokens':8}})
    assert t['input']==100 and t['output'] is None and t['incomplete']
    assert ms.token_usage(None)['total'] is None
    assert ms.token_usage({'done':True,'usage':{'input_tokens':2,'output_tokens':3,'incomplete':True}})['incomplete']
    msg=events(['tool result'])
    msg.update(done=True,usage={'prompt_tokens':20,'completion_tokens':3,'total_tokens':1234})
    t=ms.token_usage(msg)
    assert t['input'] is None and t['output'] is None and t['total']==1234 and t['incomplete']


def test_tokens_retries_snapshots_ledger_export_old_resume(env):
    run=workflow(env,retries=2)
    calls=[]
    def brain(prompt,body):
        calls.append(1)
        if len(calls)>1: publish(prompt)
        return dict(reply(),usage={'input_tokens':10,'output_tokens':2,'total_tokens':12})
    result,_,_=execute(env,run,brain)
    assert result['status']=='completed'
    assert result['tokens']['total']==36
    assert result['cartridges'][0]['tokens']['total']==24
    for _ in range(3): env.store.save(result)
    assert result['tokens']['total']==36
    blob=ms.build_download(env.store,result)
    z=zipfile.ZipFile(io.BytesIO(blob))
    assert any(n.endswith('run.json') for n in z.namelist())
    assert '10 / 2 / 12' in ms.render_ledger(result)
    # An old record without accounting remains readable and truthful.
    for c in result['cartridges']:
        for a in c['attempts']: a.pop('tokens',None)
    env.store.save(result)
    old=env.store.load('u1',result['id'])
    assert old['tokens']['total'] is None
    assert 'unavailable' in ms.render_ledger(old)
    assert ms.committed_result(env.store,old,'p')['result']['verified']


def test_five_attempt_limit_with_progress_and_no_sixth_on_resume(env):
    run=workflow(env,retries=5,outputs=True)
    calls=[]
    def brain(prompt,body):
        calls.append(1)
        (base(prompt)/'publish/result.json').write_text('{'+str(len(calls)))
        # Candidate files differ, preserving existing no-progress safeguards.
        out=env.store.cartridge_dir(run['id'],'p')/'outputs'
        (out/'answer.txt').write_text(str(len(calls)))
        return reply()
    result,fake,engine=execute(env,run,brain)
    assert len(fake.chats)==5 and len(result['cartridges'][0]['attempts'])==5
    result=asyncio.run(run_to_end(engine,result))
    assert len(fake.chats)==5 and result['status']=='failed'


def test_each_attempt_fresh_1800_no_shared_deadline(env,monkeypatch):
    run=workflow(env,retries=2)
    run['recovery']=ms.recovery_policy()
    budgets=[]
    clock=[0.0]
    import types, time
    monkeypatch.setattr(ms,'time',types.SimpleNamespace(monotonic=lambda:clock[0],time=time.time))
    real=ms.asyncio.wait_for
    async def controlled(coro,timeout):
        if timeout==1800:
            budgets.append(timeout)
        return await real(coro,timeout)
    monkeypatch.setattr(ms.asyncio,'wait_for',controlled)
    calls=[]
    def brain(prompt,body):
        calls.append(1)
        clock[0] += 1790
        if len(calls)>1: publish(prompt)
        return reply()
    result,_,_=execute(env,run,brain)
    assert result['status']=='completed' and budgets==[1800,1800,1800]
    assert all(a['timeout_seconds']==1800 for c in result['cartridges'] for a in c['attempts'])


def test_live_observer_stops_loop_then_existing_publication_recovery(env):
    run=workflow(env,retries=2)
    class LoopFake(FakeOpenWebUI):
        def handler(self,request):
            response=super().handler(request)
            if request.url.path=='/api/v1/chats/chat1':
                value=response.json()
                mid=self.chats['chat1']['completion']['id']
                value['chat']['history']['messages'][mid].update(events(['same']*5))
                return __import__('httpx').Response(200,json=value)
            return response
    def brain(prompt,body):
        if body['chat_id']!='chat1': publish(prompt)
        return reply()
    fake=LoopFake(brain)
    engine=make_engine(env,fake)
    result=asyncio.run(run_to_end(engine,run))
    first,second=result['cartridges'][0]['attempts']
    assert first['code']=='LOOP_DETECTED' and first['loop_evidence']
    assert second['kind']=='publish' and second['failure_context']['code']=='LOOP_DETECTED'
    assert result['status']=='completed' and fake.stopped==['chat1']


def test_timeout_and_cancellation_stop_confirmation(env,monkeypatch):
    class Client:
        def __init__(self): self.calls=[]
        async def request(self,method,path,body=None):
            self.calls.append((method,path))
            return {'task_ids':[]}
    client=Client()
    async def scenario():
        await ms.stop_chat(client,'disposable')
        assert client.calls==[('POST','/api/tasks/chat/disposable/stop'),('GET','/api/tasks/chat/disposable')]
        fake=FakeOpenWebUI(lambda p,b:reply(),busy_polls=100000)
        task=asyncio.create_task(ms.run_chat(fake.client(),model='m',prompt='x',title='x',poll=.01))
        await asyncio.sleep(.02)
        task.cancel()
        with pytest.raises(asyncio.CancelledError): await task
        assert fake.stopped==['chat1']
    asyncio.run(scenario())


def test_unconfirmed_stop_is_hard(env):
    class BadClient:
        async def request(self,*args): raise RuntimeError('stop inaccessible')
    with pytest.raises(RuntimeError): asyncio.run(ms.stop_chat(BadClient(),'x'))


def test_real_short_timeout_recovers_with_fresh_budget(env):
    run=workflow(env,retries=1)
    run['recovery']=ms.recovery_policy({'attempt_seconds':1,'max_attempts':2})
    class TimeoutFake(FakeOpenWebUI):
        def handler(self,request):
            if request.url.path=='/api/tasks/chat/chat2':
                self.chats['chat2']['polls']=self.busy_polls+1
            return super().handler(request)
    def brain(prompt,body):
        if body['chat_id']!='chat1': publish(prompt)
        return reply()
    fake=TimeoutFake(brain,busy_polls=100000)
    engine=make_engine(env,fake)
    # One cartridge keeps the test focused on timeout -> new chat -> commit.
    p=env.store.run_dir('u1',run['id'])/'workflow/magazine.yaml'
    import yaml
    doc=yaml.safe_load(p.read_text());doc['cartridges']=doc['cartridges'][:1];p.write_text(yaml.safe_dump(doc))
    run['cartridges']=run['cartridges'][:1]
    result=asyncio.run(run_to_end(engine,run))
    a,b=result['cartridges'][0]['attempts']
    assert a['code']=='ATTEMPT_TIMEOUT' and b['status']=='done'
    assert a['timeout_seconds']==b['timeout_seconds']==1
    assert fake.stopped==['chat1'] and result['status']=='completed'


def test_failed_stop_blocks_recovery(env):
    run=workflow(env,retries=4)
    class StopFailureFake(FakeOpenWebUI):
        def handler(self,request):
            if request.url.path.endswith('/stop'):
                return __import__('httpx').Response(500,json={'error':'injected stop failure'})
            return super().handler(request)
    def brain(prompt,body):
        engine.stop(run['id'])
        return reply()
    fake=StopFailureFake(brain,busy_polls=100000)
    engine=make_engine(env,fake)
    result=asyncio.run(run_to_end(engine,run))
    assert result['cartridges'][0]['attempts'][0]['code']=='STOP_UNCONFIRMED'
    assert len(fake.chats)==1 and result['status']=='failed'


def test_partial_totals_and_duplicate_legacy_message_identity():
    t=ms.token_usage({'id':'m','done':True,'usage':{'input_tokens':10,'output_tokens':2}})
    a={'chat_id':'c','assistant_id':'m','tokens':t}
    assert ms.sum_tokens([a,a])['total']==12
    totals=ms.sum_tokens([a,{'chat_id':'missing','tokens':ms.token_usage(None)}])
    assert totals['total']==12 and totals['unavailable_attempts']==1 and totals['incomplete']


def test_engine_cancellation_records_interrupted_and_stops_task(env):
    run=workflow(env,retries=4)
    fake=FakeOpenWebUI(lambda p,b:reply(),busy_polls=100000)
    engine=make_engine(env,fake)
    async def scenario():
        engine.start(run,'tok',{})
        task=engine.active[run['id']]
        while not fake.chats: await asyncio.sleep(0)
        await asyncio.sleep(.005)
        task.cancel()
        with pytest.raises(asyncio.CancelledError): await task
    asyncio.run(scenario())
    saved=env.store.load('u1',run['id'])
    assert saved['status']=='interrupted'
    a=saved['cartridges'][0]['attempts'][0]
    assert a['status']=='interrupted' and a['code']=='CANCELLED' and a['tokens']['incomplete']
    assert fake.stopped==['chat1'] and len(fake.chats)==1
