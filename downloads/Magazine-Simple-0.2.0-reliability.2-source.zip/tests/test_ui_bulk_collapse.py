"""Real-browser tests for the two Set-up interface changes: bulk model assignment
and the collapsible "Workflow steps" section.

These tests start Magazine's real routes (the same page and API the installed
function serves) under uvicorn, backed by the fake Open WebUI from
test_magazine_simple.py, and drive the page in Chromium with Playwright.
No model is called. Every browser test runs once per engine (Chromium and Firefox,
both real Playwright builds). A browser that cannot be launched is SKIPPED with an
"UNVERIFIED" reason; it is never replaced by another engine.

Test groups, selectable with -k: *_a11y_* (accessibility), *_layout_* (responsive
layout), *_persist* / *_saved* (what is stored), and the rest (behaviour).
"""
import asyncio
import json
import os
import re
import socket
import sys
import threading
import time
import types
from pathlib import Path

import httpx
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_magazine_simple as base  # noqa: E402

ms = base.ms
sync_api = pytest.importorskip("playwright.sync_api")

MODELS = [{"id": "model-a", "name": "Model A"}, {"id": "model-b", "name": "Model B"},
          {"id": "model-c", "name": "Model C"}, {"id": "model-d", "name": "Model D"}]
N = 26


class UIFake(base.FakeOpenWebUI):
    def handler(self, request):
        if request.url.path == "/api/models":
            return httpx.Response(200, json={"data": MODELS})
        return super().handler(request)


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def live(tmp_path_factory):
    import uvicorn
    from fastapi import FastAPI

    tmp = tmp_path_factory.mktemp("ui")
    library, data, work = tmp / "library", tmp / "data", tmp / "work"
    library.mkdir()
    # a disposable 26-step workflow; each step already names a real model id
    base.write_workflow(library / "big26", [
        {"id": f"c{i:02d}", "prompt": f"Prompt for step {i}", "model": "model-a" if i % 2 else "model-b"}
        for i in range(1, N + 1)], name="Big 26")
    # an older-format workflow (handover, artifacts, a model id), loaded as-is
    base.write_workflow(library / "older", [
        {"id": "o1", "prompt": "Write.", "model": "model-d", "artifacts": {"outputs": ["x.txt"]}},
        {"id": "o2", "prompt": "Read.", "model": "model-d",
         "artifacts": {"inputs": [{"from": "o1", "path": "x.txt"}]}},
        {"id": "o3", "prompt": "Finish.", "model": "model-c"}], name="Older")
    base.write_workflow(library / "single", [{"id": "only", "prompt": "x", "model": "model-a"}], name="Single")
    base.write_workflow(library / "small", [
        {"id": "s1", "prompt": "One", "model": "model-a"}, {"id": "s2", "prompt": "Two", "model": "model-b"}], name="Small")

    mp = pytest.MonkeyPatch()
    user = types.SimpleNamespace(id="u1", role="admin", settings={})
    auth = types.ModuleType("open_webui.utils.auth")
    auth.get_current_user = lambda: user
    config = types.ModuleType("open_webui.config")
    config.DATA_DIR = str(data)
    for name, module in (("open_webui", types.ModuleType("open_webui")),
                         ("open_webui.utils", types.ModuleType("open_webui.utils")),
                         ("open_webui.utils.auth", auth), ("open_webui.config", config)):
        mp.setitem(sys.modules, name, module)
    mp.setattr(ms, "POLL_SECONDS", 0.0)
    mp.setitem(ms._STATE, "engine", None)
    fake = UIFake(lambda prompt, body: "ok")
    app = FastAPI()
    event = ms.Event()
    event.valves.library_root = str(library)
    event.valves.workspace_root = str(work)
    installer = threading.Thread(target=lambda: asyncio.run(event.event(__app__=app)))
    installer.start()          # own thread: Playwright's driver may already own the main thread's loop
    installer.join()
    ms._STATE["engine"].client_factory = lambda token: fake.client()
    port = free_port()
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    for _ in range(100):
        if server.started:
            break
        time.sleep(0.05)
    assert server.started
    yield types.SimpleNamespace(url=f"http://127.0.0.1:{port}", data=data, fake=fake, library=library)
    server.should_exit = True
    thread.join(5)
    mp.undo()


@pytest.fixture(scope="module", params=["chromium", "firefox"])
def browser(request):
    with sync_api.sync_playwright() as p:
        try:
            b = getattr(p, request.param).launch()
        except Exception as exc:
            pytest.skip(f"UNVERIFIED in {request.param}: it could not be launched here ({str(exc).splitlines()[0][:120]})")
        print(f"[engine] {request.param} {b.version}")
        yield b
        b.close()


@pytest.fixture
def page(browser, live):
    ctx = browser.new_context(viewport={"width": 1100, "height": 900})
    pg = ctx.new_page()
    pg.on("dialog", lambda d: d.dismiss())
    errors = []
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.goto(live.url + "/magazine-simple")
    pg.wait_for_function("document.querySelectorAll('#library-workflows option').length > 1")
    pg.wait_for_function("document.querySelectorAll('#model-all option, #terminal-select option').length > 0")
    pg.js_errors = errors
    yield pg
    assert errors == [], errors
    ctx.close()


# ------------------------------------------------------------------ helpers

def load(page, wf):
    page.select_option("#library-workflows", wf)
    with page.expect_response("**/api/magazine-simple/workflows/" + wf) as loaded:
        page.click("#btn-library-select")
    loaded.value.finished()
    page.wait_for_function("name => document.querySelector('#setup-workflow').textContent === name", arg=loaded.value.json()["name"])
    page.wait_for_selector("#cartridge-s:not(.hidden)")
    page.wait_for_function("document.querySelectorAll('#cartridges .cartridge').length > 0")


def summary(page):
    return page.locator("#cartridge-s > summary")


def is_open(page):
    return page.eval_on_selector("#cartridge-s", "d => d.open")


def expand(page):
    if not is_open(page):
        summary(page).click()
    assert is_open(page)


def collapse(page):
    if is_open(page):
        summary(page).click()
    assert not is_open(page)


def models(page):
    return page.eval_on_selector_all("#cartridges select", "els => els.map(e => e.value)")


def ticked(page):
    """1-based numbers of the ticked steps."""
    return page.eval_on_selector_all("#cartridges .pick", "els => els.map((e, i) => e.checked ? i + 1 : 0).filter(Boolean)")


def tick(page, *steps):
    for s in steps:
        page.locator("#cartridges .pick").nth(s - 1).check()


def count_text(page):
    return page.inner_text("#bulk-count")


def bulk_apply(page, model):
    page.select_option("#bulk-model", model)
    page.click("#btn-bulk-apply")


def original(i):
    return "model-a" if i % 2 else "model-b"


ORIGINAL = [original(i) for i in range(1, N + 1)]


def expected_after(changes):
    out = list(ORIGINAL)
    for step, model in changes.items():
        out[step - 1] = model
    return out


def run_records(live):
    return sorted(Path(live.data).rglob("run.json"), key=lambda p: p.stat().st_mtime)


def prepare(page):
    with page.expect_response(lambda r: r.url.endswith("/api/magazine-simple/runs") and r.request.method == "POST") as info:
        page.click("#btn-create")
    resp = info.value
    assert resp.ok, resp.text()
    return resp.request.post_data_json, resp.json()


# ------------------------------------------------------------------ collapsible section

def test_loaded_workflow_starts_collapsed_with_count_visible(page):
    load(page, "big26")
    assert not is_open(page)
    assert summary(page).is_visible()
    assert "Workflow steps — 26" in summary(page).inner_text()
    # everything inside the section is hidden, not just the cartridge list
    for sel in ("#model-mode-control", "#bulk-control", "#cartridges", "#cartridges .cartridge >> nth=0",
                "#cartridges .prompt >> nth=0", "#cartridges select >> nth=0", "#btn-bulk-apply"):
        assert not page.locator(sel).is_visible(), sel
    # other controls and the rest of the page stay reachable without scrolling through 26 cartridges
    collapsed_top = page.eval_on_selector("#tools-heading", "e => e.getBoundingClientRect().top + scrollY")
    expand(page)
    expanded_top = page.eval_on_selector("#tools-heading", "e => e.getBoundingClientRect().top + scrollY")
    assert collapsed_top < 800 and expanded_top - collapsed_top > 2000, (collapsed_top, expanded_top)   # collapsed: tools are on the first screen
    assert "Workflow steps — 26" in summary(page).inner_text()


def test_toggle_by_mouse_and_keyboard(page):
    load(page, "big26")
    assert not is_open(page)
    summary(page).focus()
    page.keyboard.press("Enter")
    assert is_open(page)
    page.keyboard.press("Space")
    assert not is_open(page)
    summary(page).click()
    assert is_open(page)
    page.locator("#cartridge-badge").click()          # the whole heading line is the control
    assert not is_open(page)
    summary(page).locator("h3").click()               # ...including the heading text itself
    assert is_open(page)


def test_collapse_and_expand_preserve_everything(page):
    load(page, "big26")
    expand(page)
    tick(page, 2, 4, 7, 10, 15)
    bulk_apply(page, "model-c")
    page.select_option("#bulk-model", "model-d")                 # a half-finished choice
    page.select_option("#model-4", "model-d")                    # an unsaved individual edit (step 5)
    page.locator("#delete-details > summary").click()            # unrelated disclosure, left open
    before = dict(models=models(page), ticked=ticked(page), count=count_text(page), bulk=page.input_value("#bulk-model"),
                  prepare=page.is_enabled("#btn-create"), same=page.input_value("#model-mode"),
                  help=page.inner_text("#prepare-help"))
    row = page.eval_on_selector("#cartridges .cartridge", "e => (window.__row = e, true)")
    requests = []
    page.on("request", lambda r: requests.append(r.url) if "/api/magazine-simple/" in r.url else None)
    collapse(page)
    assert not page.locator("#cartridges").is_visible()
    assert "Workflow steps — 26" in summary(page).inner_text()
    assert page.is_visible("#delete-details > summary") and page.eval_on_selector("#delete-details", "d => d.open")
    expand(page)
    after = dict(models=models(page), ticked=ticked(page), count=count_text(page), bulk=page.input_value("#bulk-model"),
                 prepare=page.is_enabled("#btn-create"), same=page.input_value("#model-mode"),
                 help=page.inner_text("#prepare-help"))
    assert after == before
    assert before["ticked"] == [2, 4, 7, 10, 15] and before["models"][4] == "model-d"
    assert page.eval_on_selector("#cartridges .cartridge", "e => e === window.__row")   # same DOM node: nothing rebuilt
    assert requests == []                                                              # no save, no run, no refresh


def test_ledger_and_other_controls_unaffected_by_collapse(page, live):
    load(page, "small")
    expand(page)
    page.click("#btn-create")
    page.wait_for_selector("#run-result:not(.hidden)")
    page.locator("#run-result details > summary").click()                # open the Ledger
    assert page.eval_on_selector("#run-ledger", "e => e.closest('details').open")
    collapse(page)
    assert page.eval_on_selector("#run-ledger", "e => e.closest('details').open")     # Ledger keeps its own state
    page.locator("#run-result details > summary").click()
    expand(page)
    assert not page.eval_on_selector("#run-ledger", "e => e.closest('details').open")
    assert page.is_enabled("#btn-start") and page.is_enabled("#btn-refresh-run")
    page.click("#btn-refresh-run")
    page.click("#add-details > summary")
    assert page.eval_on_selector("#add-details", "d => d.open")


def test_load_again_resets_selection_and_collapses(page):
    load(page, "big26")
    expand(page)
    tick(page, 3, 5)
    assert ticked(page) == [3, 5]
    load(page, "small")                                   # the workflow changed
    assert not is_open(page)
    assert "Workflow steps — 2" in summary(page).inner_text()
    expand(page)
    assert ticked(page) == [] and count_text(page) == "0 of 2 selected"
    load(page, "big26")                                   # and back: nothing carried over
    expand(page)
    assert ticked(page) == [] and count_text(page) == "0 of 26 selected"


# ------------------------------------------------------------------ bulk assignment

def test_checkbox_labels_and_clicking_does_not_toggle_or_change_anything(page):
    load(page, "big26")
    expand(page)
    box = page.get_by_role("checkbox", name="Select Step 2: c02")
    assert box.count() == 1
    assert page.get_by_role("checkbox", name="Select Step 26: c26").count() == 1
    before = models(page)
    box.check()
    assert is_open(page)                                  # a checkbox does not collapse the section
    assert ticked(page) == [2] and models(page) == before
    box.uncheck()
    assert ticked(page) == [] and models(page) == before and is_open(page)
    page.locator("#cartridges .ord").nth(2).click()        # the step number is part of the checkbox's label
    assert ticked(page) == [3] and is_open(page)
    page.locator("#cartridges .ord").nth(2).click()
    assert ticked(page) == [] and models(page) == before and is_open(page)


def test_selection_controls_and_counter(page):
    load(page, "big26")
    expand(page)
    assert count_text(page) == "0 of 26 selected"
    assert page.is_disabled("#btn-bulk-clear") and page.is_disabled("#btn-bulk-apply")
    tick(page, 9)
    assert count_text(page) == "1 of 26 selected"
    tick(page, 2, 4, 7, 10, 15)
    assert ticked(page) == [2, 4, 7, 9, 10, 15] and count_text(page) == "6 of 26 selected"
    page.click("#btn-bulk-select-all")
    assert ticked(page) == list(range(1, N + 1)) and count_text(page) == "26 of 26 selected"
    page.click("#btn-bulk-clear")
    assert ticked(page) == [] and count_text(page) == "0 of 26 selected"
    assert page.is_disabled("#btn-bulk-clear")


def test_apply_is_disabled_without_selection_or_model(page):
    load(page, "big26")
    expand(page)
    assert page.input_value("#bulk-model") == ""
    assert page.is_disabled("#btn-bulk-apply")
    page.select_option("#bulk-model", "model-c")
    assert page.is_disabled("#btn-bulk-apply")                       # model, nobody selected
    tick(page, 1)
    assert page.is_enabled("#btn-bulk-apply")
    page.select_option("#bulk-model", "")
    assert page.is_disabled("#btn-bulk-apply")                       # selected, no model
    assert models(page) == ORIGINAL


def test_bulk_model_list_comes_from_open_webui(page):
    load(page, "big26")
    expand(page)
    got = page.eval_on_selector_all("#bulk-model option", "os => os.map(o => [o.value, o.textContent])")
    assert got[0][0] == "" and got[1:] == [[m["id"], m["name"]] for m in MODELS]
    per_step = page.eval_on_selector_all("#model-0 option", "os => os.map(o => [o.value, o.textContent])")
    assert per_step == got


def test_bulk_apply_only_changes_selected_then_group_two_then_individual_edit(page):
    load(page, "big26")
    expand(page)
    assert models(page) == ORIGINAL
    tick(page, 2, 4, 7, 10, 15)
    bulk_apply(page, "model-c")
    assert models(page) == expected_after({s: "model-c" for s in (2, 4, 7, 10, 15)})
    assert ticked(page) == [2, 4, 7, 10, 15]                          # selection survives the apply
    assert "Set Model C for 5 steps." in page.inner_text("#bulk-msg")
    # another group, with a different model (steps 4 and 26 are new/overlapping)
    page.click("#btn-bulk-clear")
    tick(page, 1, 4, 26)
    bulk_apply(page, "model-d")
    want = expected_after({**{s: "model-c" for s in (2, 7, 10, 15)}, **{s: "model-d" for s in (1, 4, 26)}})
    assert models(page) == want
    # the existing per-step control still works, and affects only its own step
    page.select_option("#model-6", "model-b")     # step 7
    want[6] = "model-b"
    assert models(page) == want
    assert page.is_enabled("#btn-create")


def test_single_selection_and_select_all_apply(page):
    load(page, "big26")
    expand(page)
    tick(page, 13)
    bulk_apply(page, "model-d")
    assert models(page) == expected_after({13: "model-d"})
    page.click("#btn-bulk-select-all")
    bulk_apply(page, "model-b")
    assert models(page) == ["model-b"] * N


def test_switching_between_shared_and_individual_modes(page):
    load(page, "big26")
    expand(page)
    tick(page, 2, 4)
    bulk_apply(page, "model-c")
    before = models(page)
    page.select_option("#model-mode", "shared")
    assert not page.locator("#bulk-control").is_visible()             # bulk controls only in per-step mode
    assert not page.locator("#cartridges .pick >> nth=0").is_visible()
    assert page.locator("#shared-model-control").is_visible()
    assert models(page) == before                                     # nothing silently rewritten
    page.select_option("#model-mode", "independent")
    assert page.locator("#bulk-control").is_visible() and page.locator("#cartridges .pick >> nth=0").is_visible()
    assert models(page) == before and ticked(page) == [2, 4]
    # shared mode still behaves as before: one model for every step in the saved choice
    page.select_option("#model-mode", "shared")
    page.select_option("#model-all", "model-d")
    payload, run = prepare(page)
    assert payload["model_map"] == {f"c{i:02d}": "model-d" for i in range(1, N + 1)}
    assert [c["model"] for c in run["cartridges"]] == ["model-d"] * N


def test_one_step_workflow_has_no_bulk_controls(page):
    load(page, "single")
    expand(page)
    assert "Workflow steps — 1" in summary(page).inner_text()
    assert not page.locator("#bulk-control").is_visible() and not page.locator("#model-mode-control").is_visible()
    assert page.is_enabled("#btn-create")


# ------------------------------------------------------------------ saved data

def test_prepare_saves_models_in_existing_fields_and_not_the_selection(page, live):
    load(page, "big26")
    expand(page)
    tick(page, 2, 4, 7, 10, 15)
    bulk_apply(page, "model-c")
    want = expected_after({s: "model-c" for s in (2, 4, 7, 10, 15)})
    collapse(page)
    payload, run = prepare(page)
    assert sorted(payload) == ["model_map", "terminal_id", "tool_ids", "workflow_id"]   # same request as before
    assert payload["model_map"] == {f"c{i:02d}": m for i, m in enumerate(want, 1)}
    assert [c["model"] for c in run["cartridges"]] == want
    saved = json.loads(run_records(live)[-1].read_text(encoding="utf-8"))
    assert saved["id"] == run["id"] and [c["model"] for c in saved["cartridges"]] == want
    assert not any(k in saved for k in ("selection", "selected", "checked", "collapsed", "open"))
    for c in saved["cartridges"]:
        assert not any(k in c for k in ("selected", "checked", "pick", "collapsed"))


def test_reopen_saved_run_shows_assigned_models_and_reload_clears_ui_state(page, live):
    load(page, "big26")
    expand(page)
    tick(page, 2, 4, 7, 10, 15)
    bulk_apply(page, "model-c")
    _, run = prepare(page)
    want = [c["model"] for c in run["cartridges"]]
    page.reload()
    page.wait_for_function("document.querySelectorAll('#history-runs option').length > 0 && document.querySelector('#history-runs').value")
    page.select_option("#history-runs", run["id"])
    page.click("#btn-history-open")
    page.wait_for_selector("#run-result:not(.hidden)")
    page.wait_for_function("document.querySelectorAll('#run-steps li').length === 26")
    shown = page.eval_on_selector_all("#run-steps li", "ls => ls.map(l => l.textContent)")
    for i, (text, model) in enumerate(zip(shown, want), 1):
        assert text.startswith(f"c{i:02d} — waiting · {model} "), text
    page.locator("#run-result details > summary").click()
    ledger = page.inner_text("#run-ledger")
    assert ledger.count("model-c") == 5
    # loading the workflow again in Set up starts from the workflow file (as in 0.2.0): collapsed, nothing ticked
    load(page, "big26")
    assert not is_open(page)
    expand(page)
    assert models(page) == ORIGINAL and ticked(page) == []


def test_older_workflow_loads_unchanged_and_bulk_works(page, live):
    before = {p.name: p.read_bytes() for p in (live.library / "older").rglob("*") if p.is_file()}
    load(page, "older")
    expand(page)
    assert models(page) == ["model-d", "model-d", "model-c"]            # the file's own model ids, no migration
    tick(page, 1, 3)
    bulk_apply(page, "model-a")
    payload, run = prepare(page)
    assert payload["model_map"] == {"o1": "model-a", "o2": "model-d", "o3": "model-a"}
    assert {p.name: p.read_bytes() for p in (live.library / "older").rglob("*") if p.is_file()} == before  # workflow untouched


def test_prepared_run_would_send_the_assigned_models_to_open_webui(page, live):
    """Starts the prepared run against the fake Open WebUI (no model, no inference)
    and checks the model id Magazine sends for every step's chat."""
    load(page, "big26")
    expand(page)
    tick(page, 2, 4, 7, 10, 15)
    bulk_apply(page, "model-c")
    want = expected_after({s: "model-c" for s in (2, 4, 7, 10, 15)})
    _, run = prepare(page)
    live.fake.chats.clear()
    r = httpx.post(f"{live.url}/api/magazine-simple/runs/{run['id']}/start", timeout=10)
    assert r.status_code == 200, r.text
    for _ in range(300):
        d = httpx.get(f"{live.url}/api/magazine-simple/runs/{run['id']}", timeout=10).json()
        if d["status"] not in ("running", "queued"):
            break
        time.sleep(0.05)
    assert d["status"] == "completed", d["status"]
    sent = [live.fake.chats[f"chat{i}"]["completion"]["model"] for i in range(1, N + 1)]
    assert sent == want
    assert [c["model"] for c in d["cartridges"]] == want


# ------------------------------------------------------------------ narrow window

@pytest.mark.parametrize("width", [375, 640])
def test_narrow_window_layout(page, width):
    page.set_viewport_size({"width": width, "height": 800})
    load(page, "big26")
    expand(page)
    assert page.eval_on_selector("body", "b => document.documentElement.scrollWidth <= window.innerWidth + 1")
    for sel in ("#btn-bulk-select-all", "#btn-bulk-clear", "#bulk-model", "#btn-bulk-apply", "#cartridges .pick >> nth=0"):
        box = page.locator(sel).bounding_box()
        assert box and box["x"] >= 0 and box["x"] + box["width"] <= width + 1, (sel, box)
    tick(page, 2, 4)
    bulk_apply(page, "model-c")
    assert models(page)[1] == "model-c" and models(page)[2] == "model-a"


# ------------------------------------------------------------------ engine record

def test_engine_and_version_recorded(browser):
    print(f"[engine-version] {browser.browser_type.name} {browser.version}")
    assert browser.version


# ------------------------------------------------------------------ accessibility

def chromium_only(browser):
    if browser.browser_type.name != "chromium":
        pytest.skip("Chromium only: needs the DevTools accessibility tree, which Playwright cannot read in Firefox")


def ax_tree(page):
    cdp = page.context.new_cdp_session(page)
    nodes = cdp.send("Accessibility.getFullAXTree")["nodes"]
    out = []
    for n in nodes:
        out.append(dict(id=n["nodeId"], role=n.get("role", {}).get("value"), name=(n.get("name") or {}).get("value", ""),
                        ignored=n.get("ignored", False), children=n.get("childIds", []),
                        props={p["name"]: p["value"].get("value") for p in n.get("properties", [])}))
    return out


def test_a11y_disclosure_heading_and_checkboxes_in_the_accessibility_tree(browser, page):
    chromium_only(browser)
    load(page, "big26")
    tree = ax_tree(page)
    by_id = {n["id"]: n for n in tree}
    disclosure = [n for n in tree if n["role"] == "DisclosureTriangle" and "Workflow steps" in n["name"]]
    assert len(disclosure) == 1
    d = disclosure[0]
    assert d["name"] == "Workflow steps — 26 in order"           # one readable name, with the count
    assert d["props"]["expanded"] is False
    headings = [n for n in tree if n["role"] == "heading" and "Workflow steps" in n["name"]]
    assert len(headings) == 1 and headings[0]["name"] == "Workflow steps — 26" and headings[0]["props"]["level"] == 3
    assert headings[0]["id"] in d["children"]                      # the heading sits inside the disclosure control
    # collapsed: the content is not exposed to assistive technology at all
    assert not [n for n in tree if n["role"] == "checkbox" and n["name"].startswith("Select Step")]
    expand(page)
    tree = ax_tree(page)
    d = [n for n in tree if n["role"] == "DisclosureTriangle" and "Workflow steps" in n["name"]][0]
    assert d["props"]["expanded"] is True
    boxes = {n["name"] for n in tree if n["role"] == "checkbox" and n["name"].startswith("Select Step")}
    assert boxes == {f"Select Step {i}: c{i:02d}" for i in range(1, N + 1)}
    collapse(page)
    d = [n for n in ax_tree(page) if n["role"] == "DisclosureTriangle" and "Workflow steps" in n["name"]][0]
    assert d["props"]["expanded"] is False


def test_a11y_heading_name_and_checkbox_labels(page):
    """Playwright's own ARIA role engine (the same code in both browsers); not the browser's accessibility tree."""
    load(page, "big26")
    assert page.get_by_role("heading", name="Workflow steps — 26", level=3).count() == 1
    assert summary(page).locator("h3").count() == 1                 # the heading is inside the native summary
    assert re.sub(r"\s+", " ", summary(page).text_content()).strip() == "Workflow steps — 26 in order"
    assert page.get_by_role("checkbox", name=re.compile("^Select Step")).count() == 0      # hidden while collapsed
    expand(page)
    names = [page.get_by_role("checkbox", name=re.compile("^Select Step")).nth(i).get_attribute("aria-label") for i in range(N)]
    assert names == [f"Select Step {i}: c{i:02d}" for i in range(1, N + 1)]


def test_a11y_native_disclosure_with_no_redundant_aria(page):
    load(page, "big26")
    attrs = page.evaluate("""() => ['#cartridge-s', '#cartridge-s > summary', '#cartridge-s > summary h3'].map(
        sel => [...document.querySelector(sel).attributes].map(a => a.name).filter(n => n.startsWith('aria-') || n === 'role' || n === 'tabindex'))""")
    assert attrs == [[], [], []]
    assert page.evaluate("document.querySelector('#cartridge-s').tagName + '/' + document.querySelector('#cartridge-s > summary').tagName") == "DETAILS/SUMMARY"


def tab_to(page, selector, back=False, limit=400):
    for _ in range(limit):
        page.keyboard.press("Shift+Tab" if back else "Tab")
        if page.evaluate("sel => document.activeElement && document.activeElement.matches(sel)", selector):
            return
    raise AssertionError(f"could not reach {selector} with the keyboard")


def test_a11y_focus_indicator_and_keyboard_only_workflow(page):
    load(page, "big26")
    tab_to(page, "#cartridge-s > summary")
    outline = page.evaluate("() => { const s = getComputedStyle(document.activeElement); return [s.outlineStyle, parseFloat(s.outlineWidth)]; }")
    assert outline[0] != "none" and outline[1] >= 2, outline                # visible keyboard focus on the disclosure
    page.keyboard.press("Enter")
    assert is_open(page)
    for step in (2, 7):                                                     # tick steps 2 and 7 with the keyboard
        tab_to(page, f'#cartridges .pick[data-index="{step - 1}"]')
        page.keyboard.press("Space")
        box = page.evaluate("() => { const s = getComputedStyle(document.activeElement); return [s.outlineStyle, parseFloat(s.outlineWidth)]; }")
        assert box[0] != "none" and box[1] >= 2, box                        # and the checkbox shows focus too
    assert ticked(page) == [2, 7] and is_open(page)
    tab_to(page, "#bulk-model", back=True)
    for _ in range(3):
        page.keyboard.press("ArrowDown")                                    # placeholder -> A -> B -> C
    assert page.input_value("#bulk-model") == "model-c"
    tab_to(page, "#btn-bulk-apply")
    page.keyboard.press("Enter")
    assert models(page) == expected_after({2: "model-c", 7: "model-c"})
    tab_to(page, "#cartridge-s > summary", back=True)
    page.keyboard.press("Space")
    assert not is_open(page)
    assert page.evaluate("document.activeElement.matches('#cartridge-s > summary')")       # focus stays on the heading
    assert ticked(page) == [2, 7] and models(page)[1] == "model-c"


def luminance(rgb):
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    return 0.2126 * ch(rgb[0]) + 0.7152 * ch(rgb[1]) + 0.0722 * ch(rgb[2])


CONTRAST_JS = """sel => {
  const el = document.querySelector(sel);
  const parse = c => { const m = c.match(/[\\d.]+/g).map(Number); return [m[0], m[1], m[2], m.length > 3 ? m[3] : 1]; };
  const over = (top, bottom) => top.slice(0, 3).map((v, i) => v * top[3] + bottom[i] * (1 - top[3]));
  let bg = [255, 255, 255, 1]; const chain = [];
  for (let e = el; e; e = e.parentElement) chain.push(parse(getComputedStyle(e).backgroundColor));
  for (const c of chain.reverse()) bg = over(c, bg).concat([1]);
  return { fg: parse(getComputedStyle(el).color).slice(0, 3), bg: bg.slice(0, 3) };
}"""


@pytest.mark.parametrize("theme", ["light", "dark"])
def test_a11y_text_contrast_of_the_new_controls(page, theme):
    page.select_option("#appearance", theme)
    assert page.evaluate("document.documentElement.getAttribute('data-theme')") == theme
    load(page, "big26")
    expand(page)
    tick(page, 2, 4)
    bulk_apply(page, "model-c")
    checks = ["#cartridge-s > summary", "#cartridge-s > summary .badge", "#bulk-count", "#bulk-control label", "#bulk-msg",
              "#btn-bulk-select-all", "#btn-bulk-clear", "#btn-bulk-apply", "#bulk-model", "#cartridges .ord", "#cartridges .id",
              "#cartridges .mk", "#cartridges .prompt", "#cartridges select"]
    for sel in checks:
        c = page.evaluate(CONTRAST_JS, sel)
        ratio = (max(luminance(c["fg"]), luminance(c["bg"])) + 0.05) / (min(luminance(c["fg"]), luminance(c["bg"])) + 0.05)
        assert ratio >= 4.5, (theme, sel, round(ratio, 2), c)


# ------------------------------------------------------------------ layout

VIEWPORTS = [(1920, 1080), (1366, 768), (640, 900), (375, 800)]


@pytest.mark.parametrize("vw,vh", VIEWPORTS)
def test_layout_no_overflow_clipping_or_overlap(page, vw, vh):
    page.set_viewport_size({"width": vw, "height": vh})
    load(page, "big26")
    expand(page)
    tick(page, 2, 4, 7, 10, 15)
    bulk_apply(page, "model-c")
    result = page.evaluate("""() => {
      const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const out = { overflowX: document.documentElement.scrollWidth - window.innerWidth, clipped: [], offscreen: [], overlaps: [], tiny: [] };
      const q = s => [...document.querySelectorAll(s)].filter(vis);
      // text that does not fit its own box (labels, buttons, headings, badges)
      for (const e of q('#cartridge-s > summary, #cartridge-s > summary .badge, #bulk-control button, #bulk-count, #bulk-control label, #cartridges .mk, #cartridges .ord, #cartridges .id')) {
        if (e.clientWidth > 0 && e.scrollWidth > e.clientWidth + 1) out.clipped.push(e.id || e.className || e.tagName);
      }
      // every control inside the window
      for (const e of q('#cartridge-s button, #cartridge-s select, #cartridge-s input')) {
        const r = e.getBoundingClientRect();
        if (r.left < -1 || r.right > window.innerWidth + 1) out.offscreen.push((e.id || e.className) + ' ' + Math.round(r.left) + '..' + Math.round(r.right));
      }
      // controls that overlap each other: the bulk block, and four sample rows
      const groups = [q('#bulk-control button, #bulk-control select, #bulk-control label, #bulk-count, #bulk-msg')];
      const rows = q('#cartridges .cartridge');
      for (const i of [0, 1, 12, rows.length - 1]) groups.push([...rows[i].children].filter(vis).concat([...rows[i].querySelectorAll('.pick, .ord, select, .mk')].filter(vis)));
      for (const g of groups) {
        const uniq = [...new Set(g)].filter(a => !g.some(b => b !== a && a.contains(b)));
        for (let i = 0; i < uniq.length; i++) for (let j = i + 1; j < uniq.length; j++) {
          const a = uniq[i].getBoundingClientRect(), b = uniq[j].getBoundingClientRect();
          const w = Math.min(a.right, b.right) - Math.max(a.left, b.left), h = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
          if (w > 1 && h > 1) out.overlaps.push((uniq[i].id || uniq[i].className) + ' x ' + (uniq[j].id || uniq[j].className));
        }
      }
      // controls big enough to use
      // (the checkbox's click target is its label, which holds the step number too; 24 px is WCAG 2.2's minimum target size)
      for (const e of q('#bulk-model, #cartridges select, #cartridges .lead, #bulk-control button')) {
        const r = e.getBoundingClientRect();
        if ((e.tagName === 'SELECT' && r.width < 120) || r.height < 24 || r.width < 24) out.tiny.push((e.id || e.className) + ' ' + Math.round(r.width) + 'x' + Math.round(r.height));
      }
      return out;
    }""")
    assert result["overflowX"] <= 1, json.dumps(result)
    assert result["clipped"] == [] and result["offscreen"] == [] and result["overlaps"] == [] and result["tiny"] == [], json.dumps(result)
    # the dropdown list itself works at this width
    page.select_option("#model-12", "model-d")
    assert models(page)[12] == "model-d"


# ------------------------------------------------------------------ persistence (existing 0.2.0 behaviour)

def saved_run(live, run_id):
    for p in Path(live.data).rglob("run.json"):
        d = json.loads(p.read_text(encoding="utf-8"))
        if d.get("id") == run_id:
            return d
    raise AssertionError(f"run {run_id} not found on disk")


def shape(x):
    if isinstance(x, dict):
        return {k: shape(v) for k, v in sorted(x.items())}
    if isinstance(x, list):
        return [shape(x[0])] if x else []
    return type(x).__name__


def test_persist_bulk_and_individual_assignment_store_the_same_thing(page, live):
    group = (2, 4, 7, 10, 15)
    load(page, "big26")
    expand(page)
    tick(page, *group)
    bulk_apply(page, "model-c")
    payload_bulk, run_bulk = prepare(page)
    load(page, "big26")                                   # back to the workflow file's own models
    expand(page)
    assert models(page) == ORIGINAL
    for s in group:
        page.select_option(f"#model-{s - 1}", "model-c")  # the same result, one control at a time
    payload_single, run_single = prepare(page)
    assert payload_bulk == payload_single
    a, b = saved_run(live, run_bulk["id"]), saved_run(live, run_single["id"])
    assert [c["model"] for c in a["cartridges"]] == [c["model"] for c in b["cartridges"]] == expected_after({s: "model-c" for s in group})
    assert shape(a) == shape(b)                           # same record layout
    for key in ("id", "created", "updated", "work_folder"):
        a.pop(key, None), b.pop(key, None)
    assert a == b                                         # and, apart from identity, the same record
    for record in (a, b):
        assert not any(k in json.dumps(record) for k in ('"selected"', '"checked"', '"collapsed"', '"pick"'))


def test_persist_models_live_in_the_run_not_in_the_workflow_file(page, live):
    files = lambda: {str(p.relative_to(live.library / "big26")): p.read_bytes() for p in (live.library / "big26").rglob("*") if p.is_file()}
    before = files()
    load(page, "big26")
    expand(page)
    page.click("#btn-bulk-select-all")
    bulk_apply(page, "model-d")
    _, run = prepare(page)
    assert [c["model"] for c in saved_run(live, run["id"])["cartridges"]] == ["model-d"] * N     # kept in the prepared run
    assert files() == before                                                                      # the reusable workflow is untouched
    assert b"model-d" not in b"".join(files().values())
    load(page, "big26")                                                                           # so loading it again starts from the file
    expand(page)
    assert models(page) == ORIGINAL


def test_persist_interface_does_not_claim_the_workflow_was_saved(page):
    load(page, "big26")
    expand(page)
    page.click("#btn-bulk-select-all")
    bulk_apply(page, "model-d")
    note = page.inner_text("#prepare-note")
    assert "for this run" in note and "doesn't change the workflow" in note
    _, _ = prepare(page)
    text = (page.inner_text("body") + " " + page.inner_text("#cartridge-s")).lower()
    for phrase in ("saved to workflow", "saved to the workflow", "workflow saved", "saved in the workflow", "saved as default", "saved permanently"):
        assert phrase not in text, phrase
    assert page.inner_text("#create-msg") == "Your workflow is ready. Nothing has started."


# ------------------------------------------------------------------ screenshots (only when SHOTS_DIR is set)

@pytest.mark.skipif(not os.environ.get("SHOTS_DIR"), reason="set SHOTS_DIR to write review screenshots")
@pytest.mark.parametrize("theme", ["light", "dark"])
@pytest.mark.parametrize("vw,vh", VIEWPORTS)
def test_screenshots_for_review(browser, page, vw, vh, theme):
    out = Path(os.environ["SHOTS_DIR"])
    out.mkdir(parents=True, exist_ok=True)
    name = f"{browser.browser_type.name}-{vw}x{vh}-{theme}"
    page.set_viewport_size({"width": vw, "height": vh})
    page.select_option("#appearance", theme)
    load(page, "big26")
    page.evaluate("document.querySelector('#setup-heading').scrollIntoView(); window.scrollBy(0, -12)")
    page.screenshot(path=str(out / f"{name}-1-collapsed.png"))
    expand(page)
    tick(page, 2, 4, 7, 10, 15)
    bulk_apply(page, "model-c")
    page.evaluate("document.querySelector('#cartridge-s').scrollIntoView(); window.scrollBy(0, -12)")
    page.screenshot(path=str(out / f"{name}-2-expanded-bulk-selection.png"))
