"""0.2.0-exec.4: the "Delete previous work" block on the page, in a real browser against the fake Open WebUI.
Runs once per engine; where Firefox cannot be launched the Firefox cases are skipped as UNVERIFIED, never passed."""
import httpx
import pytest

from test_ui_bulk_collapse import browser, live, load, prepare  # noqa: F401  (fixtures and helpers)

LIST = "#history-delete-list input[type=checkbox]"


@pytest.fixture
def page(browser, live):  # noqa: F811
    ctx = browser.new_context(viewport={"width": 1100, "height": 900})
    pg = ctx.new_page()
    pg.answers, pg.asked, errors = [], [], []

    def on_dialog(d):
        pg.asked.append(d.message)
        (d.accept if (pg.answers.pop(0) if pg.answers else False) else d.dismiss)()
    pg.on("dialog", on_dialog)
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.goto(live.url + "/magazine-simple")
    pg.wait_for_function("document.querySelectorAll('#library-workflows option').length > 1")
    yield pg
    assert errors == [], errors
    ctx.close()


def server_runs(live):
    return [r["id"] for r in httpx.get(live.url + "/api/magazine-simple/runs", timeout=10).json()["runs"]]


def make_runs(page, live, n):
    ids = []
    for _ in range(n):
        load(page, "small")
        ids.append(prepare(page)[1]["id"])
        page.wait_for_function(f"document.querySelectorAll('{LIST}').length === {len(server_runs(live))}")
    return ids


def boxes(page):
    return page.eval_on_selector_all(LIST, "els => els.map(e => [e.value, e.checked])")


def test_delete_selected_then_all(page, live):
    httpx.post(live.url + "/api/magazine-simple/runs/delete", json={"all": True}, timeout=10)   # a clean start
    page.click("#btn-history-refresh")
    page.wait_for_function(f"document.querySelectorAll('{LIST}').length === 0")
    assert not page.eval_on_selector("#history-delete-details", "d => d.open")                # closed until asked for
    page.click("#history-delete-details > summary")
    assert page.inner_text("#history-delete-list").strip() == "No previous work to delete."
    assert page.is_disabled("#btn-history-delete-selected") and page.is_disabled("#btn-history-delete-all")

    a, b, c = make_runs(page, live, 3)
    assert sorted(v for v, _ in boxes(page)) == sorted([a, b, c]) and not any(t for _, t in boxes(page))
    assert page.is_disabled("#btn-history-delete-selected") and page.is_enabled("#btn-history-delete-all")
    assert page.is_visible("#run-result")                                                       # run c is on screen

    page.check(f"{LIST}[value='{a}']")
    assert page.is_enabled("#btn-history-delete-selected")
    page.click("#btn-history-delete-select-all")
    assert all(t for _, t in boxes(page))
    page.click("#btn-history-delete-clear")
    assert not any(t for _, t in boxes(page)) and page.is_disabled("#btn-history-delete-selected")

    page.check(f"{LIST}[value='{a}']")
    page.click("#btn-history-delete-selected")                                                  # answered "Cancel"
    assert "removed for good" in page.asked[-1] and "chats stay" in page.asked[-1]
    assert sorted(server_runs(live)) == sorted([a, b, c])                                       # nothing happened

    page.answers.append(True)
    page.click("#btn-history-delete-selected")
    page.wait_for_function(f"document.querySelectorAll('{LIST}').length === 2")
    assert sorted(server_runs(live)) == sorted([b, c])
    assert page.inner_text("#history-delete-msg") == "Deleted 1 item of previous work."
    assert page.eval_on_selector_all("#history-runs option", "o => o.map(x => x.value)").count(a) == 0
    assert page.is_visible("#run-result")                                                       # c is still open

    page.answers.append(True)
    page.click("#btn-history-delete-all")
    page.wait_for_function(f"document.querySelectorAll('{LIST}').length === 0")
    assert "all 2 items" in page.asked[-1] and server_runs(live) == []
    assert page.inner_text("#history-delete-msg") == "Deleted 2 items of previous work."
    assert page.is_hidden("#run-result") and page.is_visible("#run-empty") and page.is_hidden("#btn-download")
    assert page.eval_on_selector_all("#history-runs option", "o => o.map(x => x.textContent)") == ["No previous work yet"]
    assert page.is_disabled("#btn-history-delete-all")
    assert sorted(p.name for p in live.library.iterdir() if p.is_dir())                         # workflows untouched


def test_keyboard_and_narrow_layout(page, live):
    make_runs(page, live, 1)
    page.set_viewport_size({"width": 375, "height": 800})
    page.focus("#history-delete-details > summary")
    page.keyboard.press("Enter")
    assert page.eval_on_selector("#history-delete-details", "d => d.open")
    assert page.eval_on_selector("body", "b => document.documentElement.scrollWidth <= window.innerWidth + 1")
    for sel in ("#btn-history-delete-select-all", "#btn-history-delete-clear", "#btn-history-delete-selected",
                "#btn-history-delete-all"):
        box = page.locator(sel).bounding_box()
        assert box["x"] >= 0 and box["x"] + box["width"] <= 376 and box["height"] >= 24, (sel, box)
    name = page.eval_on_selector(LIST, "e => e.closest('label').innerText")
    assert "Small" in name or "small" in name.lower()


def test_a_refused_deletion_is_shown_as_a_failure_and_nothing_disappears(page, live):
    """The server's answer for a run that is running, as the page must present it. The reply is supplied to the
    page directly, so the real run is never touched."""
    (a,) = make_runs(page, live, 1)
    before = sorted(server_runs(live))
    page.click("#history-delete-details > summary")
    page.route("**/api/magazine-simple/runs/delete", lambda route: route.fulfill(
        status=200, content_type="application/json",
        body='{"deleted": [], "failed": [{"id": "%s", "error": "Small (%s) is running or waiting. Stop it first."}]}' % (a, a)))
    page.check(f"{LIST}[value='{a}']")
    page.answers.append(True)
    page.click("#btn-history-delete-selected")
    page.wait_for_function("document.getElementById('history-delete-msg').textContent.indexOf('Could not delete') >= 0")
    text = page.inner_text("#history-delete-msg")
    assert text.startswith("Deleted 0 items of previous work. Could not delete 1:") and "is running or waiting" in text
    assert "err" in page.get_attribute("#history-delete-msg", "class")
    assert a in [v for v, _ in boxes(page)] and sorted(server_runs(live)) == before
    page.unroute("**/api/magazine-simple/runs/delete")
    page.route("**/api/magazine-simple/runs/delete", lambda route: route.fulfill(
        status=500, content_type="application/json", body='{"detail": "Unexpected error: disk"}'))
    page.answers.append(True)
    page.click("#btn-history-delete-all")
    page.wait_for_function("document.getElementById('history-delete-msg').textContent.indexOf('disk') >= 0")
    assert "err" in page.get_attribute("#history-delete-msg", "class") and sorted(server_runs(live)) == before
