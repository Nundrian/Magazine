Magazine Simple 0.3.0-scheduler.rc1 — source-only package
For Open WebUI 0.12.5.

This is NOT a Magazine workflow ZIP. Do not use Add a workflow to import it.

To install or update:
1. Back up the existing Function, valves and Magazine storage.
2. Ensure no running or queued Magazine projects remain.
3. In Open WebUI Admin Panel > Functions, edit the EXISTING Magazine Simple Function.
4. Replace its source with magazine_simple.py, save and verify /magazine-simple.
5. Keep existing Function ID, valves, workspace and Sidebar Launcher.

Python requirements: httpx==0.28.1 and PyYAML==6.0.3.
The scheduler runs one cartridge at a time (Sequential or Round Robin).
Real multi-project model and deliberate production restart tests remain incomplete.

Repository: https://github.com/Nundrian/Magazine
Technical guide: docs/TECHNICAL_0.3.0_SCHEDULER_RC1.md
